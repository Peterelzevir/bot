# utils/constants.py

# Text Styles
TEXT_STYLES = {
    'bold': '**{}**',
    'italic': '__{}__',
    'code': '`{}`',
    'strike': '~~{}~~',
    'underline': '--{}--',
    'spoiler': '||{}||'
}

# Media Types
MEDIA_TYPES = {
    'photo': 'photo',
    'video': 'video',
    'gif': 'gif',
    'sticker': 'sticker',
    'document': 'document'
}

# Message States
MESSAGE_STATES = {
    'waiting_phone': 'waiting_phone',
    'waiting_code': 'waiting_code',
    'waiting_2fa': 'waiting_2fa',
    'waiting_message': 'waiting_message',
    'waiting_delay': 'waiting_delay',
    'waiting_group': 'waiting_group',
    'waiting_group_selection': 'waiting_group_selection',
    'waiting_rc_message': 'waiting_rc_message'
}

# Access Types
ACCESS_TYPES = {
    'regular': 'regular',
    'premium': 'premium',
    'premium_plus': 'premium_plus',
    'admin': 'admin'
}

# Userbot States
USERBOT_STATES = {
    'active': 'active',
    'inactive': 'inactive'
}

# Message Types
MESSAGE_TYPES = {
    'text': 'text',
    'media': 'media',
    'mixed': 'mixed'  # For messages with both text and media
}

# Group Actions
GROUP_ACTIONS = {
    'add_all': 'add_all',
    'add_custom': 'add_custom',
    'remove': 'remove'
}

# Button Types
BUTTON_TYPES = {
    'url': 'url',
    'callback': 'callback',
    'switch_inline': 'switch_inline'
}

# Command Types
COMMAND_TYPES = {
    'start': '/start',
    'help': '/help',
    'settings': '/settings'
}