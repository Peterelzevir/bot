from typing import Dict

# Text Styles
TEXT_STYLES: Dict[str, str] = {
    'bold': '**{}**',
    'italic': '__{}__', 
    'code': '`{}`',
    'pre': '```{}```',
    'strike': '~~{}~~',
    'underline': '--{}--',
    'spoiler': '||{}||',
    'mention': '@{}',
    'hashtag': '#{}',
    'url': '[{}]({})'
}

# Media Types
MEDIA_TYPES: Dict[str, str] = {
    'photo': 'photo',
    'video': 'video',
    'animation': 'animation',
    'gif': 'gif',
    'sticker': 'sticker',
    'voice': 'voice',
    'audio': 'audio',
    'document': 'document',
    'video_note': 'video_note',
    'unknown': 'unknown'
}

# Message States
MESSAGE_STATES: Dict[str, str] = {
    # Auth States
    'waiting_phone': 'waiting_phone',
    'waiting_code': 'waiting_code',
    'waiting_2fa': 'waiting_2fa',
    'waiting_password': 'waiting_password',
    
    # Message States
    'waiting_message': 'waiting_message',
    'waiting_delay': 'waiting_delay',
    'waiting_caption': 'waiting_caption',
    'waiting_media': 'waiting_media',
    
    # Group States
    'waiting_group': 'waiting_group',
    'waiting_group_selection': 'waiting_group_selection',
    'waiting_group_usernames': 'waiting_group_usernames',
    
    # RC States
    'waiting_rc_message': 'waiting_rc_message',
    'waiting_rc_target': 'waiting_rc_target',
    
    # Admin States
    'waiting_admin_id': 'waiting_admin_id',
    'waiting_premium_user': 'waiting_premium_user',
    'waiting_premium_duration': 'waiting_premium_duration',
    'waiting_broadcast': 'waiting_broadcast'
}

# Access Types with Permissions
ACCESS_TYPES: Dict[str, Dict] = {
    'regular': {
        'name': 'Regular User',
        'can_create_userbot': False,
        'max_messages': 5,
        'max_groups': 10,
        'has_watermark': True,
        'can_use_premium_emoji': False
    },
    'premium': {
        'name': 'Premium User',
        'can_create_userbot': True,
        'max_messages': 20,
        'max_groups': 50,
        'has_watermark': True,
        'can_use_premium_emoji': True
    },
    'premium_plus': {
        'name': 'Premium Plus User',
        'can_create_userbot': True,
        'max_messages': -1,  # Unlimited
        'max_groups': -1,    # Unlimited
        'has_watermark': False,
        'can_use_premium_emoji': True
    },
    'admin': {
        'name': 'Administrator',
        'can_create_userbot': True,
        'max_messages': -1,  # Unlimited
        'max_groups': -1,    # Unlimited
        'has_watermark': False,
        'can_use_premium_emoji': True,
        'is_admin': True
    }
}

# Userbot States
USERBOT_STATES: Dict[str, Dict] = {
    'inactive': {
        'name': 'Inactive',
        'can_send': False,
        'can_join': False,
        'color': '🔴'
    },
    'active': {
        'name': 'Active',
        'can_send': True,
        'can_join': True,
        'color': '🟢'
    },
    'banned': {
        'name': 'Banned',
        'can_send': False,
        'can_join': False,
        'color': '⛔'
    },
    'expired': {
        'name': 'Expired',
        'can_send': False,
        'can_join': False,
        'color': '⚠️'
    }
}

# Message Types with Validation
MESSAGE_TYPES: Dict[str, Dict] = {
    'text': {
        'name': 'Text Message',
        'max_length': 4096,
        'supports_entities': True
    },
    'media': {
        'name': 'Media Message',
        'max_size': 50 * 1024 * 1024,  # 50MB
        'supported_types': MEDIA_TYPES
    },
    'mixed': {
        'name': 'Mixed Message',
        'max_caption': 1024,
        'supports_entities': True
    }
}

# Group Types and Actions
GROUP_TYPES: Dict[str, str] = {
    'group': 'group',
    'supergroup': 'supergroup',
    'channel': 'channel'
}

GROUP_ACTIONS: Dict[str, Dict] = {
    'add_all': {
        'name': 'Add All Groups',
        'requires_premium': False
    },
    'add_custom': {
        'name': 'Add Custom Groups',
        'requires_premium': True
    },
    'add_by_username': {
        'name': 'Add by Username',
        'requires_premium': True
    },
    'remove': {
        'name': 'Remove Group',
        'requires_premium': False
    }
}

# Button Types with Validation
BUTTON_TYPES: Dict[str, Dict] = {
    'url': {
        'name': 'URL Button',
        'requires_url': True,
        'max_text': 64
    },
    'callback': {
        'name': 'Callback Button',
        'requires_data': True,
        'max_data': 64
    },
    'switch_inline': {
        'name': 'Switch Inline Button',
        'requires_query': True,
        'max_query': 64
    }
}

# Command Types with Descriptions
COMMAND_TYPES: Dict[str, Dict] = {
    'start': {
        'command': '/start',
        'description': 'Start the bot',
        'admin_only': False
    },
    'help': {
        'command': '/help',
        'description': 'Show help message',
        'admin_only': False
    },
    'settings': {
        'command': '/settings',
        'description': 'Bot settings',
        'admin_only': False
    },
    'admin': {
        'command': '/admin',
        'description': 'Admin panel',
        'admin_only': True
    }
}

# Broadcast Settings
BROADCAST_SETTINGS: Dict[str, any] = {
    'max_concurrent': 3,
    'delay_between_messages': 2,  # seconds
    'max_retries': 3,
    'retry_delay': 60,  # seconds
    'chunk_size': 20
}

# Rate Limits
RATE_LIMITS: Dict[str, int] = {
    'message_per_minute': 20,
    'message_per_hour': 100,
    'join_per_minute': 5,
    'join_per_hour': 20
}

# Error Messages
ERROR_MESSAGES: Dict[str, str] = {
    'not_authorized': '⛔ You are not authorized to use this feature',
    'premium_required': '💎 This feature requires Premium subscription',
    'invalid_input': '❌ Invalid input provided',
    'limit_reached': '⚠️ You have reached the limit',
    'bot_blocked': '🚫 Bot was blocked by user',
    'group_not_found': '❌ Group not found',
    'message_too_long': '⚠️ Message is too long'
}

# Success Messages
SUCCESS_MESSAGES: Dict[str, str] = {
    'message_sent': '✅ Message sent successfully',
    'group_added': '✅ Group added successfully',
    'settings_updated': '✅ Settings updated successfully',
    'broadcast_complete': '✅ Broadcast completed successfully'
}