# helpers njir
import re
import emoji
import json
from datetime import datetime
from typing import Union, List, Dict, Optional, Any
from telethon.tl import types
from telethon.utils import get_display_name
import logging

logger = logging.getLogger(__name__)

class TextFormatter:
    """Enhanced text formatting utilities"""
    
    @staticmethod
    def is_valid_phone(phone: str) -> bool:
        """Validate international phone number format"""
        try:
            return bool(re.match(r'^\+[1-9]\d{10,14}$', phone))
        except Exception as e:
            logger.error(f"Phone validation error: {str(e)}")
            return False

    @staticmethod
    def is_valid_otp(otp: str) -> bool:
        """Validate OTP code format"""
        try:
            # Accept both spaced and non-spaced format
            return bool(re.match(r'^\d(\s*\d){4}$', otp))
        except Exception as e:
            logger.error(f"OTP validation error: {str(e)}")
            return False

    @staticmethod
    def clean_text(text: str, preserve_lines: bool = False) -> str:
        """Clean and format text while preserving structure"""
        try:
            if preserve_lines:
                lines = text.split('\n')
                cleaned_lines = [' '.join(line.split()) for line in lines]
                return '\n'.join(line for line in cleaned_lines if line)
            return ' '.join(text.split())
        except Exception as e:
            logger.error(f"Text cleaning error: {str(e)}")
            return text

    @staticmethod
    def extract_username(text: str) -> Optional[str]:
        """Extract username from various formats"""
        try:
            text = text.strip().lower()
            if text.startswith('@'):
                return text[1:]
            elif text.startswith('https://t.me/'):
                return text.split('/')[-1].split('?')[0]
            elif text.startswith('t.me/'):
                return text.split('/')[-1].split('?')[0]
            elif re.match(r'^[a-zA-Z]\w{3,}$', text):
                return text
            return None
        except Exception as e:
            logger.error(f"Username extraction error: {str(e)}")
            return None

    @staticmethod
    def has_emoji(text: str) -> bool:
        """Check for emoji presence with error handling"""
        try:
            return bool(emoji.emoji_count(text))
        except Exception:
            return False

    @staticmethod
    def extract_mentions(text: str) -> List[str]:
        """Extract all mentions from text"""
        try:
            return re.findall(r'@(\w+)', text)
        except Exception as e:
            logger.error(f"Mention extraction error: {str(e)}")
            return []

    @staticmethod
    def format_duration(seconds: int) -> str:
        """Format seconds into readable duration"""
        try:
            minutes, seconds = divmod(seconds, 60)
            hours, minutes = divmod(minutes, 60)
            parts = []
            if hours:
                parts.append(f"{hours}h")
            if minutes:
                parts.append(f"{minutes}m")
            if seconds or not parts:
                parts.append(f"{seconds}s")
            return " ".join(parts)
        except Exception as e:
            logger.error(f"Duration formatting error: {str(e)}")
            return f"{seconds}s"

class MessageHelper:
    """Enhanced message handling utilities"""

    @staticmethod
    def format_message(text: str, entities: List[Dict] = None, 
                      media: Dict = None, caption: str = None) -> Dict:
        """Format message with comprehensive metadata"""
        try:
            return {
                "text": TextFormatter.clean_text(text) if text else "",
                "entities": entities or [],
                "media": media,
                "caption": TextFormatter.clean_text(caption) if caption else "",
                "has_emoji": TextFormatter.has_emoji(text or caption or ""),
                "mentions": TextFormatter.extract_mentions(text or caption or ""),
                "created_at": datetime.now().isoformat(),
                "type": "media" if media else "text"
            }
        except Exception as e:
            logger.error(f"Message formatting error: {str(e)}")
            return {"text": text}

    @staticmethod
    def parse_entities(message_entities: List[types.TypeMessageEntity]) -> List[Dict]:
        """Convert message entities with enhanced attributes"""
        try:
            entities = []
            for entity in message_entities:
                entity_dict = {
                    "offset": entity.offset,
                    "length": entity.length,
                    "type": entity.__class__.__name__
                }
                
                # Add additional attributes
                for attr in ['url', 'user_id', 'language']:
                    if hasattr(entity, attr):
                        value = getattr(entity, attr)
                        if value:
                            entity_dict[attr] = value
                
                entities.append(entity_dict)
            return entities
        except Exception as e:
            logger.error(f"Entity parsing error: {str(e)}")
            return []

    @staticmethod
    def get_media_info(media: Union[bytes, str], mime_type: str = None, 
                      file_name: str = None, file_size: int = None) -> Dict:
        """Get comprehensive media information"""
        try:
            media_type = None
            if mime_type:
                if mime_type.startswith('image/'):
                    media_type = 'photo' if mime_type != 'image/gif' else 'gif'
                elif mime_type.startswith('video/'):
                    media_type = 'video'
                elif mime_type.startswith('audio/'):
                    media_type = 'audio'
                elif mime_type == 'application/x-tgsticker':
                    media_type = 'sticker'
                else:
                    media_type = 'document'

            return {
                "type": media_type,
                "file": media,
                "mime_type": mime_type,
                "file_name": file_name,
                "file_size": file_size,
                "uploaded_at": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Media info error: {str(e)}")
            return {"type": "unknown", "file": media}

class GroupHelper:
    """Enhanced group management utilities"""
    
    @staticmethod
    def format_group_info(group: Dict, include_stats: bool = False) -> str:
        """Format group information with optional stats"""
        try:
            text = f"📌 {group['title']}"
            if group.get('username'):
                text += f" (@{group['username']})"
            text += f"\nID: {group['id']}"
            
            if include_stats:
                text += f"\n👥 Members: {group.get('members_count', '?')}"
                if group.get('broadcast_success'):
                    success_rate = (group['broadcast_success'] / 
                                  (group['broadcast_success'] + group.get('broadcast_fail', 0)) * 100)
                    text += f"\n📊 Success Rate: {success_rate:.1f}%"
            
            return text
        except Exception as e:
            logger.error(f"Group info formatting error: {str(e)}")
            return str(group.get('title', 'Unknown Group'))

    @staticmethod
    def chunk_groups(groups: List[Dict], chunk_size: int = 5) -> List[List[Dict]]:
        """Split groups into manageable chunks"""
        try:
            return [groups[i:i + chunk_size] for i in range(0, len(groups), chunk_size)]
        except Exception as e:
            logger.error(f"Group chunking error: {str(e)}")
            return [groups]

    @staticmethod
    def sort_groups(groups: List[Dict], key: str = 'title', 
                   reverse: bool = False) -> List[Dict]:
        """Sort groups by specified attribute"""
        try:
            return sorted(groups, key=lambda x: x.get(key, ''), reverse=reverse)
        except Exception as e:
            logger.error(f"Group sorting error: {str(e)}")
            return groups

class UserHelper:
    """Enhanced user management utilities"""
    
    @staticmethod
    def format_user_info(user: Dict, include_stats: bool = False) -> str:
        """Format user information with optional stats"""
        try:
            text = f"👤 User ID: {user['user_id']}\n"
            if user.get('first_name'):
                text += f"📝 Name: {user['first_name']}\n"
            if user.get('username'):
                text += f"🔖 Username: @{user['username']}\n"
            text += f"📱 Phone: {user.get('phone', 'Not set')}\n"
            text += f"💎 Access: {user['access_type'].upper()}\n"
            
            if user.get('expire_at'):
                expire_date = datetime.fromisoformat(user['expire_at'])
                days_left = (expire_date - datetime.now()).days
                text += f"⏱️ Expires: {expire_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
                text += f"📅 Days Left: {days_left}\n"
            
            if include_stats and user.get('stats'):
                stats = user['stats']
                text += "\n📊 Statistics:\n"
                text += f"• Messages: {stats.get('message_count', 0)}\n"
                text += f"• Groups: {stats.get('group_count', 0)}\n"
                text += f"• Broadcasts: {stats.get('broadcast_count', 0)}\n"
                if stats.get('broadcast_count'):
                    success_rate = (stats.get('broadcast_success', 0) / 
                                  stats['broadcast_count'] * 100)
                    text += f"• Success Rate: {success_rate:.1f}%\n"
            
            return text
        except Exception as e:
            logger.error(f"User info formatting error: {str(e)}")
            return f"User ID: {user.get('user_id', 'Unknown')}"