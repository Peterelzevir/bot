from datetime import datetime, timedelta
import asyncio
import logging
from typing import Optional, List, Dict
from config import Config
from telethon import TelegramClient
from database.database import Database
from database.models import User

logger = logging.getLogger(__name__)

class ExpiryChecker:
    def __init__(self, bot: TelegramClient, db: Database):
        self.bot = bot
        self.db = db
        self.running = True
        self.check_interval = 3600  # 1 hour in seconds
        self.warning_days = [7, 3, 1]  # Days before expiry to send warning
        self.last_check = None

    async def start(self):
        """Start the expiry checker loop with improved error handling"""
        logger.info("Starting expiry checker service...")
        
        while self.running:
            try:
                current_time = datetime.now()
                
                # Check if enough time has passed since last check
                if (not self.last_check or 
                    (current_time - self.last_check).total_seconds() >= self.check_interval):
                    
                    logger.info("Running expiry checks...")
                    await self.check_expired_users()
                    await self.send_expiry_warnings()
                    self.last_check = current_time
                
                await asyncio.sleep(360)  # Check every 6 minutes
                
            except Exception as e:
                logger.error(f"Error in expiry checker loop: {str(e)}")
                await asyncio.sleep(60)  # Wait a minute before retrying

    async def stop(self):
        """Stop the expiry checker gracefully"""
        logger.info("Stopping expiry checker service...")
        self.running = False

    async def check_expired_users(self):
        """Check and handle expired users with enhanced features"""
        try:
            expired_users = await self.db.check_expired_users()
            
            for user in expired_users:
                await self.handle_expired_user(user)
                
            if expired_users:
                logger.info(f"Processed {len(expired_users)} expired users")
                
        except Exception as e:
            logger.error(f"Error checking expired users: {str(e)}")

    async def handle_expired_user(self, user: User):
        """Handle individual expired user with comprehensive cleanup"""
        try:
            user_id = user.user_id
            old_access_type = user.access_type
            
            # Get user stats before cleanup
            user_stats = await self.db.get_user_stats(user_id)
            
            # Handle userbot cleanup
            await self.cleanup_userbot(user_id)
            
            # Update user access
            await self.db.update_user_access(
                user_id=user_id,
                access_type="regular",
                duration=None
            )
            
            # Send notifications
            await self.send_expiry_notifications(
                user_id=user_id,
                old_access_type=old_access_type,
                user_stats=user_stats
            )
            
            logger.info(f"Successfully handled expired user {user_id}")
            
        except Exception as e:
            logger.error(f"Error handling expired user {user.user_id}: {str(e)}")

    async def cleanup_userbot(self, user_id: int):
        """Comprehensive userbot cleanup"""
        try:
            # Stop active userbot
            if user_id in self.bot.active_userbots:
                userbot = self.bot.active_userbots[user_id]
                try:
                    await userbot.disconnect()
                except:
                    pass
                del self.bot.active_userbots[user_id]
            
            # Delete userbot and associated data
            await self.db.delete_userbot(user_id)
            logger.info(f"Cleaned up userbot for user {user_id}")
            
        except Exception as e:
            logger.error(f"Error cleaning up userbot for user {user_id}: {str(e)}")
            raise

    async def send_expiry_notifications(self, user_id: int, old_access_type: str, user_stats: Dict):
        """Send detailed notifications to user and admin"""
        try:
            # User notification
            user_message = (
                f"⚠️ **Akses Premium Anda Telah Berakhir!**\n\n"
                f"📊 Ringkasan Penggunaan:\n"
                f"• Total Pesan: {user_stats['message_count']}\n"
                f"• Total Grup: {user_stats['group_count']}\n"
                f"• Total Broadcast: {user_stats['total_broadcasts']}\n\n"
                f"📱 Status sebelumnya: {old_access_type.upper()}\n"
                f"📱 Status sekarang: REGULAR\n\n"
                f"Perubahan yang terjadi:\n"
                f"• ❌ Userbot telah dihentikan dan dihapus\n"
                f"• ❌ Session telah dilepas dari akun\n"
                f"• ❌ Seluruh list pesan telah dihapus\n"
                f"• ❌ Seluruh list grup telah dihapus\n\n"
                f"Untuk mengaktifkan kembali akses premium,\n"
                f"silakan hubungi @hiyaok"
            )
            
            await self.bot.send_message(user_id, user_message)
            
            # Admin notification
            admin_message = (
                f"📊 **Premium User Expired!**\n\n"
                f"👤 User ID: {user_id}\n"
                f"📱 Status sebelumnya: {old_access_type.upper()}\n"
                f"📊 Statistik Penggunaan:\n"
                f"• Messages: {user_stats['message_count']}\n"
                f"• Groups: {user_stats['group_count']}\n"
                f"• Broadcasts: {user_stats['total_broadcasts']}\n"
                f"• Success Rate: {user_stats['successful_broadcasts'] / max(1, user_stats['total_broadcasts']) * 100:.1f}%\n\n"
                f"✅ Tindakan yang dilakukan:\n"
                f"• Userbot dihentikan & dihapus\n"
                f"• Status diubah ke REGULAR\n"
                f"• Notifikasi terkirim ke user"
            )
            
            await self.bot.send_message(Config.ADMIN_ID, admin_message)
            logger.info(f"Sent expiry notifications for user {user_id}")
            
        except Exception as e:
            logger.error(f"Error sending notifications for user {user_id}: {str(e)}")

    async def send_expiry_warnings(self):
        """Send warnings to users approaching expiry"""
        try:
            users = await self.db.get_all_users()
            current_time = datetime.now()
            
            for user in users:
                if not user.expire_at:
                    continue
                    
                days_left = (user.expire_at - current_time).days
                
                if days_left in self.warning_days:
                    await self.send_warning_notification(user, days_left)
                    
        except Exception as e:
            logger.error(f"Error sending expiry warnings: {str(e)}")

    async def send_warning_notification(self, user: User, days_left: int):
        """Send warning notification to user"""
        try:
            message = (
                f"⚠️ **Peringatan Masa Aktif Premium**\n\n"
                f"📅 Akses premium Anda akan berakhir dalam {days_left} hari\n"
                f"📱 Status: {user.access_type.upper()}\n"
                f"⏰ Berakhir pada: {user.expire_at.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"Untuk memperpanjang akses premium,\n"
                f"silakan hubungi @hiyaok sebelum masa aktif berakhir\n\n"
                f"Jika tidak diperpanjang, maka:\n"
                f"• ❌ Userbot akan dihentikan\n"
                f"• ❌ Seluruh data akan dihapus\n"
                f"• ❌ Status akan kembali ke REGULAR"
            )
            
            await self.bot.send_message(user.user_id, message)
            logger.info(f"Sent {days_left}-day warning to user {user.user_id}")
            
        except Exception as e:
            logger.error(f"Error sending warning to user {user.user_id}: {str(e)}")