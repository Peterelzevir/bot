# atur disini abangkuhhh ganti api id api hash sama token bot y
# by hiyaok 
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

class Config:
    # Telegram API Credentials
    API_ID = "23207350"
    API_HASH = "03464b6c80a5051eead6835928e48189"
    BOT_TOKEN = "7512821985:AAHvCj9srUJhxqGYoQ7xjZxW_nepIILJGsI"
    
    # Database Configuration
    DB_NAME = "userbot.db"
    DB_BACKUP_DIR = "backups"
    
    # Admin Configuration
    ADMIN_ID = 5988451717
    ADMIN_USERNAME = "hiyaok"
    
    # Bot Settings
    BOT_USERNAME = "userbotdemobot"
    OWNER_USERNAME = "hiyaok"
    WATERMARK = "Userbot By @hiyaok"
    
    # Logging Configuration
    LOG_LEVEL = "INFO"
    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE = "bot.log"
    
    # Rate Limits
    RATE_LIMITS = {
        "message_per_minute": 20,
        "message_per_hour": 180,
        "join_per_minute": 5,
        "join_per_hour": 20,
        "broadcast_delay": 2,  # seconds between broadcasts
        "group_join_delay": 30,  # seconds between group joins
    }
    
    # Timeouts
    TIMEOUTS = {
        "client_connection": 30,  # seconds
        "message_send": 15,
        "group_join": 20,
        "media_download": 300,
        "session_expire": 3600
    }
    
    # User Settings
    USER_SETTINGS = {
        "max_userbots": 1,
        "max_otp_attempts": 3,
        "otp_timeout": 300,  # seconds
        "session_timeout": 1800,  # seconds
        "min_delay": 1,
        "max_delay": 3600,
        "max_messages": 100,
        "max_groups": 100,
        "max_message_length": 4096,
        "max_caption_length": 1024,
        "max_file_size": 50 * 1024 * 1024  # 50MB
    }
    
    # Premium Features
    PREMIUM_FEATURES = {
        "regular": {
            "can_create_userbot": False,
            "max_groups": 0,
            "max_messages": 0,
            "needs_watermark": True,
            "can_use_premium_emoji": False,
            "can_send_media": False,
            "can_schedule": False,
            "max_file_size": 10 * 1024 * 1024,  # 10MB
            "broadcast_interval": 60,
            "support_priority": "low"
        },
        "premium": {
            "can_create_userbot": True,
            "max_groups": 50,
            "max_messages": 50,
            "needs_watermark": True,
            "can_use_premium_emoji": True,
            "can_send_media": True,
            "can_schedule": True,
            "max_file_size": 50 * 1024 * 1024,  # 50MB
            "broadcast_interval": 30,
            "support_priority": "medium"
        },
        "premium_plus": {
            "can_create_userbot": True,
            "max_groups": 100,
            "max_messages": 100,
            "needs_watermark": False,
            "can_use_premium_emoji": True,
            "can_send_media": True,
            "can_schedule": True,
            "max_file_size": 100 * 1024 * 1024,  # 100MB
            "broadcast_interval": 10,
            "support_priority": "high"
        },
        "admin": {
            "can_create_userbot": True,
            "max_groups": -1,
            "max_messages": -1,
            "needs_watermark": False,
            "can_use_premium_emoji": True,
            "can_send_media": True,
            "can_schedule": True,
            "max_file_size": -1,
            "broadcast_interval": 0,
            "support_priority": "instant"
        }
    }
    
    # Media Types
    ALLOWED_MEDIA_TYPES = {
        "photo": ["image/jpeg", "image/png", "image/webp"],
        "video": ["video/mp4", "video/x-matroska", "video/webm"],
        "animation": ["video/mp4", "image/gif"],
        "audio": ["audio/mp3", "audio/ogg", "audio/wav"],
        "voice": ["audio/ogg"],
        "document": ["application/pdf", "application/zip", "text/plain"]
    }
    
    # Error Messages
    ERROR_MESSAGES = {
        # Auth Errors
        "not_authorized": "❌ Anda tidak memiliki akses untuk menggunakan fitur ini.\n\nHubungi @{owner} untuk mendapatkan akses premium.",
        "expired": "❌ Akses premium Anda telah berakhir. Silakan perpanjang untuk melanjutkan.",
        "invalid_phone": "❌ Nomor telepon tidak valid. Gunakan format: +6281234567890",
        "invalid_otp": "❌ Kode OTP tidak valid. Masukkan 5 digit angka dengan spasi.",
        "max_otp_attempts": "❌ Terlalu banyak percobaan. Silakan mulai dari awal.",
        "2fa_needed": "🔐 Akun ini menggunakan 2FA. Masukkan password 2FA Anda.",
        "invalid_2fa": "❌ Password 2FA salah. Coba lagi.",
        
        # Limit Errors
        "group_limit": "❌ Batas maksimum grup tercapai ({limit}).",
        "message_limit": "❌ Batas maksimum pesan tercapai ({limit}).",
        "file_size_limit": "❌ Ukuran file melebihi batas ({limit}MB).",
        "flood_wait": "⚠️ Terlalu banyak permintaan. Tunggu {wait_time} detik.",
        
        # Operation Errors
        "invalid_delay": "❌ Delay harus antara {min_delay} dan {max_delay} detik.",
        "userbot_exists": "❌ Anda sudah memiliki userbot aktif.",
        "no_userbot": "❌ Anda belum memiliki userbot.",
        "database_error": "❌ Terjadi kesalahan database. Coba lagi nanti.",
        "media_error": "❌ Gagal memproses media. Format tidak didukung.",
        "group_not_found": "❌ Grup tidak ditemukan atau tidak dapat diakses.",
        "message_too_long": "❌ Pesan terlalu panjang. Maksimal {limit} karakter.",
        
        # Technical Errors
        "connection_error": "❌ Gagal terhubung ke server. Coba lagi.",
        "session_expired": "❌ Sesi telah berakhir. Silakan login ulang.",
        "internal_error": "❌ Terjadi kesalahan internal. Tim support akan menangani."
    }
    
    # Success Messages
    SUCCESS_MESSAGES = {
        # Auth Success
        "userbot_created": "✅ Userbot berhasil dibuat!\n\nGunakan menu Settings untuk konfigurasi.",
        "login_success": "✅ Login berhasil! Selamat menggunakan userbot.",
        
        # Operation Success
        "message_added": "✅ Pesan berhasil ditambahkan ke list.",
        "message_updated": "✅ Pesan berhasil diperbarui.",
        "message_deleted": "✅ Pesan berhasil dihapus.",
        "group_added": "✅ Grup berhasil ditambahkan ke list.",
        "group_removed": "✅ Grup berhasil dihapus dari list.",
        "delay_updated": "✅ Delay berhasil diubah menjadi {delay} detik.",
        "status_changed": "✅ Status userbot berhasil diubah ke {status}.",
        
        # Broadcast Success
        "broadcast_started": "📤 Broadcast dimulai...",
        "broadcast_progress": "📊 Progress: {progress}%\n✅ Berhasil: {success}\n❌ Gagal: {failed}",
        "broadcast_complete": "✅ Broadcast selesai!\n\nBerhasil: {success}\nGagal: {failed}",
        
        # Admin Operations
        "premium_added": "✅ User premium berhasil ditambahkan!\nDurasi: {duration} hari",
        "admin_added": "✅ Admin baru berhasil ditambahkan.",
        "settings_updated": "✅ Pengaturan berhasil diperbarui."
    }
    
    # Help Messages
    HELP_MESSAGES = {
        "about_userbot": """
🤖 *Userbot Premium*

Userbot adalah bot Telegram yang berjalan menggunakan akun pengguna biasa.
Dengan userbot premium, Anda mendapatkan:

- 📨 Broadcast otomatis ke banyak grup
- 📱 Support semua jenis media 
- ⚡ Support emoji premium
- ⏱️ Pengaturan delay fleksibel
- 📊 Monitoring status pengiriman
- 🔄 Fitur RC (Recent Chats)
- 💎 Dan banyak lagi!

Untuk menggunakan userbot, Anda harus menjadi user premium.
Hubungi @{owner} untuk informasi lebih lanjut.
        """,
        
        "premium_features": """
💎 *Fitur Premium*

✨ Premium Regular:
- 50 grup maksimal
- 50 pesan maksimal
- Support media & emoji
- Dengan watermark

✨ Premium Plus:
- 100 grup maksimal
- 100 pesan maksimal
- Support media & emoji
- Tanpa watermark
- Priority support

Hubungi @{owner} untuk upgrade ke premium!
        """
    }

    @classmethod
    def get_user_limits(cls, access_type: str) -> Dict[str, Any]:
        """Get user limits with defaults"""
        default_limits = cls.PREMIUM_FEATURES["regular"]
        return cls.PREMIUM_FEATURES.get(access_type, default_limits)

    @classmethod
    def format_error(cls, error_key: str, **kwargs) -> str:
        """Format error message with owner replacement"""
        kwargs.setdefault('owner', cls.OWNER_USERNAME)
        return cls.ERROR_MESSAGES.get(error_key, "❌ Terjadi kesalahan.").format(**kwargs)

    @classmethod
    def format_success(cls, success_key: str, **kwargs) -> str:
        """Format success message with owner replacement"""
        kwargs.setdefault('owner', cls.OWNER_USERNAME)
        return cls.SUCCESS_MESSAGES.get(success_key, "✅ Berhasil!").format(**kwargs)

    @classmethod
    def format_help(cls, help_key: str, **kwargs) -> str:
        """Format help message with owner replacement"""
        kwargs.setdefault('owner', cls.OWNER_USERNAME)
        return cls.HELP_MESSAGES.get(help_key, "").format(**kwargs)

    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id == cls.ADMIN_ID

    @classmethod 
    def get_media_types(cls, file_type: str) -> list:
        """Get allowed mime types for media type"""
        return cls.ALLOWED_MEDIA_TYPES.get(file_type, [])