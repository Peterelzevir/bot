# handlers/user_handlers.py
from telethon import events, Button, TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, MessageMediaPhoto, MessageMediaDocument
from telethon.errors import *
from database.database import Database
from config import Config
from userbot.client import UserBot
import asyncio
import logging
import re
from datetime import datetime

logger = logging.getLogger(__name__)

class UserHandlers:
    def __init__(self, bot: TelegramClient, db: Database):
        self.bot = bot
        self.db = db
        self.user_states = {}
        self.otp_attempts = {}
        self.active_userbots = {}
        self.message_formatter = MessageFormatter()

    async def start_handler(self, event):
        """Handle /start command"""
        user = await self.db.get_user(event.sender_id)
        
        if not user:
            buttons = [
                [Button.inline("📱 Create Userbot", "create_userbot")],
                [Button.inline("ℹ️ About Userbot", "about_userbot")]
            ]
            await event.reply(
                "🤖 Welcome to Userbot by @hiyaok!\n\n"
                "Bot ini memungkinkan Anda untuk membuat userbot dengan berbagai fitur:\n"
                "• 📨 Broadcast pesan otomatis ke grup\n"
                "• 📱 Support berbagai jenis media\n"
                "• ⚡ Support emoji premium\n"
                "• ⏱️ Pengaturan delay untuk setiap pesan\n"
                "• 📊 Monitoring status pengiriman\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )
        else:
            userbot = await self.db.get_userbot(event.sender_id)
            buttons = [
                [Button.inline("⚙️ Settings Userbot", "settings_userbot")],
                [Button.inline("ℹ️ About Userbot", "about_userbot")]
            ]
            
            if event.sender_id == Config.ADMIN_ID:
                buttons.insert(0, [Button.inline("👮‍♂️ Admin Panel", "admin_panel")])

            status_text = "Active" if userbot and userbot.status == "active" else "Inactive"
            expire_text = user.expire_at.strftime('%Y-%m-%d %H:%M:%S') if user.expire_at else 'Never'

            await event.reply(
                f"👋 Selamat datang kembali!\n\n"
                f"📊 Informasi User:\n"
                f"├ Status: {user.access_type.upper()}\n"
                f"├ Userbot: {status_text}\n"
                f"└ Expire: {expire_text}\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )

    async def about_handler(self, event):
        """Handle about section"""
        text = Config.format_help("about_userbot")
        await event.edit(text, buttons=[[Button.inline("🔙 Back", "start")]])

    async def create_userbot_handler(self, event):
        """Handle userbot creation"""
        user = await self.db.get_user(event.sender_id)
        if not user or user.access_type not in ["admin", "premium", "premium_plus"]:
            await event.edit(
                Config.format_error("not_authorized"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        self.otp_attempts[event.sender_id] = 0
        
        await event.edit(
            "📱 Kirim nomor telepon dalam format internasional\n"
            "Contoh: +6281234567890",
            buttons=[[Button.inline("🔙 Back", "start")]]
        )
        self.user_states[event.sender_id] = "waiting_phone"

    async def handle_phone_number(self, event):
        """Handle phone number input"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                Config.format_error("invalid_phone"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Kode telah dikirim! Masukkan kode dengan spasi.\n"
                "Contoh: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ Nomor telepon ini telah dibanned oleh Telegram!",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Terlalu banyak permintaan! Tunggu {e.seconds} detik.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_code(self, event):
        """Handle OTP code input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            await event.reply(Config.format_error("invalid_otp"))
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)
            
            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return
                
            await event.reply("❌ Kode OTP salah! Silakan coba lagi.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa"
            await event.reply(
                "🔐 Akun ini menggunakan Two-Factor Authentication.\n"
                "Silakan masukkan password 2FA Anda:",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)

            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Password 2FA salah! Silakan coba lagi.")
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def settings_handler(self, event):
        """Handle settings menu"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                Config.format_error("no_userbot"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        buttons = [
            [Button.inline("📊 Status", "status"), 
             Button.inline("📝 Check Lists", "check_lists")],
            [Button.inline("➕ Add List", "add_list"),
             Button.inline("📨 Send to RC", "send_rc")],
            [Button.inline("👥 Add Groups", "add_groups"),
             Button.inline("📋 List Groups", "list_groups")],
            [Button.inline("🗑️ Delete Group", "delete_group"),
             Button.inline("📥 Join Group", "joined_groups")],
            [Button.inline("⏱️ Set Delay", "set_delay"),
             Button.inline("❌ Delete List", "delete_list")],
            [Button.inline("🔙 Back", "start")]
        ]
        
        await event.edit(
            f"⚙️ Pengaturan Userbot\n\n"
            f"Status: {'🟢 Active' if userbot.status == 'active' else '🔴 Inactive'}\n\n"
            "Pilih opsi di bawah:",
            buttons=buttons
        )

    async def status_handler(self, event):
        """Handle status change"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                Config.format_error("no_userbot"),
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        current_status = userbot.status
        new_status = "active" if current_status == "inactive" else "inactive"
        
        buttons = [
            [Button.inline(f"✅ Ya, ubah ke {new_status}", f"confirm_status_{new_status}"),
             Button.inline("❌ Tidak", "settings_userbot")]
        ]
        
        await event.edit(
            f"📊 Status Userbot\n\n"
            f"Status saat ini: {current_status}\n"
            f"Ubah ke: {new_status}\n\n"
            f"{'⚠️ Bot akan mulai mengirim pesan' if new_status == 'active' else '⚠️ Bot akan berhenti mengirim pesan'}",
            buttons=buttons
        )

    async def confirm_status_handler(self, event):
        """Handle status confirmation"""
        status = event.data.decode().split("_")[-1]
        user_id = event.sender_id
        
        await self.db.update_userbot_status(user_id, status)
        
        if status == "active":
            userbot_data = await self.db.get_userbot(user_id)
            user_data = await self.db.get_user(user_id)
            
            userbot = UserBot(
                userbot_data.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            
            await userbot.start()
            self.active_userbots[user_id] = userbot
            
            asyncio.create_task(self.handle_broadcasting(user_id))
            
            await event.edit(
                "✅ Status berhasil diubah ke active!\n"
                "Bot akan mulai mengirim pesan...",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        else:
            if user_id in self.active_userbots:
                await self.active_userbots[user_id].stop()
                del self.active_userbots[user_id]
            
            await event.edit(
                "✅ Status berhasil diubah ke inactive!\n"
                "Bot telah berhenti mengirim pesan.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def check_lists_handler(self, event):
        """Handle list check"""
        messages = await self.db.get_messages(event.sender_id)
        
        if not messages:
            await event.edit(
                "📝 Belum ada pesan dalam list.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return
            
        text = "📝 List Pesan:\n\n"
        for i, msg in enumerate(messages, 1):
            text += f"{i}. "
            if msg.media:
                text += "[Media] "
            text += f"{msg.text[:50]}...\nDelay: {msg.delay}s\n\n"
            
        await event.edit(text, buttons=[[Button.inline("🔙 Back", "settings_userbot")]])

    async def add_list_handler(self, event):
        """Handle list addition"""
        await event.edit(
            "📝 Kirim pesan yang ingin ditambahkan ke list.\n\n"
            "• Support semua format teks\n"
            "• Support emoji premium\n"
            "• Support foto/video/gif dengan caption",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id]
        
    async def handle_message_input(self, event):
        """Handle message input for list"""
        if event.sender_id not in self.user_states:
            return

        user_id = event.sender_id
        message = event.message

        # Format message with text and entities
        formatted_message = {
            "text": message.text or message.caption or "",
            "entities": [e.to_dict() for e in (message.entities or [])],
            "media": None
        }

        # Handle media
        if message.media:
            media_bytes = await message.download_media(bytes)
            formatted_message["media"] = {
                "type": self._get_media_type(message.media),
                "file": media_bytes
            }

        # Move to delay input state
        self.user_states[user_id] = {
            "state": "waiting_delay",
            "message": formatted_message
        }

        await event.reply(
            "⏱️ Berapa detik delay untuk pesan ini? (1-3600)",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def handle_delay_input(self, event):
        """Handle delay input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text)
            if not 1 <= delay <= 3600:
                raise ValueError

            state_data = self.user_states[event.sender_id]
            message = state_data["message"]
            message["delay"] = delay

            await self.db.add_message(event.sender_id, message)

            await event.reply(
                "✅ Pesan berhasil ditambahkan ke list!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError:
            await event.reply(
                "❌ Delay tidak valid! Masukkan angka antara 1-3600 detik.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def delete_list_handler(self, event):
        """Handle list deletion"""
        messages = await self.db.get_messages(event.sender_id)

        if not messages:
            await event.edit(
                "📝 Tidak ada pesan yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for message in messages:
            text = f"[Media] " if message.media else ""
            text += message.text[:30] + "..."
            buttons.append([Button.inline(text, f"delete_msg_{message.id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "🗑️ Pilih pesan yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_message(self, event):
        """Handle message deletion confirmation"""
        message_id = int(event.data.decode().split("_")[-1])
        await self.db.delete_message(event.sender_id, message_id)
        
        await event.edit(
            "✅ Pesan berhasil dihapus!",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def joined_groups_handler(self, event):
        """Handle listing joined groups"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        user_data = await self.db.get_user(event.sender_id)
        client = UserBot(
            userbot.session_string,
            Config.API_ID,
            Config.API_HASH,
            user_data.access_type
        )
        await client.start()

        joined_groups = await client.get_joined_groups()
        await client.stop()

        if not joined_groups:
            await event.edit(
                "📥 Userbot belum join grup manapun.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        text = "📥 List Grup yang Di-Join:\n\n"
        for i, group in enumerate(joined_groups, 1):
            text += f"{i}. {group['title']}"
            if group.get('username'):
                text += f" (@{group['username']})"
            text += f"\nID: {group['id']}"
            text += f"\nMembers: {group.get('members_count', '?')}\n\n"

        await event.edit(
            text,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def add_groups_handler(self, event):
        """Handle adding groups to allowed list"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = [
            [Button.inline("✅ Add All Joined Groups", "add_all_groups")],
            [Button.inline("👥 Custom Selection", "custom_add_groups")],
            [Button.inline("🔙 Back", "settings_userbot")]
        ]

        await event.edit(
            "👥 Pilih metode penambahan grup:",
            buttons=buttons
        )

    async def add_all_groups_handler(self, event):
        """Handle adding all joined groups"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            return

        user_data = await self.db.get_user(event.sender_id)
        client = UserBot(
            userbot.session_string,
            Config.API_ID,
            Config.API_HASH,
            user_data.access_type
        )
        await client.start()

        joined_groups = await client.get_joined_groups()
        await client.stop()

        if not joined_groups:
            await event.edit(
                "📥 Userbot belum join grup manapun.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        count = 0
        for group in joined_groups:
            await self.db.add_allowed_group(event.sender_id, group)
            count += 1

        await event.edit(
            f"✅ Berhasil menambahkan {count} grup ke daftar yang diizinkan!",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def custom_add_groups_handler(self, event):
        """Handle custom group selection"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            return

        user_data = await self.db.get_user(event.sender_id)
        client = UserBot(
            userbot.session_string,
            Config.API_ID,
            Config.API_HASH,
            user_data.access_type
        )
        await client.start()

        joined_groups = await client.get_joined_groups()
        await client.stop()

        if not joined_groups:
            await event.edit(
                "📥 Userbot belum join grup manapun.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        # Get already allowed groups
        allowed_groups = await self.db.get_allowed_groups(event.sender_id)
        allowed_ids = [g.group_id for g in allowed_groups]

        # Create selection buttons
        buttons = []
        for group in joined_groups:
            is_allowed = group["id"] in allowed_ids
            text = "✅ " if is_allowed else "⭕ "
            text += group["title"]
            if group.get("username"):
                text += f" (@{group['username']})"
            buttons.append([Button.inline(text, f"toggle_group_{group['id']}")])

        buttons.extend([
            [Button.inline("💾 Save Selection", "save_group_selection")],
            [Button.inline("🔙 Back", "settings_userbot")]
        ])

        self.user_states[event.sender_id] = {
            "state": "selecting_groups",
            "selected": allowed_ids
        }

        await event.edit(
            "👥 Pilih grup yang diizinkan:\n"
            "✅ = Sudah diizinkan\n"
            "⭕ = Belum diizinkan",
            buttons=buttons
        )

    async def list_groups_handler(self, event):
        """Handle group list display"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Belum ada grup yang ditambahkan.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        text = "📋 List Grup:\n\n"
        for i, group in enumerate(groups, 1):
            text += f"{i}. {group.title}"
            if group.username:
                text += f" (@{group.username})"
            text += f"\nID: {group.group_id}\n\n"

        await event.edit(
            text,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def delete_group_handler(self, event):
        """Handle group deletion"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Tidak ada grup yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for group in groups:
            text = group.title
            if group.username:
                text += f" (@{group.username})"
            buttons.append([Button.inline(text, f"delete_group_{group.group_id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "🗑️ Pilih grup yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_group(self, event):
        """Handle group deletion confirmation"""
        group_id = int(event.data.decode().split("_")[-1])
        await self.db.remove_group(event.sender_id, group_id)

        await event.edit(
            "✅ Grup berhasil dihapus!",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def set_delay_handler(self, event):
        """Handle delay setting"""
        messages = await self.db.get_messages(event.sender_id)

        if not messages:
            await event.edit(
                "📝 Tidak ada pesan yang bisa diatur delaynya.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for message in messages:
            text = f"[Media] " if message.media else ""
            text += f"{message.text[:30]}... ({message.delay}s)"
            buttons.append([Button.inline(text, f"set_delay_{message.id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "⏱️ Pilih pesan yang ingin diubah delaynya:",
            buttons=buttons
        )

    async def handle_new_delay(self, event):
        """Handle new delay input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text)
            if not 1 <= delay <= 3600:
                raise ValueError

            message_id = self.user_states[event.sender_id]["message_id"]
            await self.db.update_message_delay(event.sender_id, message_id, delay)

            await event.reply(
                "✅ Delay berhasil diubah!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError:
            await event.reply(
                "❌ Delay tidak valid! Masukkan angka antara 1-3600 detik.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def send_rc_handler(self, event):
        """Handle RC message sending"""
        await event.edit(
            "📨 Kirim pesan yang ingin disebarkan ke recent chats:\n\n"
            "• Support semua format teks\n"
            "• Support emoji premium\n"
            "• Support foto/video/gif dengan caption",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_rc_message"

    async def handle_rc_message(self, event):
        """Handle RC message input"""
        if event.sender_id not in self.user_states:
            return

        userbot_data = await self.db.get_userbot(event.sender_id)
        user_data = await self.db.get_user(event.sender_id)

        if not userbot_data:
            await event.reply("❌ Userbot tidak ditemukan!")
            return

        userbot = UserBot(
            userbot_data.session_string,
            Config.API_ID,
            Config.API_HASH,
            user_data.access_type
        )

        await userbot.start()

        message = event.message
        formatted_message = {
            "text": message.text or message.caption or "",
            "entities": [e.to_dict() for e in (message.entities or [])],
            "media": None
        }

        if message.media:
            media_bytes = await message.download_media(bytes)
            formatted_message["media"] = {
                "type": self._get_media_type(message.media),
                "file": media_bytes
            }

        result = await userbot.send_to_recent_chats(formatted_message)

        await userbot.stop()

        report = (
            "📊 Hasil Pengiriman RC:\n\n"
            f"✅ Berhasil: {result['success_count']}\n"
            f"❌ Gagal: {result['fail_count']}\n\n"
        )

        if result['failed_chats']:
            report += "Chat yang gagal:\n"
            for chat in result['failed_chats']:
                report += f"• {chat}\n"

        await event.reply(
            report,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

        del self.user_states[event.sender_id]

    def _get_media_type(self, media):
        """Helper to determine media type"""
        if isinstance(media, MessageMediaPhoto):
            return "photo"
        elif isinstance(media, MessageMediaDocument):
            if media.document.mime_type.startswith("video"):
                return "video"
            elif media.document.mime_type == "image/gif":
                return "gif"
        return None

    async def handle_broadcasting(self, user_id):
        """Handle message broadcasting"""
        if user_id not in self.active_userbots:
            return

        userbot = self.active_userbots[user_id]
        messages = await self.db.get_messages(user_id)
        groups = await self.db.get_groups(user_id)

        if not messages or not groups:
            await self.bot.send_message(
                user_id,
                "❌ Tidak ada pesan atau grup yang ditambahkan!"
            )
            return

        user = await self.db.get_user(user_id)
        watermark = Config.WATERMARK if user.access_type == "premium" else None

        while user_id in self.active_userbots:
            for message in messages:
                if user_id not in self.active_userbots:
                    break

                for group in groups:
                    if user_id not in self.active_userbots:
                        break

                    try:
                        await userbot.send_message_to_group(
                            group.group_id,
                            message,
                            watermark=watermark
                        )

                        await self.bot.send_message(
                            user_id,
                            f"✅ Pesan berhasil dikirim ke {group.title}"
                        )
                    except Exception as e:
                        await self.bot.send_message(
                            user_id,
                            f"❌ Gagal mengirim ke {group.title}: {str(e)}"
                        )

                    await asyncio.sleep(message.delay)