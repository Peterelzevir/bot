# user handlers
from telethon import events, Button, TelegramClient
from telethon.sessions import StringSession
from telethon.tl.types import User
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, MessageMediaPhoto, MessageMediaDocument
from telethon.errors import *
from database.database import Database
from config import Config
from userbot.client import UserBot
import asyncio
import logging
import re
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class UserHandlers:
    def __init__(self, bot: TelegramClient, db: Database):
        self.bot = bot
        self.db = db
        self.user_states = {}
        self.otp_attempts = {}
        self.active_userbots = {}

    # Helper Methods
    def _format_entity(self, entity):
        """Format message entity (formatting, emoji, etc)"""
        return {
            "type": entity.__class__.__name__,
            "offset": entity.offset,
            "length": entity.length,
            "url": getattr(entity, 'url', None),
            "user_id": getattr(entity, 'user_id', None),
            "language": getattr(entity, 'language', None),
        }

    def _get_media_type(self, media):
        """Enhanced media type detection"""
        try:
            if isinstance(media, MessageMediaPhoto):
                return "photo"
            elif isinstance(media, MessageMediaDocument):
                if hasattr(media.document, 'mime_type'):
                    if media.document.mime_type.startswith('video'):
                        return "video"
                    elif media.document.mime_type == 'image/gif':
                        return "gif"
                    elif media.document.mime_type.startswith('image'):
                        return "image"
                    elif media.document.mime_type.startswith('audio'):
                        return "audio"
                    else:
                        return "document"
            return "unknown"
        except:
            return "unknown"

    async def format_message(self, message):
        """Format message to match database schema structure"""
        try:
            formatted_msg = {
                'text': None,
                'media': None,
                'media_type': None,
                'caption': None,
                'delay': 60,  # Default delay
                'entities': None,
                'caption_entities': None,
                'status': 'active'
            }
            
            if message.media:
                # Handle media message
                media_bytes = await message.download_media(bytes)
                
                # Set media type
                if hasattr(message.media, 'photo'):
                    media_type = "photo"
                elif hasattr(message.media, 'document'):
                    mime_type = message.media.document.mime_type
                    if mime_type:
                        if mime_type.startswith('video'): media_type = "video"
                        elif mime_type == 'image/gif': media_type = "gif"
                        elif mime_type.startswith('image'): media_type = "image"
                        elif mime_type.startswith('audio'): media_type = "audio"
                        else: media_type = "document"
                    else:
                        media_type = "document"
                else:
                    media_type = "document"

                formatted_msg.update({
                    'media': media_bytes,
                    'media_type': media_type,
                    'caption': message.caption if message.caption else None,
                    'caption_entities': json.dumps([{
                        'type': entity.__class__.__name__,
                        'offset': entity.offset,
                        'length': entity.length,
                        'url': getattr(entity, 'url', None)
                    } for entity in message.caption_entities]) if message.caption_entities else None
                })
                
            else:
                # Handle text message
                formatted_msg.update({
                    'text': message.text,
                    'entities': json.dumps([{
                        'type': entity.__class__.__name__,
                        'offset': entity.offset,
                        'length': entity.length,
                        'url': getattr(entity, 'url', None)
                    } for entity in message.entities]) if message.entities else None
                })

            return formatted_msg
            
        except Exception as e:
            logger.error(f"Error formatting message: {str(e)}")
            raise

    async def send_formatted_message(self, client, chat_id, message_data):
        """Send message with database-compatible format"""
        try:
            if message_data.get('media') is not None:
                # Handle media message
                file = message_data['media']
                caption = message_data.get('caption', '')
                
                # Parse caption entities if present
                caption_entities = None
                if message_data.get('caption_entities'):
                    caption_entities = json.loads(message_data['caption_entities'])
                
                params = {
                    'file': file,
                    'caption': caption,
                    'parse_mode': 'html'  # For emoji support
                }
                
                if caption_entities:
                    params['caption_entities'] = caption_entities
                
                # Handle different media types
                media_type = message_data.get('media_type', 'document')
                if media_type == "photo":
                    params['force_document'] = False
                else:
                    params['force_document'] = media_type == "document"
                
                await client.send_file(chat_id, **params)
                
            else:
                # Handle text message
                text = message_data.get('text', '')
                
                # Parse text entities if present
                entities = None
                if message_data.get('entities'):
                    entities = json.loads(message_data['entities'])
                
                await client.send_message(
                    chat_id,
                    text,
                    formatting_entities=entities,
                    parse_mode='html'  # For emoji support
                )
                
            # Update last_used timestamp in database
            if 'id' in message_data:
                await self.db.update_message_last_used(message_data['id'])
                
        except Exception as e:
            logger.error(f"Error sending message to {chat_id}: {str(e)}")
            raise

    # Main Handlers
    async def start_handler(self, event):
        """Handle /start command"""
        user = await self.db.get_user(event.sender_id)
        
        if not user:
            # New user registration
            buttons = [
                [Button.inline("📱 Create Userbot", "create_userbot")],
                [Button.inline("ℹ️ About Userbot", "about_userbot")]
            ]
            
            # Add admin button if user is admin
            if event.sender_id == Config.ADMIN_ID:
                buttons.insert(0, [Button.inline("👮‍♂️ Admin Panel", "admin_panel")])
                
            await event.reply(
                "🤖 Welcome to Userbot by @hiyaok!\n\n"
                "Bot ini memungkinkan Anda untuk membuat userbot dengan berbagai fitur:\n"
                "• 📨 Broadcast pesan otomatis ke grup\n"
                "• 📱 Support berbagai jenis media\n"
                "• ⚡ Support emoji premium\n"
                "• ⏱️ Pengaturan delay untuk setiap pesan\n"
                "• 📊 Monitoring status pengiriman\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )
        else:
            # Check if user has userbot
            userbot = await self.db.get_userbot(event.sender_id)
            
            if not userbot:
                buttons = [
                    [Button.inline("📱 Create Userbot", "create_userbot")],
                    [Button.inline("ℹ️ About Userbot", "about_userbot")]
                ]
            else:
                buttons = [
                    [Button.inline("⚙️ Settings Userbot", "settings_userbot")],
                    [Button.inline("ℹ️ About Userbot", "about_userbot")]
                ]
            
            # Add admin button if user is admin
            if event.sender_id == Config.ADMIN_ID:
                buttons.insert(0, [Button.inline("👮‍♂️ Admin Panel", "admin_panel")])

            status_text = "Active" if userbot and userbot.status == "active" else "Inactive"
            expire_text = user.expire_at.strftime('%Y-%m-%d %H:%M:%S') if user.expire_at else 'Never'

            await event.reply(
                f"👋 Selamat datang kembali!\n\n"
                f"📊 Informasi User:\n"
                f"├ Status: {user.access_type.upper()}\n"
                f"├ Userbot: {status_text}\n"
                f"└ Expire: {expire_text}\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )

    async def create_userbot_handler(self, event):
        """Handle userbot creation"""
        try:
            user = await self.db.get_user(event.sender_id)
            if not user or user.access_type not in ["admin", "premium", "premium_plus"]:
                await event.edit(
                    Config.format_error("not_authorized"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            existing_userbot = await self.db.get_userbot(event.sender_id)
            if existing_userbot:
                await event.edit(
                    Config.format_error("userbot_exists"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            self.otp_attempts[event.sender_id] = 0

            await event.edit(
                "📱 Kirim nomor telepon dalam format internasional\n"
                "Contoh: +6281234567890",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            self.user_states[event.sender_id] = "waiting_phone"

        except Exception as e:
            logger.error(f"Error in create_userbot_handler: {str(e)}")
            await event.edit(
                "❌ Terjadi kesalahan. Silakan coba lagi nanti.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
  
    async def handle_phone_number(self, event):
        """Handle phone number input"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                Config.format_error("invalid_phone"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Kode telah dikirim! Masukkan kode dengan spasi.\n"
                "Contoh: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ Nomor telepon ini telah dibanned oleh Telegram!",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Terlalu banyak permintaan! Tunggu {e.seconds} detik.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_code(self, event):
        """Handle OTP code input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            await event.reply(Config.format_error("invalid_otp"))
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)
            
            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return
                
            await event.reply("❌ Kode OTP salah! Silakan coba lagi.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa"
            await event.reply(
                "🔐 Akun ini menggunakan Two-Factor Authentication.\n"
                "Silakan masukkan password 2FA Anda:",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)

            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Password 2FA salah! Silakan coba lagi.")
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def about_handler(self, event):
        """Handle about section"""
        text = (
            "ℹ️ About Userbot\n\n"
            "🔸 Userbot adalah bot yang berjalan di akun Telegram Anda\n"
            "🔸 Dapat mengirim pesan ke banyak grup secara otomatis\n"
            "🔸 Support berbagai jenis media dan format:\n"
            "  • Foto, Video, GIF, Sticker\n"
            "  • File dan Dokumen\n" 
            "  • Emoji Premium & Regular\n"
            "  • Format teks (bold, italic, dll)\n\n"
            "Fitur Premium:\n"
            "✨ Emoji Premium\n"
            "✨ Broadcast tanpa watermark\n"
            "✨ Priority support\n\n"
            "Creator: @hiyaok"
        )
        await event.edit(text, buttons=[[Button.inline("🔙 Back", "start")]])

    async def settings_handler(self, event):
        """Handle userbot settings"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!\n"
                "Silakan buat userbot terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        messages = await self.db.get_messages(event.sender_id) 
        groups = await self.db.get_groups(event.sender_id)

        buttons = [
            [Button.inline("📊 Status Bot", "status"), 
             Button.inline("📝 List Pesan", "check_lists")],
            [Button.inline("➕ Tambah Pesan", "add_list"),
             Button.inline("⏱️ Atur Delay", "set_delay")],
            [Button.inline("👥 Tambah Grup", "add_groups"),
             Button.inline("📋 List Grup", "list_groups")],
            [Button.inline("🗑️ Hapus Grup", "delete_group"),
             Button.inline("❌ Hapus Pesan", "delete_list")],
            [Button.inline("📥 Grup Joined", "joined_groups"),
             Button.inline("📨 Kirim RC", "send_rc")],
            [Button.inline("🔙 Kembali", "start")]
        ]
        
        msg_count = len(messages) if messages else 0
        grp_count = len(groups) if groups else 0
        status_text = "🟢 Active" if userbot.status == "active" else "🔴 Inactive"
        
        await event.edit(
            f"⚙️ Pengaturan Userbot\n\n"
            f"Status: {status_text}\n"
            f"List Pesan: {msg_count} pesan\n"
            f"List Grup: {grp_count} grup\n\n"
            f"Pilih menu di bawah:",
            buttons=buttons
        )

    async def check_lists_handler(self, event):
        try:
            messages = await self.db.get_messages(event.sender_id)
            
            if not messages:
                await event.edit(
                    "📝 Belum ada pesan yang ditambahkan.",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            text = "📋 Daftar Pesan:\n\n"
            for i, msg in enumerate(messages, 1):
                text += f"📌 Pesan #{i}\n"
                text += "➖➖➖➖➖➖➖➖\n"
                
                if msg.text:
                    preview = msg.text[:150] + "..." if len(msg.text) > 150 else msg.text
                    text += f"📜 Text: {preview}\n"
                
                if msg.media:
                    media_type = msg.media_type.upper() if msg.media_type else "MEDIA"
                    text += f"📎 {media_type}\n"
                    
                    if msg.caption:
                        caption_preview = msg.caption[:150] + "..." if len(msg.caption) > 150 else msg.caption
                        text += f"📝 Caption: {caption_preview}\n"
                
                text += f"⏱️ Delay: {msg.delay} detik\n"
                text += "➖➖➖➖➖➖➖➖\n\n"

            # Split long messages
            if len(text) > 4096:
                texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
                for i, chunk in enumerate(texts):
                    if i == len(texts)-1:
                        await event.edit(chunk, buttons=[[Button.inline("🔙 Back", b"settings_userbot")]])
                    else:
                        await event.respond(chunk)
            else:
                await event.edit(text, buttons=[[Button.inline("🔙 Back", b"settings_userbot")]])

        except Exception as e:
            logger.error(f"Error in check_lists_handler: {str(e)}")
            await event.edit(
                f"❌ Error mendapatkan daftar pesan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def add_list_handler(self, event):
        await event.edit(
            "📝 Kirim pesan yang ingin ditambahkan:\n\n"
            "Support format:\n"
            "• Teks standar & format Telegram:\n"
            "  - Bold: **teks** atau __teks__\n"
            "  - Italic: *teks* atau _teks_\n"
            "  - Underline: __teks__\n"
            "  - Strike: ~~teks~~\n"
            "  - Spoiler: ||teks||\n"
            "  - Code: `teks`\n"
            "  - Pre: ```teks```\n"
            "  - Quote: > teks\n"
            "  - Mention: @username\n"
            "  - Link: [teks](url)\n"
            "• Emoji premium & regular ✨\n"
            "• Media dengan/tanpa caption:\n"
            "  - Foto (JPG/PNG)\n"
            "  - Video (MP4/etc)\n" 
            "  - GIF animasi\n"
            "  - Sticker\n"
            "  - File & dokumen\n"
            "• Support teks dari copy-paste\n"
            "• Support pesan forward\n\n"
            "Setelah mengirim pesan, Anda akan diminta mengatur durasi delay.",
            buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
        )
        self.user_states[event.sender_id] = {
            "state": "waiting_message"
        }

    async def handle_new_message(self, event):
        if event.sender_id not in self.user_states:
            return

        try:
            user_data = await self.db.get_user(event.sender_id)
            message = event.message
            
            msg_data = {
                'text': None,
                'media': None,
                'media_type': None,
                'caption': None,
                'entities': None,
                'caption_entities': None
            }

            # Handle media messages
            if message.media:
                try:
                    # Store media object directly
                    msg_data['media'] = message.media
                    
                    # Get media type
                    if hasattr(message.media, 'photo'):
                        msg_data['media_type'] = 'photo'
                    elif hasattr(message.media, 'document'):
                        doc = message.media.document
                        mime_type = getattr(doc, 'mime_type', '')
                        
                        if mime_type:
                            if mime_type.startswith('video'):
                                msg_data['media_type'] = 'video'
                            elif mime_type.startswith('image'):
                                msg_data['media_type'] = 'gif' if mime_type == 'image/gif' else 'photo'
                            elif mime_type.startswith('audio'):
                                msg_data['media_type'] = 'audio'
                            else:
                                msg_data['media_type'] = 'document'
                        else:
                            msg_data['media_type'] = 'document'
                    else:
                        msg_data['media_type'] = 'media'

                    # Handle caption
                    if message.raw_text:
                        msg_data['caption'] = message.raw_text
                        
                        # Handle caption formatting
                        if message.entities:
                            entities = []
                            for entity in message.entities:
                                entity_data = {
                                    'offset': entity.offset,
                                    'length': entity.length,
                                    '_type': entity._type
                                }
                                
                                # Handle different entity types
                                if hasattr(entity, 'url'):
                                    entity_data['url'] = entity.url
                                if hasattr(entity, 'user_id'):
                                    entity_data['user_id'] = entity.user_id
                                if hasattr(entity, 'language'):
                                    entity_data['language'] = entity.language
                                if hasattr(entity, 'document_id'):
                                    entity_data['document_id'] = entity.document_id
                                    
                                entities.append(entity_data)
                            
                            msg_data['caption_entities'] = entities

                except Exception as e:
                    logger.error(f"Error processing media: {str(e)}")
                    raise Exception(f"Error processing media: {str(e)}")

            # Handle text messages
            else:
                msg_data['text'] = message.raw_text
                
                if message.entities:
                    entities = []
                    for entity in message.entities:
                        entity_data = {
                            'offset': entity.offset,
                            'length': entity.length,
                            '_type': entity._type
                        }
                        
                        # Handle different entity types
                        if hasattr(entity, 'url'):
                            entity_data['url'] = entity.url
                        if hasattr(entity, 'user_id'):
                            entity_data['user_id'] = entity.user_id
                        if hasattr(entity, 'language'):
                            entity_data['language'] = entity.language
                        if hasattr(entity, 'document_id'):
                            entity_data['document_id'] = entity.document_id
                            
                        entities.append(entity_data)
                    
                    msg_data['entities'] = entities

            # Store in user state
            self.user_states[event.sender_id].update({
                "state": "waiting_delay",
                "message_data": msg_data
            })

            # Create preview message
            preview_text = "✨ Pesan berhasil diterima!\n\n"
            preview_text += "📝 Preview:\n"
            preview_text += "➖➖➖➖➖➖➖➖\n"
            
            if msg_data['media']:
                preview_text += f"📎 Type: {msg_data['media_type'].upper()}\n"
                if msg_data['caption']:
                    caption_preview = msg_data['caption'][:150] + "..." if len(msg_data['caption']) > 150 else msg_data['caption']
                    preview_text += f"📝 Caption: {caption_preview}\n"
            else:
                text_preview = msg_data['text'][:150] + "..." if len(msg_data['text']) > 150 else msg_data['text']
                preview_text += f"📜 Text: {text_preview}\n"
            
            preview_text += "➖➖➖➖➖➖➖➖\n\n"
            preview_text += "⏱️ Silakan masukkan durasi delay (dalam detik):\n"
            preview_text += "Contoh: 60"

            await event.reply(
                preview_text,
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

        except Exception as e:
            logger.error(f"Error in handle_new_message: {str(e)}")
            await event.reply(
                f"❌ Gagal memproses pesan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )
            if event.sender_id in self.user_states:
                del self.user_states[event.sender_id]

    async def handle_delay_input(self, event):
        if event.sender_id not in self.user_states or \
           self.user_states[event.sender_id].get("state") != "waiting_delay":
            return

        try:
            # Validate delay input
            try:
                delay = int(event.raw_text)
                if delay < 1:
                    raise ValueError("Delay harus lebih dari 0 detik")
            except ValueError:
                await event.reply(
                    "⚠️ Masukkan angka yang valid (minimal 1 detik).",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            msg_data = self.user_states[event.sender_id]["message_data"]
            user_data = await self.db.get_user(event.sender_id)
            
            # Add watermark for premium users
            if user_data.access_type == "premium":
                watermark = f"\n\n{Config.WATERMARK}"
                if msg_data.get('text'):
                    msg_data['text'] += watermark
                elif msg_data.get('caption'):
                    msg_data['caption'] += watermark

            # Add delay to message data
            msg_data['delay'] = delay

            # Save message to database
            await self.db.add_message(event.sender_id, msg_data)

            # Create confirmation message
            confirm_text = "✅ Pesan berhasil disimpan!\n\n"
            confirm_text += "📝 Detail Pesan:\n"
            confirm_text += "➖➖➖➖➖➖➖➖\n"
            
            if msg_data['media']:
                confirm_text += f"📎 Type: {msg_data['media_type'].upper()}\n"
                if msg_data['caption']:
                    caption_preview = msg_data['caption'][:150] + "..." if len(msg_data['caption']) > 150 else msg_data['caption']
                    confirm_text += f"📝 Caption: {caption_preview}\n"
            else:
                text_preview = msg_data['text'][:150] + "..." if len(msg_data['text']) > 150 else msg_data['text']
                confirm_text += f"📜 Text: {text_preview}\n"
            
            confirm_text += f"⏱️ Delay: {delay} detik\n"
            confirm_text += "➖➖➖➖➖➖➖➖"

            await event.reply(
                confirm_text,
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

        except Exception as e:
            logger.error(f"Error in handle_delay_input: {str(e)}")
            error_msg = str(e) if len(str(e)) < 200 else str(e)[:200] + "..."
            await event.reply(
                f"❌ Gagal menyimpan pesan: {error_msg}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )
        finally:
            if event.sender_id in self.user_states:
                del self.user_states[event.sender_id]

    async def set_delay_handler(self, event):
        """Handle delay setting with improved display"""
        try:
            messages = await self.db.get_messages(event.sender_id)
            
            if not messages:
                await event.edit(
                    "📝 Tidak ada pesan untuk diatur delay-nya.",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return

            buttons = []
            for i, msg in enumerate(messages, 1):
                try:
                    text = f"{i}. "
                    if msg.media_type:
                        text += f"[{msg.media_type.upper()}] "
                        if msg.caption:
                            preview = msg.caption[:30]
                            if len(msg.caption) > 30:
                                preview += "..."
                            text += preview
                    else:
                        preview = msg.text[:30]
                        if len(msg.text) > 30:
                            preview += "..."
                        text += preview
                    text += f" ({msg.delay}s)"
                    buttons.append([Button.inline(text, f"set_delay_{msg.id}")])
                except Exception as e:
                    logger.error(f"Error formatting delay button for message {i}: {str(e)}")
                    buttons.append([Button.inline(f"Message {i} ({msg.delay}s)", f"set_delay_{msg.id}")])

            buttons.append([Button.inline("🔙 Back", "settings_userbot")])
            
            await event.edit(
                "⏱️ Pilih pesan yang ingin diubah delay-nya:",
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in set_delay_handler: {str(e)}")
            await event.edit(
                f"❌ Error loading messages: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def handle_delay_selection(self, event):
        """Handle message selection for delay change"""
        try:
            msg_id = int(event.data.decode().split("_")[-1])
            
            self.user_states[event.sender_id] = {
                "state": "waiting_new_delay",
                "message_id": msg_id
            }
            
            await event.edit(
                "⏱️ Masukkan delay baru dalam detik:\n\n"
                "• Minimal: 1 detik\n"
                "• Maksimal: 3600 detik (1 jam)",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            
        except Exception as e:
            logger.error(f"Error in handle_delay_selection: {str(e)}")
            await event.edit(
                f"❌ Error selecting message: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def handle_new_delay(self, event):
        """Handle new delay value input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text.strip())
            if not 1 <= delay <= 3600:
                raise ValueError("Delay harus antara 1-3600 detik")

            state_data = self.user_states[event.sender_id]
            msg_id = state_data["message_id"]

            # Update delay in database
            await self.db.update_message_delay(event.sender_id, msg_id, delay)
            
            # Get updated message for preview
            messages = await self.db.get_messages(event.sender_id)
            message = next((m for m in messages if m.id == msg_id), None)
            
            if not message:
                raise ValueError("Pesan tidak ditemukan")
            
            preview = "✅ Delay berhasil diupdate!\n\n"
            if message.media_type:
                preview += f"Tipe Pesan: {message.media_type.upper()}\n"
                if message.caption:
                    preview += f"Caption: {message.caption[:50]}...\n"
            else:
                preview += f"Text: {message.text[:50]}...\n"
            
            preview += f"Delay Baru: {delay} detik"

            await event.reply(
                preview,
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        except Exception as e:
            logger.error(f"Error updating delay: {str(e)}")
            await event.reply(
                f"❌ Error updating delay: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def delete_list_handler(self, event):
        """Handle message deletion with improved preview"""
        try:
            messages = await self.db.get_messages(event.sender_id)
            
            if not messages:
                await event.edit(
                    "📝 Tidak ada pesan yang bisa dihapus.",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return

            buttons = []
            for i, msg in enumerate(messages, 1):
                try:
                    text = f"{i}. "
                    if msg.media_type:
                        text += f"[{msg.media_type.upper()}] "
                        if msg.caption:
                            preview = msg.caption[:30]
                            if len(msg.caption) > 30:
                                preview += "..."
                            text += preview
                    else:
                        preview = msg.text[:30]
                        if len(msg.text) > 30:
                            preview += "..."
                        text += preview
                    buttons.append([Button.inline(text, f"delete_msg_{msg.id}")])
                except Exception as e:
                    logger.error(f"Error formatting delete button for message {i}: {str(e)}")
                    buttons.append([Button.inline(f"Message {i}", f"delete_msg_{msg.id}")])

            buttons.append([Button.inline("🔙 Back", "settings_userbot")])
            
            await event.edit(
                "🗑️ Pilih pesan yang ingin dihapus:",
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in delete_list_handler: {str(e)}")
            await event.edit(
                f"❌ Error loading messages: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def confirm_delete_message(self, event):
        """Handle message deletion confirmation"""
        try:
            msg_id = int(event.data.decode().split("_")[-1])
            messages = await self.db.get_messages(event.sender_id)
            message = next((m for m in messages if m.id == msg_id), None)

            if not message:
                await event.edit(
                    "❌ Pesan tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return

            buttons = [
                [Button.inline("✅ Ya, Hapus", f"confirm_delete_user_{msg_id}"),
                 Button.inline("❌ Batal", "delete_list")]
            ]

            preview = "🗑️ Hapus pesan ini?\n\n"
            if message.media_type:
                preview += f"Tipe: {message.media_type.upper()}\n"
                if message.caption:
                    preview += f"Caption: {message.caption[:50]}...\n"
            else:
                preview += f"Text: {message.text[:50]}...\n"

            await event.edit(
                preview,
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in confirm_delete_message: {str(e)}")
            await event.edit(
                f"❌ Error confirming deletion: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def final_delete_message(self, event):
        """Handle final message deletion"""
        try:
            msg_id = int(event.data.decode().split("_")[-1])
            await self.db.delete_message(event.sender_id, msg_id)
            
            await event.edit(
                "✅ Pesan berhasil dihapus!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        except Exception as e:
            logger.error(f"Error in final_delete_message: {str(e)}")
            await event.edit(
                f"❌ Error deleting message: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    # Broadcasting & RC Handlers
    async def status_handler(self, event):
        """Handle bot status activation/deactivation"""
        userbot = await self.db.get_userbot(event.sender_id)
        messages = await self.db.get_messages(event.sender_id)
        groups = await self.db.get_groups(event.sender_id)

        if not messages:
            await event.edit(
                "❌ Tidak dapat mengaktifkan bot!\n\n"
                "Anda belum memiliki list pesan.\n"
                "Silakan tambahkan pesan terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        if not groups:
            await event.edit(
                "❌ Tidak dapat mengaktifkan bot!\n\n"
                "Anda belum memiliki daftar grup.\n"
                "Silakan tambahkan grup terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        current_status = userbot.status
        new_status = "active" if current_status == "inactive" else "inactive"
        
        buttons = [
            [Button.inline(
                f"✅ {'Aktifkan' if new_status == 'active' else 'Nonaktifkan'} Bot", 
                f"confirm_status_{new_status}"
            )],
            [Button.inline("❌ Batal", "settings_userbot")]
        ]
        
        msg = (
            f"📊 Status Bot\n\n"
            f"Status saat ini: {'🟢 Active' if current_status == 'active' else '🔴 Inactive'}\n"
            f"List Pesan: {len(messages)} pesan\n"
            f"List Grup: {len(groups)} grup\n\n"
        )
        
        if new_status == "active":
            msg += (
                "⚠️ Bot akan:\n"
                "• Mengirim semua pesan ke semua grup\n"
                "• Menggunakan delay sesuai pengaturan\n"
                "• Memberikan notifikasi status pengiriman"
            )
        else:
            msg += "⚠️ Bot akan berhenti mengirim pesan"
            
        await event.edit(msg, buttons=buttons)

    async def confirm_status_handler(self, event):
        """Handle status confirmation and broadcast initialization"""
        try:
            status = event.data.decode().split("_")[-1]
            user_id = event.sender_id
            
            await self.db.update_userbot_status(user_id, status)
            
            if status == "active":
                userbot_data = await self.db.get_userbot(user_id)
                user_data = await self.db.get_user(user_id)
                
                userbot = UserBot(
                    userbot_data.session_string,
                    Config.API_ID,
                    Config.API_HASH,
                    user_data.access_type
                )
                
                await userbot.start()
                self.active_userbots[user_id] = userbot
                
                # Start broadcasting in background
                asyncio.create_task(self.handle_broadcasting(user_id))
                
                await event.edit(
                    "✅ Status berhasil diubah ke active!\n"
                    "Bot akan mulai mengirim pesan...",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
            else:
                if user_id in self.active_userbots:
                    await self.active_userbots[user_id].disconnect()
                    del self.active_userbots[user_id]
                
                await event.edit(
                    "✅ Status berhasil diubah ke inactive!\n"
                    "Bot telah berhenti mengirim pesan.",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                
        except Exception as e:
            logger.error(f"Error in confirm_status_handler: {str(e)}")
            await event.edit(
                f"❌ Error updating status: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def handle_broadcasting(self, user_id):
        if user_id not in self.active_userbots:
            return

        try:
            userbot_data = await self.db.get_userbot(user_id) 
            user_data = await self.db.get_user(user_id)
            
            # Initial delay if userbot has messages
            messages = await self.db.get_messages(user_id)
            allowed_groups = await self.db.get_allowed_groups(user_id)
            
            if not messages or not allowed_groups:
                await self.bot.send_message(
                    user_id,
                    "⚠️ Broadcasting dihentikan:\n"
                    "Tidak ada pesan atau grup yang terdaftar dalam daftar allowed groups.",
                    buttons=[[Button.inline("🔙 Settings", b"settings_userbot")]]
                )
                await self.stop_userbot(user_id)
                return

            await self.bot.send_message(
                user_id,
                f"🚀 Memulai broadcast dengan {len(messages)} pesan ke {len(allowed_groups)} grup...\n"
                "Menunggu 5 detik sebelum mulai broadcast..."
            )
            await asyncio.sleep(5)

            status_msg = await self.bot.send_message(
                user_id,
                "📤 Memulai proses broadcasting..."
            )

            async with TelegramClient(
                StringSession(userbot_data.session_string),
                userbot_data.app_id or Config.API_ID,
                userbot_data.app_hash or Config.API_HASH
            ) as client:
                while user_id in self.active_userbots:
                    # Refresh messages and groups data
                    messages = await self.db.get_messages(user_id)
                    allowed_groups = await self.db.get_allowed_groups(user_id)

                    # Process each message
                    for msg_index, message in enumerate(messages, 1):
                        if user_id not in self.active_userbots:
                            break

                        # Create message preview
                        msg_preview = message.text[:50] + "..." if message.text else "" 
                        if message.media:
                            msg_preview = f"[{message.media_type.upper()}] "
                            if message.caption:
                                msg_preview += message.caption[:50] + "..."

                        success_count = 0
                        failed_count = 0
                        error_groups = []

                        await status_msg.edit(
                            f"📤 Mengirim pesan {msg_index}/{len(messages)} ke semua grup\n"
                            f"Preview: {msg_preview}\n"
                            f"Delay: {message.delay} detik"
                        )

                        # Send to all allowed groups
                        for group_index, group in enumerate(allowed_groups, 1):
                            if user_id not in self.active_userbots:
                                break

                            try:
                                # Prepare message data
                                msg_data = {
                                    'text': message.text,
                                    'media': message.media,
                                    'caption': message.caption,
                                    'entities': message.entities,
                                    'caption_entities': message.caption_entities
                                }

                                # Add watermark for premium users
                                if user_data.access_type == "premium":
                                    watermark = f"\n\n{Config.WATERMARK}"
                                    if msg_data['text']:
                                        msg_data['text'] += watermark
                                    elif msg_data['caption']:
                                        msg_data['caption'] += watermark

                                # Send message based on type
                                if msg_data['media']:
                                    file_data = msg_data['media'].get('file', None)
                                    if not file_data:
                                        raise Exception("Media data not found")

                                    await client.send_file(
                                        group.group_id,
                                        file=file_data,
                                        caption=msg_data['caption'],
                                        parse_mode='html',
                                        formatting_entities=msg_data['caption_entities'],
                                        allow_cache=False,
                                        silent=True
                                    )
                                else:
                                    await client.send_message(
                                        group.group_id,
                                        msg_data['text'],
                                        parse_mode='html',
                                        formatting_entities=msg_data['entities'],
                                        link_preview=True,
                                        silent=True
                                    )

                                # Log success
                                await self.db.log_broadcast(
                                    user_id=user_id,
                                    message_id=message.id,
                                    group_id=group.group_id,
                                    status="success"
                                )
                                await self.db.update_broadcast_stats(
                                    user_id=user_id,
                                    group_id=group.group_id,
                                    success=True
                                )
                                success_count += 1

                            except Exception as e:
                                error_msg = str(e)
                                logger.error(f"Broadcasting error to group {group.title}: {error_msg}")
                                
                                # Log failure
                                await self.db.log_broadcast(
                                    user_id=user_id,
                                    message_id=message.id,
                                    group_id=group.group_id,
                                    status="failed",
                                    error_message=error_msg
                                )
                                await self.db.update_broadcast_stats(
                                    user_id=user_id,
                                    group_id=group.group_id,
                                    success=False
                                )
                                failed_count += 1
                                error_groups.append({
                                    'title': group.title,
                                    'error': error_msg
                                })

                            # Update progress every 3 groups
                            if group_index % 3 == 0 or group_index == len(allowed_groups):
                                progress = (
                                    f"📤 Mengirim pesan {msg_index}/{len(messages)}\n"
                                    f"Preview: {msg_preview}\n"
                                    f"Progress: {group_index}/{len(allowed_groups)}\n"
                                    f"✅ Berhasil: {success_count}\n"
                                    f"❌ Gagal: {failed_count}"
                                )
                                await status_msg.edit(progress)

                            await asyncio.sleep(2)  # Small delay between group sends

                        # Send summary for this message
                        summary = (
                            f"📋 Status Pengiriman - Pesan {msg_index}/{len(messages)}\n"
                            f"Preview: {msg_preview}\n\n"
                            f"📊 Statistik:\n"
                            f"✅ Berhasil: {success_count}\n"
                            f"❌ Gagal: {failed_count}\n"
                            f"📱 Total Grup: {len(allowed_groups)}\n"
                        )
                        
                        if error_groups:
                            summary += "\n❌ Detail Kegagalan:\n"
                            for g in error_groups[:5]:
                                error_preview = g['error'][:100] + "..." if len(g['error']) > 100 else g['error']
                                summary += f"• {g['title']}: {error_preview}\n"
                            if len(error_groups) > 5:
                                summary += f"...dan {len(error_groups) - 5} grup lainnya\n"

                        await self.bot.send_message(user_id, summary)

                        # Wait for configured delay before next message
                        if msg_index < len(messages):
                            await status_msg.edit(
                                f"⏳ Menunggu {message.delay} detik sebelum mengirim pesan berikutnya..."
                            )
                            await asyncio.sleep(message.delay)
                        else:
                            await status_msg.edit(
                                f"⏳ Menunggu {message.delay} detik sebelum memulai siklus baru..."
                            )
                            await asyncio.sleep(message.delay)

                        # Update message last used timestamp
                        await self.db.update_message_last_used(message.id)

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Broadcasting error: {error_msg}")
            
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
                
            await self.bot.send_message(
                user_id,
                f"❌ Error dalam broadcasting: {error_msg}",
                buttons=[[Button.inline("🔙 Settings", b"settings_userbot")]]
            )
            await self.stop_userbot(user_id)

    async def stop_userbot(self, user_id):
        """Safely stop userbot and clean up"""
        try:
            if user_id in self.active_userbots:
                await self.db.update_userbot_status(user_id, "inactive")
                await self.active_userbots[user_id].disconnect()
                del self.active_userbots[user_id]
        except Exception as e:
            logger.error(f"Error stopping userbot {user_id}: {str(e)}")

    async def send_rc_handler(self, event):
        await event.edit(
            "📨 Kirim pesan yang ingin disebarkan ke recent chats:\n\n"
            "Support format:\n"
            "• Teks biasa dan format Telegram:\n"
            "  - Bold: **teks** atau __teks__\n"
            "  - Italic: *teks* atau _teks_\n"
            "  - Underline: __teks__\n"
            "  - Strike: ~~teks~~\n"
            "  - Spoiler: ||teks||\n"
            "  - Code: `teks`\n"
            "  - Pre: ```teks```\n"
            "  - Quote: > teks\n"
            "  - Mention: @username\n"
            "  - Link: [teks](url)\n"
            "• Emoji premium & regular ✨\n"
            "• Media dengan caption (foto/video/gif/sticker)\n"
            "• File & dokumen dengan caption\n\n"
            "Kirim pesan/media yang ingin disebarkan:",
            buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_rc_message"

    async def handle_rc_message(self, event):
        if event.sender_id not in self.user_states:
            return

        try:
            userbot_data = await self.db.get_userbot(event.sender_id)
            user_data = await self.db.get_user(event.sender_id)

            if not userbot_data or not userbot_data.session_string:
                await event.reply(
                    "❌ Userbot tidak ditemukan atau sesi tidak valid!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            message = event.message
            formatted_message = {
                'text': message.text if message.text else None,
                'media': None,
                'caption': message.raw_text if message.raw_text and message.media else None,
                'entities': message.entities if hasattr(message, 'entities') else None,
                'file': None
            }

            if message.media:
                try:
                    # Store the media directly without downloading
                    formatted_message['media'] = message.media
                    formatted_message['file'] = message.media

                except Exception as e:
                    logger.error(f"Failed handling media: {str(e)}")
                    await event.reply(
                        f"❌ Terjadi kesalahan saat memproses media: {str(e)}",
                        buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                    )
                    return

            if user_data.access_type == "premium":
                watermark = f"\n\n{Config.WATERMARK}"
                if formatted_message['text']:
                    formatted_message['text'] += watermark
                elif formatted_message['caption']:
                    formatted_message['caption'] += watermark

            progress_msg = await event.reply("📤 Mengambil daftar recent private chats...")

            async with TelegramClient(
                StringSession(userbot_data.session_string),
                userbot_data.app_id or Config.API_ID,
                userbot_data.app_hash or Config.API_HASH
            ) as client:
                try:
                    recent_chats = []
                    async for dialog in client.iter_dialogs():
                        if dialog.entity and isinstance(dialog.entity, User) and not dialog.entity.bot:
                            recent_chats.append({
                                'id': dialog.id,
                                'name': dialog.name or "Unknown",
                                'username': getattr(dialog.entity, 'username', None),
                                'last_message_date': dialog.date
                            })

                    recent_chats.sort(key=lambda x: x['last_message_date'], reverse=True)

                    if not recent_chats:
                        await progress_msg.edit(
                            "❌ Tidak ada recent private chats yang ditemukan!",
                            buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                        )
                        return

                    success_count = 0
                    fail_count = 0
                    failed_chats = []

                    total = len(recent_chats)
                    for i, chat in enumerate(recent_chats, 1):
                        try:
                            if formatted_message['media']:
                                # Forward the media directly
                                await client.send_file(
                                    chat['id'],
                                    file=formatted_message['file'],
                                    caption=formatted_message['caption'],
                                    parse_mode='html',
                                    formatting_entities=formatted_message['entities'],
                                    supports_streaming=True
                                )
                            else:
                                await client.send_message(
                                    chat['id'],
                                    formatted_message['text'],
                                    parse_mode='html',
                                    formatting_entities=formatted_message['entities'],
                                    link_preview=True
                                )
                            success_count += 1
                            
                            if i % 3 == 0 or i == total:
                                await progress_msg.edit(
                                    f"📤 Mengirim ke recent chats...\n\n"
                                    f"Progress: {i}/{total}\n"
                                    f"✅ Berhasil: {success_count}\n"
                                    f"❌ Gagal: {fail_count}"
                                )

                        except Exception as e:
                            logger.error(f"Failed to send to {chat['name']}: {str(e)}")
                            fail_count += 1
                            failed_chats.append({
                                'name': chat['name'],
                                'username': chat['username'],
                                'error': str(e)
                            })

                        await asyncio.sleep(2)

                    report = (
                        "📊 Hasil Pengiriman RC:\n\n"
                        f"Total chat: {total}\n"
                        f"✅ Berhasil: {success_count}\n"
                        f"❌ Gagal: {fail_count}\n\n"
                    )

                    if failed_chats:
                        report += "Chat yang gagal:\n"
                        for chat in failed_chats[:10]:
                            chat_info = chat['name']
                            if chat['username']:
                                chat_info += f" (@{chat['username']})"
                            report += f"• {chat_info}\n  Error: {chat['error'][:50]}...\n"
                        if len(failed_chats) > 10:
                            report += f"...dan {len(failed_chats) - 10} lainnya"

                    await progress_msg.edit(
                        report,
                        buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                    )

                except Exception as e:
                    logger.error(f"Error during RC send: {str(e)}")
                    await progress_msg.edit(
                        f"❌ Terjadi kesalahan saat broadcast: {str(e)}",
                        buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                    )

        except Exception as e:
            logger.error(f"Error in handle_rc_message: {str(e)}")
            await event.reply(
                "❌ Gagal menginisialisasi userbot. Pastikan sesi masih valid.",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

        finally:
            if event.sender_id in self.user_states:
                del self.user_states[event.sender_id]

    async def list_groups_handler(self, event):
        try:
            groups = await self.db.get_groups(event.sender_id)

            if not groups:
                await event.edit(
                    "👥 Belum ada grup yang ditambahkan.",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            text = "📋 List Grup:\n\n"
            for i, group in enumerate(groups, 1):
                text += f"{i}. {group.title}"
                if group.username:
                    text += f" (@{group.username})"
                text += f"\nID: {group.group_id}"
                if group.member_count:
                    text += f"\nMember: {group.member_count:,}"
                text += "\n\n"

            # Split long messages
            if len(text) > 4096:
                texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
                for i, chunk in enumerate(texts):
                    if i == len(texts)-1:
                        await event.edit(chunk, buttons=[[Button.inline("🔙 Back", b"settings_userbot")]])
                    else:
                        await event.respond(chunk)
            else:
                await event.edit(text, buttons=[[Button.inline("🔙 Back", b"settings_userbot")]])

        except Exception as e:
            logger.error(f"Error in list_groups_handler: {str(e)}")
            await event.edit(
                f"❌ Error mendapatkan list grup: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def joined_groups_handler(self, event):
        try:
            userbot = await self.db.get_userbot(event.sender_id)
            if not userbot:
                await event.edit(
                    "❌ Anda belum memiliki userbot!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            progress_msg = await event.edit("🔄 Scanning joined groups...")
            
            async with TelegramClient(
                StringSession(userbot.session_string),
                userbot.app_id or Config.API_ID,
                userbot.app_hash or Config.API_HASH
            ) as client:
                joined_groups = []
                dialogs = await client.get_dialogs()
                
                for dialog in dialogs:
                    # Check if it's a group and not a channel
                    if getattr(dialog, 'is_group', False) and not getattr(dialog, 'is_channel', False):
                        try:
                            # Get group info safely
                            group_info = {
                                'id': getattr(dialog, 'id', 0),
                                'title': getattr(dialog, 'title', 'Unknown Group'),
                                'username': getattr(dialog.entity, 'username', None) if hasattr(dialog, 'entity') else None,
                                'unread_count': getattr(dialog, 'unread_count', 0)
                            }

                            # Get additional attributes safely
                            if hasattr(dialog, 'entity'):
                                group_info['members_count'] = getattr(dialog.entity, 'participants_count', 'N/A')
                                join_date = getattr(dialog.entity, 'date', None)
                                group_info['join_date'] = join_date.strftime('%Y-%m-%d %H:%M:%S') if join_date else 'N/A'
                            else:
                                group_info['members_count'] = 'N/A'
                                group_info['join_date'] = 'N/A'

                            # Try to get admin status
                            try:
                                permissions = await client.get_permissions(dialog)
                                group_info['is_admin'] = permissions.is_admin if permissions else False
                            except:
                                group_info['is_admin'] = False

                            # Add to database
                            await self.db.add_group(event.sender_id, {
                                'id': group_info['id'],
                                'title': group_info['title'],
                                'username': group_info['username'],
                                'member_count': group_info['members_count'],
                                'is_channel': False
                            })
                            
                            joined_groups.append(group_info)
                            
                        except Exception as e:
                            logger.error(f"Error getting info for group {getattr(dialog, 'id', 'Unknown')}: {str(e)}")
                            continue

                if not joined_groups:
                    await event.edit(
                        "📥 Userbot belum join ke grup manapun.",
                        buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                    )
                    return

                # Sort by title
                joined_groups.sort(key=lambda x: x['title'].lower())
                
                text = "📥 Daftar Grup yang Di-Join:\n\n"
                for i, group in enumerate(joined_groups, 1):
                    text += f"{i}. {group['title']}\n"
                    if group['username']:
                        text += f"   ├ @{group['username']}\n"
                    text += f"   ├ ID: {group['id']}\n"
                    text += f"   ├ Members: {group['members_count']}\n"
                    text += f"   ├ Join Date: {group['join_date']}\n"
                    text += f"   ├ Admin: {'✅' if group['is_admin'] else '❌'}\n"
                    if group['unread_count'] > 0:
                        text += f"   └ Unread: {group['unread_count']} messages\n\n"
                    else:
                        text += f"   └ No unread messages\n\n"

                if len(text) > 4096:
                    texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
                    for i, msg_text in enumerate(texts):
                        if i == len(texts)-1:
                            await event.edit(
                                msg_text,
                                buttons=[
                                    [Button.inline("🔄 Refresh", b"joined_groups")],
                                    [Button.inline("🔙 Back", b"settings_userbot")]
                                ]
                            )
                        else:
                            await event.respond(msg_text)
                else:
                    await event.edit(
                        text,
                        buttons=[
                            [Button.inline("🔄 Refresh", b"joined_groups")],
                            [Button.inline("🔙 Back", b"settings_userbot")]
                        ]
                    )

        except Exception as e:
            logger.error(f"Error in joined_groups_handler: {str(e)}")
            error_msg = f"❌ Terjadi kesalahan: {str(e)}"
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
                
            await event.edit(
                error_msg,
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def add_groups_handler(self, event):
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )
            return

        buttons = [
            [Button.inline("✅ Add Semua Grup", b"add_all_groups")],
            [Button.inline("👥 Add Custom Grup", b"custom_add_groups")],
            [Button.inline("🔙 Back", b"settings_userbot")]
        ]

        await event.edit(
            "👥 Pilih metode penambahan grup:\n\n"
            "• Add Semua Grup: Menambahkan semua grup yang di-join\n"
            "• Add Custom Grup: Pilih grup spesifik dengan username",
            buttons=buttons
        )

    async def add_all_groups_handler(self, event):
        try:
            # Get userbot data
            userbot = await self.db.get_userbot(event.sender_id)
            if not userbot:
                await event.edit(
                    "❌ Userbot tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            progress_msg = await event.edit("🔄 Scanning joined groups...")

            async with TelegramClient(
                StringSession(userbot.session_string),
                userbot.app_id or Config.API_ID,
                userbot.app_hash or Config.API_HASH
            ) as client:
                added_count = 0
                skipped_count = 0
                total_groups = 0

                # Get existing groups
                existing_groups = await self.db.get_groups(event.sender_id)
                existing_ids = {g.group_id for g in existing_groups}

                async for dialog in client.iter_dialogs():
                    # Only process groups, skip channels
                    if dialog.is_group and not dialog.is_channel:
                        total_groups += 1
                        
                        if dialog.id in existing_ids:
                            skipped_count += 1
                            continue

                        try:
                            entity = await client.get_entity(dialog.id)
                            group_data = {
                                'id': dialog.id,
                                'title': dialog.title,
                                'username': getattr(entity, 'username', None),
                                'member_count': getattr(entity, 'participants_count', 0),
                                'is_channel': False
                            }
                            
                            await self.db.add_group(event.sender_id, group_data)
                            added_count += 1

                            if (added_count + skipped_count) % 5 == 0:
                                await progress_msg.edit(
                                    f"🔄 Menambahkan grup...\n\n"
                                    f"✅ Berhasil: {added_count}\n"
                                    f"⏭️ Dilewati: {skipped_count}\n"
                                    f"Total groups scanned: {added_count + skipped_count}"
                                )

                        except Exception as e:
                            logger.error(f"Error adding group {dialog.id}: {str(e)}")
                            continue

                report = (
                    "📊 Hasil Penambahan Grup:\n\n"
                    f"✅ Berhasil ditambahkan: {added_count}\n"
                    f"⏭️ Sudah ada dalam list: {skipped_count}\n"
                    f"Total grup diproses: {total_groups}"
                )

                await progress_msg.edit(
                    report,
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )

        except Exception as e:
            logger.error(f"Error in add_all_groups_handler: {str(e)}")
            await event.edit(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def custom_add_groups_handler(self, event):
        await event.edit(
            "👥 Masukkan username atau ID grup yang ingin ditambahkan\n\n"
            "Format:\n"
            "• Single: @groupname atau -100123456789\n" 
            "• Multiple: @group1, -100123456789, @group3\n\n"
            "Note: \n"
            "• Hanya grup yang di-join userbot yang bisa ditambahkan\n"
            "• Pastikan format ID grup benar (-100xxxxxxxxx)\n"
            "• Channel tidak bisa ditambahkan",
            buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_group_usernames"

    async def handle_group_usernames(self, event):
        if event.sender_id not in self.user_states:
            return

        try:
            userbot = await self.db.get_userbot(event.sender_id)
            if not userbot:
                await event.reply(
                    "❌ Userbot tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            progress_msg = await event.reply("🔄 Memproses input...")

            # Split and clean input
            inputs = [x.strip() for x in event.text.split(',')]
            usernames = []
            group_ids = []

            for item in inputs:
                if item.startswith('@'):
                    usernames.append(item[1:])
                elif item.startswith('-100'):
                    try:
                        group_ids.append(int(item))
                    except ValueError:
                        continue
                elif item.isdigit():
                    group_ids.append(int(f"-100{item}"))

            results = {
                'success': [],
                'already': [],
                'not_found': [],
                'not_joined': [],
                'is_channel': []
            }

            existing_groups = await self.db.get_groups(event.sender_id)
            existing_ids = {g.group_id for g in existing_groups}

            async with TelegramClient(
                StringSession(userbot.session_string),
                userbot.app_id or Config.API_ID,
                userbot.app_hash or Config.API_HASH
            ) as client:
                # Process usernames
                for username in usernames:
                    try:
                        entity = await client.get_entity(username)
                        
                        # Skip if it's a channel
                        if getattr(entity, 'broadcast', False):
                            results['is_channel'].append(f"@{username}")
                            continue

                        # Check if bot is member
                        try:
                            await client.get_permissions(entity)
                        except:
                            results['not_joined'].append(f"@{username}")
                            continue

                        if entity.id in existing_ids:
                            results['already'].append(entity.title)
                            continue

                        group_data = {
                            'id': entity.id,
                            'title': entity.title,
                            'username': username,
                            'member_count': getattr(entity, 'participants_count', 0),
                            'is_channel': False
                        }
                        
                        await self.db.add_group(event.sender_id, group_data)
                        results['success'].append(entity.title)

                    except ValueError:
                        results['not_found'].append(f"@{username}")
                    except Exception as e:
                        logger.error(f"Error processing @{username}: {str(e)}")
                        results['not_found'].append(f"@{username}")

                # Process group IDs
                for group_id in group_ids:
                    try:
                        entity = await client.get_entity(group_id)
                        
                        # Skip if it's a channel
                        if getattr(entity, 'broadcast', False):
                            results['is_channel'].append(str(group_id))
                            continue

                        # Check if bot is member
                        try:
                            await client.get_permissions(entity)
                        except:
                            results['not_joined'].append(str(group_id))
                            continue

                        if entity.id in existing_ids:
                            results['already'].append(entity.title)
                            continue

                        group_data = {
                            'id': entity.id,
                            'title': entity.title,
                            'username': getattr(entity, 'username', None),
                            'member_count': getattr(entity, 'participants_count', 0),
                            'is_channel': False
                        }
                        
                        await self.db.add_group(event.sender_id, group_data)
                        results['success'].append(entity.title)

                    except ValueError:
                        results['not_found'].append(str(group_id))
                    except Exception as e:
                        logger.error(f"Error processing ID {group_id}: {str(e)}")
                        results['not_found'].append(str(group_id))

            # Generate report
            report = "📊 Hasil Penambahan Grup:\n\n"
            
            if results['success']:
                report += "✅ Berhasil ditambahkan:\n"
                for name in results['success']:
                    report += f"• {name}\n"
                report += "\n"
            
            if results['already']:
                report += "⏭️ Sudah ada dalam list:\n"
                for name in results['already']:
                    report += f"• {name}\n"
                report += "\n"
            
            if results['not_joined']:
                report += "❌ Userbot belum join:\n"
                for item in results['not_joined']:
                    report += f"• {item}\n"
                report += "\n"

            if results['is_channel']:
                report += "⚠️ Channel tidak dapat ditambahkan:\n"
                for item in results['is_channel']:
                    report += f"• {item}\n"
                report += "\n"
            
            if results['not_found']:
                report += "❓ Tidak ditemukan:\n"
                for item in results['not_found']:
                    report += f"• {item}\n"

            await progress_msg.edit(
                report,
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

        except Exception as e:
            logger.error(f"Error in handle_group_usernames: {str(e)}")
            error_msg = f"❌ Terjadi kesalahan: {str(e)}"
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
            
            await event.reply(
                error_msg,
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

        finally:
            if event.sender_id in self.user_states:
                del self.user_states[event.sender_id]

    async def delete_group_handler(self, event):
        try:
            groups = await self.db.get_groups(event.sender_id)

            if not groups:
                await event.edit(
                    "👥 Tidak ada grup yang bisa dihapus.",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            buttons = []
            for i, group in enumerate(groups, 1):
                text = f"{i}. {group.title}"
                if group.username:
                    text += f" (@{group.username})"
                buttons.append([Button.inline(text, f"delete_group_{group.group_id}".encode())])

            buttons.append([Button.inline("🔙 Back", b"settings_userbot")])

            await event.edit(
                "🗑️ Pilih grup yang ingin dihapus:",
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in delete_group_handler: {str(e)}")
            await event.edit(
                f"❌ Error loading groups: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def confirm_delete_group(self, event):
        try:
            group_id = int(event.data.decode().split("_")[-1])
            groups = await self.db.get_groups(event.sender_id)
            group = next((g for g in groups if g.group_id == group_id), None)
            
            if not group:
                await event.edit(
                    "❌ Grup tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return
                
            buttons = [
                [Button.inline("✅ Ya, Hapus", f"final_delete_group_{group_id}".encode()),
                 Button.inline("❌ Batal", b"delete_group")]
            ]
            
            await event.edit(
                f"⚠️ Hapus grup ini?\n\n"
                f"Grup: {group.title}\n"
                f"{'Username: @' + group.username if group.username else ''}\n"
                f"ID: {group.group_id}\n\n"
                "Grup yang dihapus tidak akan menerima broadcast.",
                buttons=buttons
            )
            
        except Exception as e:
            logger.error(f"Error in confirm_delete_group: {str(e)}")
            await event.edit(
                f"❌ Failed to process request: {str(e)}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def final_delete_group(self, event):
        try:
            group_id = int(event.data.decode().split("_")[-1])
            groups = await self.db.get_groups(event.sender_id)
            group = next((g for g in groups if g.group_id == group_id), None)
            
            if not group:
                await event.edit(
                    "❌ Grup tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
                )
                return

            # Get group title before deletion
            group_title = group.title

            # Update group status to 'deleted' in database
            try:
                await self.db.update_group_status(event.sender_id, group_id, 'deleted')
            except AttributeError:
                # If update_group_status doesn't exist, try using remove_allowed_group
                await self.db.remove_allowed_group(event.sender_id, group_id)
            
            await event.edit(
                f"✅ Grup berhasil dihapus!\n\n"
                f"Grup: {group_title}\n"
                f"ID: {group_id}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )
            
        except Exception as e:
            logger.error(f"Error in final_delete_group: {str(e)}")
            error_msg = str(e)
            if len(error_msg) > 200:
                error_msg = error_msg[:200] + "..."
            await event.edit(
                f"❌ Gagal menghapus grup: {error_msg}",
                buttons=[[Button.inline("🔙 Back", b"settings_userbot")]]
            )

    async def validate_group(self, client, group_id: int) -> dict:
        """Validate and get group info compatible with database schema"""
        try:
            group_entity = await client.get_entity(group_id)
            return {
                'group_id': group_id,
                'title': group_entity.title,
                'username': getattr(group_entity, 'username', None),
                'member_count': getattr(group_entity, 'participants_count', 0),
                'is_channel': hasattr(group_entity, 'broadcast'),
                'status': 'active',
                'join_date': datetime.now()
            }
        except Exception as e:
            logger.error(f"Error validating group {group_id}: {str(e)}")
            raise