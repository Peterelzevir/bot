# user handlers
from telethon import events, Button, TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, MessageMediaPhoto, MessageMediaDocument
from telethon.errors import *
from database.database import Database
from config import Config
from userbot.client import UserBot
import asyncio
import logging
import re
from datetime import datetime

logger = logging.getLogger(__name__)

class UserHandlers:
    def __init__(self, bot: TelegramClient, db: Database):
        self.bot = bot
        self.db = db
        self.user_states = {}
        self.otp_attempts = {}
        self.active_userbots = {}

    async def start_handler(self, event):
        """Handle /start command"""
        user = await self.db.get_user(event.sender_id)
        
        if not user:
            # User belum terdaftar
            buttons = [
                [Button.inline("📱 Create Userbot", "create_userbot")],
                [Button.inline("ℹ️ About Userbot", "about_userbot")]
            ]
            
            # Add admin button if user is admin
            if event.sender_id == Config.ADMIN_ID:
                buttons.insert(0, [Button.inline("👮‍♂️ Admin Panel", "admin_panel")])
                
            await event.reply(
                "🤖 Welcome to Userbot by @hiyaok!\n\n"
                "Bot ini memungkinkan Anda untuk membuat userbot dengan berbagai fitur:\n"
                "• 📨 Broadcast pesan otomatis ke grup\n"
                "• 📱 Support berbagai jenis media\n"
                "• ⚡ Support emoji premium\n"
                "• ⏱️ Pengaturan delay untuk setiap pesan\n"
                "• 📊 Monitoring status pengiriman\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )
        else:
            # Cek apakah user sudah punya userbot
            userbot = await self.db.get_userbot(event.sender_id)
            
            if not userbot:
                # User terdaftar tapi belum punya userbot
                buttons = [
                    [Button.inline("📱 Create Userbot", "create_userbot")],
                    [Button.inline("ℹ️ About Userbot", "about_userbot")]
                ]
            else:
                # User sudah punya userbot
                buttons = [
                    [Button.inline("⚙️ Settings Userbot", "settings_userbot")],
                    [Button.inline("ℹ️ About Userbot", "about_userbot")]
                ]
            
            # Add admin button if user is admin
            if event.sender_id == Config.ADMIN_ID:
                buttons.insert(0, [Button.inline("👮‍♂️ Admin Panel", "admin_panel")])

            status_text = "Active" if userbot and userbot.status == "active" else "Inactive"
            expire_text = user.expire_at.strftime('%Y-%m-%d %H:%M:%S') if user.expire_at else 'Never'

            await event.reply(
                f"👋 Selamat datang kembali!\n\n"
                f"📊 Informasi User:\n"
                f"├ Status: {user.access_type.upper()}\n"
                f"├ Userbot: {status_text}\n"
                f"└ Expire: {expire_text}\n\n"
                "Silakan pilih opsi di bawah:",
                buttons=buttons
            )

    async def create_userbot_handler(self, event):
        """Handle userbot creation"""
        try:
            user = await self.db.get_user(event.sender_id)
            if not user or user.access_type not in ["admin", "premium", "premium_plus"]:
                await event.edit(
                    Config.format_error("not_authorized"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            existing_userbot = await self.db.get_userbot(event.sender_id)
            if existing_userbot:
                await event.edit(
                    Config.format_error("userbot_exists"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            self.otp_attempts[event.sender_id] = 0

            await event.edit(
                "📱 Kirim nomor telepon dalam format internasional\n"
                "Contoh: +6281234567890",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            self.user_states[event.sender_id] = "waiting_phone"

        except Exception as e:
            logger.error(f"Error in create_userbot_handler: {str(e)}")
            await event.edit(
                "❌ Terjadi kesalahan. Silakan coba lagi nanti.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
  
    async def handle_phone_number(self, event):
        """Handle phone number input"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                Config.format_error("invalid_phone"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Kode telah dikirim! Masukkan kode dengan spasi.\n"
                "Contoh: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ Nomor telepon ini telah dibanned oleh Telegram!",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Terlalu banyak permintaan! Tunggu {e.seconds} detik.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_code(self, event):
        """Handle OTP code input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            await event.reply(Config.format_error("invalid_otp"))
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)
            
            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return
                
            await event.reply("❌ Kode OTP salah! Silakan coba lagi.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa"
            await event.reply(
                "🔐 Akun ini menggunakan Two-Factor Authentication.\n"
                "Silakan masukkan password 2FA Anda:",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)

            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Password 2FA salah! Silakan coba lagi.")
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def about_handler(self, event):
        """Handle about section"""
        text = (
            "ℹ️ About Userbot\n\n"
            "🔸 Userbot adalah bot yang berjalan di akun Telegram Anda\n"
            "🔸 Dapat mengirim pesan ke banyak grup secara otomatis\n"
            "🔸 Support berbagai jenis media dan format:\n"
            "  • Foto, Video, GIF, Sticker\n"
            "  • File dan Dokumen\n" 
            "  • Emoji Premium & Regular\n"
            "  • Format teks (bold, italic, dll)\n\n"
            "Fitur Premium:\n"
            "✨ Emoji Premium\n"
            "✨ Broadcast tanpa watermark\n"
            "✨ Priority support\n\n"
            "Creator: @hiyaok"
        )
        await event.edit(text, buttons=[[Button.inline("🔙 Back", "start")]])

    async def settings_handler(self, event):
        """Handle settings menu"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!\n"
                "Silakan buat userbot terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        messages = await self.db.get_messages(event.sender_id)
        groups = await self.db.get_groups(event.sender_id)

        buttons = [
            [Button.inline("📊 Status Bot", "status"), 
             Button.inline("📝 List Pesan", "check_lists")],
            [Button.inline("➕ Tambah Pesan", "add_list"),
             Button.inline("⏱️ Atur Delay", "set_delay")],
            [Button.inline("👥 Tambah Grup", "add_groups"),
             Button.inline("📋 List Grup", "list_groups")],
            [Button.inline("🗑️ Hapus Grup", "delete_group"),
             Button.inline("❌ Hapus Pesan", "delete_list")],
            [Button.inline("📥 Grup Joined", "joined_groups"),
             Button.inline("📨 Kirim RC", "send_rc")],
            [Button.inline("🔙 Kembali", "start")]
        ]
        
        msg_count = len(messages) if messages else 0
        grp_count = len(groups) if groups else 0
        status_text = "🟢 Active" if userbot.status == "active" else "🔴 Inactive"
        
        await event.edit(
            f"⚙️ Pengaturan Userbot\n\n"
            f"Status: {status_text}\n"
            f"List Pesan: {msg_count} pesan\n"
            f"List Grup: {grp_count} grup\n\n"
            f"Pilih menu di bawah:",
            buttons=buttons
        )

    async def status_handler(self, event):
        """Handle status bot activation/deactivation"""
        userbot = await self.db.get_userbot(event.sender_id)
        messages = await self.db.get_messages(event.sender_id)
        groups = await self.db.get_groups(event.sender_id)

        if not messages:
            await event.edit(
                "❌ Tidak dapat mengaktifkan bot!\n\n"
                "Anda belum memiliki list pesan.\n"
                "Silakan tambahkan pesan terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        if not groups:
            await event.edit(
                "❌ Tidak dapat mengaktifkan bot!\n\n"
                "Anda belum memiliki daftar grup.\n"
                "Silakan tambahkan grup terlebih dahulu.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        current_status = userbot.status
        new_status = "active" if current_status == "inactive" else "inactive"
        
        buttons = [
            [Button.inline(
                f"✅ {'Aktifkan' if new_status == 'active' else 'Nonaktifkan'} Bot", 
                f"confirm_status_{new_status}"
            )],
            [Button.inline("❌ Batal", "settings_userbot")]
        ]
        
        msg = (
            f"📊 Status Bot\n\n"
            f"Status saat ini: {'🟢 Active' if current_status == 'active' else '🔴 Inactive'}\n"
            f"List Pesan: {len(messages)} pesan\n"
            f"List Grup: {len(groups)} grup\n\n"
        )
        
        if new_status == "active":
            msg += (
                "⚠️ Bot akan:\n"
                "• Mengirim semua pesan ke semua grup\n"
                "• Menggunakan delay sesuai pengaturan\n"
                "• Memberikan notifikasi status pengiriman"
            )
        else:
            msg += "⚠️ Bot akan berhenti mengirim pesan"
            
        await event.edit(msg, buttons=buttons)

    async def list_groups_handler(self, event):
        """Handle group list display"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Belum ada grup yang ditambahkan.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        text = "📋 List Grup:\n\n"
        for i, group in enumerate(groups, 1):
            text += f"{i}. {group.title}"
            if group.username:
                text += f" (@{group.username})"
            text += f"\nID: {group.group_id}\n\n"

        await event.edit(
            text,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def add_list_handler(self, event):
        """Handle message list addition"""
        await event.edit(
            "📝 Kirim pesan yang ingin ditambahkan ke list\n\n"
            "Support format:\n"
            "• Semua jenis teks & format\n"
            "• Emoji premium & regular\n"
            "• Media: foto, video, gif, sticker\n"
            "• File & dokumen\n"
            "• Caption untuk media\n\n"
            "Kirim pesan/media yang ingin ditambahkan:",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_message"

    async def handle_new_message(self, event):
        """Handle new message input"""
        if event.sender_id not in self.user_states:
            return

        try:
            message = event.message
            
            # Handle media dengan atau tanpa caption
            if message.media:
                try:
                    media_bytes = await message.download_media(bytes)
                    media_type = self._get_media_type(message.media)
                    
                    formatted_message = {
                        "media": {
                            "type": media_type,
                            "file": media_bytes,
                            "mime_type": getattr(message.media.document, 'mime_type', None) 
                                       if hasattr(message.media, 'document') else None
                        },
                        "caption": message.caption or "",
                        "caption_entities": [
                            self._format_entity(e) for e in (message.caption_entities or [])
                        ] if message.caption_entities else []
                    }
                except Exception as e:
                    raise Exception(f"Gagal memproses media: {str(e)}")
                    
            # Handle text message
            else:
                if not message.text:
                    raise Exception("Pesan tidak boleh kosong")
                    
                formatted_message = {
                    "text": message.text,
                    "entities": [
                        self._format_entity(e) for e in (message.entities or [])
                    ] if message.entities else []
                }

            # Move to delay input state
            self.user_states[event.sender_id] = {
                "state": "waiting_delay",
                "message": formatted_message
            }

            await event.reply(
                "⏱️ Masukkan delay untuk pesan ini (dalam detik):\n\n"
                "• Minimal: 1 detik\n"
                "• Maksimal: 3600 detik (1 jam)",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Gagal memproses pesan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def handle_delay_input(self, event):
        """Handle delay input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text.strip())
            if not 1 <= delay <= 3600:
                raise ValueError("Delay harus antara 1-3600 detik")

            state_data = self.user_states[event.sender_id]
            message_data = state_data["message"]
            message_data["delay"] = delay

            await self.db.add_message(event.sender_id, message_data)

            # Preview message
            preview = "📝 Pesan berhasil ditambahkan!\n\n"
            if "media" in message_data:
                preview += f"Tipe: {message_data['media']['type'].upper()}\n"
                if message_data.get("caption"):
                    caption_preview = message_data["caption"][:50]
                    preview += f"Caption: {caption_preview}...\n"
            else:
                text_preview = message_data["text"][:50]
                preview += f"Text: {text_preview}...\n"
            
            preview += f"Delay: {delay} detik"

            await event.reply(
                preview,
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Gagal menyimpan pesan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def check_lists_handler(self, event):
        """Handle list checking"""
        messages = await self.db.get_messages(event.sender_id)
        
        if not messages:
            await event.edit(
                "📝 Belum ada pesan dalam list.\n\n"
                "Gunakan tombol 'Tambah Pesan' untuk menambahkan pesan baru.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return
            
        text = "📝 List Pesan:\n\n"
        for i, msg in enumerate(messages, 1):
            text += f"{i}. "
            if "media" in msg:
                media_type = msg["media"]["type"].upper()
                text += f"[{media_type}] "
                if msg.get("caption"):
                    preview = msg["caption"][:50] + "..." if len(msg["caption"]) > 50 else msg["caption"]
                    text += preview
            else:
                preview = msg["text"][:50] + "..." if len(msg["text"]) > 50 else msg["text"]
                text += preview
            text += f"\nDelay: {msg.get('delay', 60)}s\n\n"

        # Split text if too long
        if len(text) > 4096:
            texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
            for i, msg_text in enumerate(texts):
                if i == len(texts)-1:
                    await event.edit(msg_text, buttons=[[Button.inline("🔙 Back", "settings_userbot")]])
                else:
                    await event.respond(msg_text)
        else:
            await event.edit(text, buttons=[[Button.inline("🔙 Back", "settings_userbot")]])

    async def delete_list_handler(self, event):
        """Handle message deletion"""
        messages = await self.db.get_messages(event.sender_id)
        
        if not messages:
            await event.edit(
                "📝 Tidak ada pesan yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for i, msg in enumerate(messages):
            text = ""
            if "media" in msg:
                text += f"[{msg['media']['type'].upper()}] "
                if msg.get("caption"):
                    text += msg["caption"][:30] + "..."
            else:
                text += msg["text"][:30] + "..."
            buttons.append([Button.inline(f"{i+1}. {text}", f"delete_msg_{i}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])
        
        await event.edit(
            "🗑️ Pilih pesan yang ingin dihapus:",
            buttons=buttons
        )

    async def set_delay_handler(self, event):
        """Handle delay setting"""
        messages = await self.db.get_messages(event.sender_id)
        
        if not messages:
            await event.edit(
                "📝 Tidak ada pesan untuk diatur delay-nya.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for i, msg in enumerate(messages):
            text = ""
            if "media" in msg:
                text += f"[{msg['media']['type'].upper()}] "
                if msg.get("caption"):
                    text += f"{msg['caption'][:20]}... "
            else:
                text += f"{msg['text'][:20]}... "
            text += f"({msg.get('delay', 60)}s)"
            buttons.append([Button.inline(f"{i+1}. {text}", f"set_delay_{i}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])
        
        await event.edit(
            "⏱️ Pilih pesan yang ingin diubah delay-nya:",
            buttons=buttons
        )

    async def handle_broadcasting(self, user_id):
        """Handle continuous message broadcasting"""
        if user_id not in self.active_userbots:
            return

        try:
            userbot = self.active_userbots[user_id]
            user_data = await self.db.get_user(user_id)
            
            while user_id in self.active_userbots:
                messages = await self.db.get_messages(user_id)
                groups = await self.db.get_groups(user_id)

                if not messages or not groups:
                    await self.bot.send_message(
                        user_id,
                        "⚠️ Broadcasting dihentikan:\n"
                        "Tidak ada pesan atau grup yang terdaftar.",
                        buttons=[[Button.inline("🔙 Settings", "settings_userbot")]]
                    )
                    if user_id in self.active_userbots:
                        await self.db.update_userbot_status(user_id, "inactive")
                        del self.active_userbots[user_id]
                    return

                for message in messages:
                    if user_id not in self.active_userbots:
                        break

                    for group in groups:
                        if user_id not in self.active_userbots:
                            break

                        try:
                            # Prepare message with watermark if needed
                            msg_to_send = message.copy()
                            if user_data.access_type == "premium":
                                if "text" in msg_to_send:
                                    msg_to_send["text"] += f"\n\n{Config.WATERMARK}"
                                elif "caption" in msg_to_send:
                                    msg_to_send["caption"] += f"\n\n{Config.WATERMARK}"

                            # Send message
                            await self.send_message_to_group(userbot, group.group_id, msg_to_send)
                            
                            # Send success notification
                            await self.bot.send_message(
                                user_id,
                                f"✅ Berhasil mengirim ke {group.title}"
                            )

                        except Exception as e:
                            logger.error(f"Broadcasting error to group {group.title}: {str(e)}")
                            await self.bot.send_message(
                                user_id,
                                f"❌ Gagal mengirim ke {group.title}:\n{str(e)}"
                            )

                        # Wait for delay
                        await asyncio.sleep(message.get('delay', 60))

        except Exception as e:
            logger.error(f"Broadcasting error: {str(e)}")
            await self.bot.send_message(
                user_id,
                f"❌ Error dalam broadcasting: {str(e)}",
                buttons=[[Button.inline("🔙 Settings", "settings_userbot")]]
            )

    async def send_message_to_group(self, client, group_id, message_data):
        """Send formatted message to group"""
        try:
            if "media" in message_data:
                # Handle media message
                media_data = message_data["media"]
                file = media_data["file"]
                caption = message_data.get("caption", "")
                
                params = {
                    "file": file,
                    "caption": caption,
                }
                
                if message_data.get("caption_entities"):
                    params["caption_entities"] = message_data["caption_entities"]
                
                media_type = media_data.get("type", "document")
                if media_type == "photo":
                    params["force_document"] = False
                else:
                    params["force_document"] = media_type == "document"
                
                await client.send_file(group_id, **params)
                
            else:
                # Handle text message
                text = message_data.get("text", "")
                entities = message_data.get("entities", [])
                await client.send_message(group_id, text, formatting_entities=entities)
                
        except Exception as e:
            logger.error(f"Error sending message to group {group_id}: {str(e)}")
            raise

    def _format_entity(self, entity):
        """Format message entity (formatting, emoji, etc)"""
        return {
            "type": entity.__class__.__name__,
            "offset": entity.offset,
            "length": entity.length,
            "url": getattr(entity, 'url', None),
            "user_id": getattr(entity, 'user_id', None),
            "language": getattr(entity, 'language', None),
        }

    def _get_media_type(self, media):
        """Enhanced media type detection"""
        try:
            if isinstance(media, MessageMediaPhoto):
                return "photo"
            elif isinstance(media, MessageMediaDocument):
                if hasattr(media.document, 'mime_type'):
                    if media.document.mime_type.startswith('video'):
                        return "video"
                    elif media.document.mime_type == 'image/gif':
                        return "gif"
                    elif media.document.mime_type.startswith('image'):
                        return "image"
                    elif media.document.mime_type.startswith('audio'):
                        return "audio"
                    else:
                        return "document"
            return "unknown"
        except:
            return "unknown"

    async def send_rc_handler(self, event):
        """Handle RC (Recent Chats) message sending"""
        await event.edit(
            "📨 Kirim pesan yang ingin disebarkan ke recent chats:\n\n"
            "Support format:\n"
            "• Teks & format lengkap\n"
            "• Emoji premium & regular\n"
            "• Media (foto, video, gif, sticker)\n"
            "• File & dokumen\n"
            "• Caption untuk media\n\n"
            "Kirim pesan/media yang ingin disebarkan:",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_rc_message"

    async def handle_rc_message(self, event):
        """Handle RC message input and sending"""
        if event.sender_id not in self.user_states:
            return

        try:
            userbot_data = await self.db.get_userbot(event.sender_id)
            user_data = await self.db.get_user(event.sender_id)

            if not userbot_data:
                await event.reply(
                    "❌ Userbot tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return

            # Initialize userbot
            userbot = UserBot(
                userbot_data.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            await userbot.start()

            # Format message
            message = event.message
            formatted_message = {}

            # Handle media with or without caption
            if message.media:
                try:
                    media_bytes = await message.download_media(bytes)
                    media_type = self._get_media_type(message.media)
                    
                    formatted_message["media"] = {
                        "type": media_type,
                        "file": media_bytes,
                        "mime_type": getattr(message.media.document, 'mime_type', None) 
                                   if hasattr(message.media, 'document') else None
                    }
                    
                    if message.caption:
                        formatted_message["caption"] = message.caption
                        if message.caption_entities:
                            formatted_message["caption_entities"] = [
                                self._format_entity(e) for e in message.caption_entities
                            ]
                except Exception as e:
                    raise Exception(f"Gagal memproses media: {str(e)}")
            else:
                # Handle text message
                if not message.text:
                    raise Exception("Pesan tidak boleh kosong")
                    
                formatted_message["text"] = message.text
                if message.entities:
                    formatted_message["entities"] = [
                        self._format_entity(e) for e in message.entities
                    ]

            # Add watermark for premium users (not premium_plus)
            if user_data.access_type == "premium":
                if "text" in formatted_message:
                    formatted_message["text"] += f"\n\n{Config.WATERMARK}"
                elif "caption" in formatted_message:
                    formatted_message["caption"] += f"\n\n{Config.WATERMARK}"

            # Send to recent chats
            result = await userbot.send_to_recent_chats(formatted_message)
            
            # Generate report
            report = (
                "📊 Hasil Pengiriman RC:\n\n"
                f"✅ Berhasil: {result['success_count']}\n"
                f"❌ Gagal: {result['fail_count']}\n\n"
            )

            if result['failed_chats']:
                report += "Chat yang gagal:\n"
                for chat in result['failed_chats'][:10]:  # Show only first 10 failures
                    report += f"• {chat}\n"
                if len(result['failed_chats']) > 10:
                    report += f"...dan {len(result['failed_chats']) - 10} lainnya"

            await event.reply(
                report,
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

        except Exception as e:
            logger.error(f"Error in handle_rc_message: {str(e)}")
            await event.reply(
                f"❌ Gagal mengirim RC: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        finally:
            try:
                await userbot.disconnect()
            except:
                pass
            del self.user_states[event.sender_id]

    async def confirm_delete_message(self, event):
        """Handle message deletion confirmation"""
        try:
            msg_id = int(event.data.decode().split("_")[-1])
            await self.db.delete_message(event.sender_id, msg_id)
            
            await event.edit(
                "✅ Pesan berhasil dihapus!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        except Exception as e:
            await event.edit(
                f"❌ Gagal menghapus pesan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def joined_groups_handler(self, event):
        """Handle listing joined groups"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        try:
            # Initialize userbot
            user_data = await self.db.get_user(event.sender_id)
            client = UserBot(
                userbot.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            await client.start()

            # Get all joined groups
            all_groups = []
            async for dialog in client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    group_info = {
                        'id': dialog.id,
                        'title': dialog.title,
                        'username': dialog.entity.username if hasattr(dialog.entity, 'username') else None,
                        'members': dialog.entity.participants_count if hasattr(dialog.entity, 'participants_count') else '?'
                    }
                    all_groups.append(group_info)

            await client.disconnect()

            if not all_groups:
                await event.edit(
                    "📥 Userbot belum join ke grup manapun.",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return

            # Generate report
            text = "📥 Daftar Grup yang Di-Join:\n\n"
            for i, group in enumerate(all_groups, 1):
                text += f"{i}. {group['title']}\n"
                if group['username']:
                    text += f"   @{group['username']}\n"
                text += f"   ID: {group['id']}\n"
                text += f"   Members: {group['members']}\n\n"

            # Split text if too long
            if len(text) > 4096:
                texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
                for i, msg_text in enumerate(texts):
                    if i == len(texts)-1:
                        await event.edit(
                            msg_text,
                            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                        )
                    else:
                        await event.respond(msg_text)
            else:
                await event.edit(
                    text,
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )

        except Exception as e:
            logger.error(f"Error in joined_groups_handler: {str(e)}")
            await event.edit(
                f"❌ Gagal mengambil daftar grup: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def delete_group_handler(self, event):
        """Handle group deletion"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Tidak ada grup yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for group in groups:
            text = f"{group.title}"
            if group.username:
                text += f" (@{group.username})"
            buttons.append([Button.inline(text, f"delete_group_{group.group_id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "🗑️ Pilih grup yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_group(self, event):
        """Handle group deletion confirmation"""
        try:
            group_id = int(event.data.decode().split("_")[-1])
            group = await self.db.get_group(event.sender_id, group_id)
            
            if not group:
                await event.edit(
                    "❌ Grup tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return
                
            buttons = [
                [Button.inline("✅ Ya, Hapus", f"confirm_delete_group_{group_id}"),
                 Button.inline("❌ Batal", "delete_group")]
            ]
            
            await event.edit(
                f"⚠️ Hapus grup ini?\n\n"
                f"Grup: {group.title}\n"
                f"{'Username: @' + group.username if group.username else ''}\n"
                f"ID: {group.group_id}\n\n"
                "Grup yang dihapus tidak akan menerima broadcast.",
                buttons=buttons
            )
            
        except Exception as e:
            logger.error(f"Error in confirm_delete_group: {str(e)}")
            await event.edit(
                f"❌ Gagal memproses permintaan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def confirm_delete_group_final(self, event):
        """Handle final group deletion"""
        try:
            group_id = int(event.data.decode().split("_")[-1])
            group = await self.db.get_group(event.sender_id, group_id)
            
            if not group:
                await event.edit(
                    "❌ Grup tidak ditemukan!",
                    buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
                )
                return
                
            group_title = group.title
            await self.db.remove_group(event.sender_id, group_id)
            
            await event.edit(
                f"✅ Grup berhasil dihapus!\n\n"
                f"Grup: {group_title}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            
        except Exception as e:
            logger.error(f"Error in confirm_delete_group_final: {str(e)}")
            await event.edit(
                f"❌ Gagal menghapus grup: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def add_groups_handler(self, event):
        """Handle adding groups to allowed list"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = [
            [Button.inline("✅ Add Semua Grup", "add_all_groups")],
            [Button.inline("👥 Add Custom Grup", "add_custom_groups")],
            [Button.inline("🔙 Back", "settings_userbot")]
        ]

        await event.edit(
            "👥 Pilih metode penambahan grup:\n\n"
            "• Add Semua Grup: Menambahkan semua grup yang di-join\n"
            "• Add Custom Grup: Pilih grup spesifik dengan username",
            buttons=buttons
        )

    async def add_all_groups_handler(self, event):
        """Handle adding all joined groups"""
        try:
            userbot = await self.db.get_userbot(event.sender_id)
            user_data = await self.db.get_user(event.sender_id)
            
            if not userbot:
                raise Exception("Userbot tidak ditemukan")

            client = UserBot(
                userbot.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            
            await client.start()

            # Get all joined groups
            added_count = 0
            skipped_count = 0
            failed_count = 0
            
            async for dialog in client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    try:
                        group_data = {
                            'group_id': dialog.id,
                            'title': dialog.title,
                            'username': dialog.entity.username if hasattr(dialog.entity, 'username') else None
                        }
                        
                        # Check if group already exists
                        existing_group = await self.db.get_group(event.sender_id, dialog.id)
                        if existing_group:
                            skipped_count += 1
                            continue
                            
                        await self.db.add_group(event.sender_id, group_data)
                        added_count += 1
                    except Exception as e:
                        logger.error(f"Failed to add group {dialog.title}: {str(e)}")
                        failed_count += 1

            await client.disconnect()

            report = (
                "📊 Hasil Penambahan Grup:\n\n"
                f"✅ Berhasil ditambahkan: {added_count}\n"
                f"⏭️ Dilewati (sudah ada): {skipped_count}\n"
                f"❌ Gagal: {failed_count}"
            )

            await event.edit(
                report,
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

        except Exception as e:
            logger.error(f"Error in add_all_groups_handler: {str(e)}")
            await event.edit(
                f"❌ Gagal menambahkan grup: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def add_custom_groups_handler(self, event):
        """Handle custom group addition"""
        await event.edit(
            "👥 Masukkan username grup yang ingin ditambahkan\n\n"
            "Format:\n"
            "• Single: @groupname\n"
            "• Multiple: @group1, @group2, @group3\n\n"
            "Note: Hanya grup yang di-join userbot yang bisa ditambahkan",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_group_usernames"

    async def handle_group_usernames(self, event):
        """Handle group username input"""
        if event.sender_id not in self.user_states:
            return

        try:
            userbot = await self.db.get_userbot(event.sender_id)
            user_data = await self.db.get_user(event.sender_id)
            
            if not userbot:
                raise Exception("Userbot tidak ditemukan")

            # Initialize userbot client
            client = UserBot(
                userbot.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            await client.start()

            # Process usernames
            usernames = [u.strip() for u in event.text.split(',')]
            usernames = [u[1:] if u.startswith('@') else u for u in usernames]

            results = {
                'success': [],
                'already': [],
                'not_found': [],
                'failed': []
            }

            # Get all joined groups first
            joined_groups = {}
            async for dialog in client.iter_dialogs():
                if (dialog.is_group or dialog.is_channel) and dialog.entity.username:
                    joined_groups[dialog.entity.username.lower()] = {
                        'id': dialog.id,
                        'title': dialog.title,
                        'username': dialog.entity.username
                    }

            # Process each username
            for username in usernames:
                try:
                    username = username.lower()
                    if username not in joined_groups:
                        results['not_found'].append(username)
                        continue

                    group_data = joined_groups[username]
                    
                    # Check if already added
                    existing_group = await self.db.get_group(event.sender_id, group_data['id'])
                    if existing_group:
                        results['already'].append(group_data['title'])
                        continue

                    # Add to database
                    await self.db.add_group(event.sender_id, group_data)
                    results['success'].append(group_data['title'])

                except Exception as e:
                    logger.error(f"Failed to add group @{username}: {str(e)}")
                    results['failed'].append(username)

            await client.disconnect()

            # Generate report
            report = "📊 Hasil Penambahan Grup:\n\n"
            
            if results['success']:
                report += "✅ Berhasil ditambahkan:\n"
                for group in results['success']:
                    report += f"• {group}\n"
                report += "\n"
            
            if results['already']:
                report += "⏭️ Sudah ada dalam list:\n"
                for group in results['already']:
                    report += f"• {group}\n"
                report += "\n"
            
            if results['not_found']:
                report += "❓ Tidak ditemukan/tidak di-join:\n"
                for username in results['not_found']:
                    report += f"• @{username}\n"
                report += "\n"
            
            if results['failed']:
                report += "❌ Gagal ditambahkan:\n"
                for username in results['failed']:
                    report += f"• @{username}\n"

            await event.reply(
                report,
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except Exception as e:
            logger.error(f"Error in handle_group_usernames: {str(e)}")
            await event.reply(
                f"❌ Gagal memproses grup: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )