# admin njir
from telethon import events, Button, TelegramClient
from telethon.sessions import StringSession
from telethon.errors import *
from database.database import Database
from config import Config
from typing import Dict, List
import asyncio
import logging
import re
from datetime import datetime

logger = logging.getLogger(__name__)

class AdminHandlers:
    def __init__(self, bot, db: Database):
        self.bot = bot
        self.db = db
        self.admin_states = {}
        self.otp_attempts = {}

    async def admin_panel_handler(self, event):
        """Handle admin panel menu"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        buttons = [
            [
                Button.inline("👥 Add Admin", "add_admin"),
                Button.inline("💎 Add Premium", "add_premium")
            ],
            [
                Button.inline("📢 Broadcast", "broadcast"),
                Button.inline("📊 User List", "user_list")
            ],
            [
                Button.inline("🗑️ Delete Userbot", "delete_userbot"),
                Button.inline("📱 Create Userbot", "admin_create_userbot")
            ],
            [
                Button.inline("⚙️ Settings Userbot", "admin_settings_userbot"),
                Button.inline("🔙 Back", "start")
            ]
        ]

        await event.edit(
            "👮‍♂️ Admin Panel\n\n"
            "Select an option:",
            buttons=buttons
        )

    async def add_admin_handler(self, event):
        """Handle adding new admin"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "👤 Kirim User ID yang ingin dijadikan admin:\n\n"
            "Format: angka saja (contoh: 123456789)",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_admin_id"

    async def handle_admin_id(self, event):
        """Handle admin ID input"""
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            user_id = int(event.text.strip())
            
            # Verify user exists
            try:
                user = await self.bot.get_entity(user_id)
            except:
                raise ValueError("User ID tidak valid atau user tidak ditemukan")

            # Add as admin
            await self.db.add_user(user_id, access_type="admin")
            
            await event.reply(
                f"✅ Berhasil menambahkan admin baru!\n\n"
                f"User ID: {user_id}\n"
                f"Name: {user.first_name}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    "🎉 Anda telah diangkat menjadi admin!"
                )
            except:
                pass
            
        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            
        del self.admin_states[event.sender_id]

    async def add_premium_handler(self, event):
        """Handle adding premium user"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        buttons = [
            [
                Button.inline("💎 Premium", "premium_normal"),
                Button.inline("💎+ Premium Plus", "premium_plus")
            ],
            [Button.inline("🔙 Back", "admin_panel")]
        ]

        await event.edit(
            "💎 Pilih jenis premium:\n\n"
            "• Premium: Watermark dibawah pesan\n"
            "• Premium Plus: Tanpa watermark",
            buttons=buttons
        )

    async def handle_premium_type(self, event):
        """Handle premium type selection"""
        if event.sender_id != Config.ADMIN_ID:
            return

        premium_type = event.data.decode().split("_")[-1]
        self.admin_states[event.sender_id] = {
            "state": "waiting_premium_user",
            "premium_type": premium_type
        }

        await event.edit(
            "👤 Kirim User ID yang ingin dijadikan premium:\n\n"
            "Format: angka saja (contoh: 123456789)",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def handle_premium_user(self, event):
        """Handle premium user ID input"""
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            user_id = int(event.text.strip())
            
            # Verify user exists
            try:
                user = await self.bot.get_entity(user_id)
            except:
                raise ValueError("User ID tidak valid atau user tidak ditemukan")

            state_data = self.admin_states[event.sender_id]
            premium_type = state_data["premium_type"]

            # Store for duration input
            self.admin_states[event.sender_id] = {
                "state": "waiting_premium_duration",
                "user_id": user_id,
                "premium_type": premium_type,
                "user_name": user.first_name
            }

            await event.reply(
                "⏱️ Masukkan durasi premium dalam hari:\n\n"
                "Contoh: 30 (untuk 30 hari)",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def handle_premium_duration(self, event):
        """Handle premium duration input"""
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            duration = int(event.text.strip())
            if duration <= 0:
                raise ValueError("Durasi harus lebih dari 0 hari")

            state_data = self.admin_states[event.sender_id]
            user_id = state_data["user_id"]
            premium_type = state_data["premium_type"]
            user_name = state_data["user_name"]

            access_type = "premium_plus" if premium_type == "plus" else "premium"
            expire_date = datetime.now() + timedelta(days=duration)
            
            # Add/update user
            await self.db.add_user(
                user_id, 
                access_type=access_type,
                expire_at=expire_date
            )

            await event.reply(
                f"✅ Berhasil menambahkan user premium!\n\n"
                f"User: {user_name}\n"
                f"ID: {user_id}\n"
                f"Tipe: {access_type}\n"
                f"Durasi: {duration} hari\n"
                f"Expired: {expire_date.strftime('%Y-%m-%d %H:%M:%S')}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    f"🎉 Selamat! Akun Anda telah diupgrade ke {access_type}!\n\n"
                    f"Durasi: {duration} hari\n"
                    f"Expired: {expire_date.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            except:
                pass

            del self.admin_states[event.sender_id]

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def broadcast_handler(self, event):
        """Handle broadcast message"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "📢 Kirim pesan yang ingin di-broadcast ke semua user:\n\n"
            "Support format:\n"
            "• Teks biasa dan formatting\n"
            "• Media dengan caption\n"
            "• Emoji dan formatting lainnya",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_broadcast"

    async def handle_broadcast(self, event):
        """Handle broadcast message sending"""
        if event.sender_id != Config.ADMIN_ID:
            return

        message = event.message
        users = await self.db.get_all_users()

        success = 0
        failed = 0
        skipped = 0
        
        # Progress message
        progress_msg = await event.reply("📤 Memulai broadcast...")

        try:
            for user in users:
                try:
                    if message.media:
                        await self.bot.send_file(
                            user["user_id"],
                            file=message.media,
                            caption=message.text if message.text else None,
                            formatting_entities=message.entities if message.entities else None
                        )
                    else:
                        await self.bot.send_message(
                            user["user_id"],
                            message.text,
                            formatting_entities=message.entities if message.entities else None
                        )
                    success += 1
                    
                    # Update progress setiap 10 user
                    if success % 10 == 0:
                        await progress_msg.edit(
                            f"📤 Broadcasting...\n\n"
                            f"✅ Berhasil: {success}\n"
                            f"❌ Gagal: {failed}\n"
                            f"⏭️ Dilewati: {skipped}\n\n"
                            f"Progress: {((success + failed + skipped) / len(users)) * 100:.1f}%"
                        )
                        
                except Exception as e:
                    logger.error(f"Broadcast failed for user {user['user_id']}: {str(e)}")
                    failed += 1

                await asyncio.sleep(0.5)  # Delay to avoid flood

        except Exception as e:
            logger.error(f"Broadcast error: {str(e)}")
            await progress_msg.edit(
                f"❌ Terjadi kesalahan dalam broadcast: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        await progress_msg.edit(
            f"📢 Broadcast selesai!\n\n"
            f"✅ Berhasil: {success}\n"
            f"❌ Gagal: {failed}\n"
            f"⏭️ Dilewati: {skipped}",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

        del self.admin_states[event.sender_id]

    async def user_list_handler(self, event):
        """Handle user list display"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        users = await self.db.get_all_users()
        
        # Group users by access type
        user_groups = {
            "admin": [],
            "premium_plus": [],
            "premium": [],
            "regular": []
        }

        for user in users:
            user_groups[user["access_type"]].append(user)

        text = "👥 Daftar User:\n\n"
        
        # Admin users
        if user_groups["admin"]:
            text += "👮‍♂️ ADMIN:\n"
            for user in user_groups["admin"]:
                try:
                    user_entity = await self.bot.get_entity(user["user_id"])
                    text += f"• {user_entity.first_name} (ID: {user['user_id']})\n"
                except:
                    text += f"• ID: {user['user_id']}\n"
            text += "\n"

        # Premium Plus users
        if user_groups["premium_plus"]:
            text += "💎+ PREMIUM PLUS:\n"
            for user in user_groups["premium_plus"]:
                expire = user.get("expire_at", "Never").strftime("%Y-%m-%d") if user.get("expire_at") else "Never"
                try:
                    user_entity = await self.bot.get_entity(user["user_id"])
                    text += f"• {user_entity.first_name} (ID: {user['user_id']})\n  Expire: {expire}\n"
                except:
                    text += f"• ID: {user['user_id']}\n  Expire: {expire}\n"
            text += "\n"

        # Premium users
        if user_groups["premium"]:
            text += "💎 PREMIUM:\n"
            for user in user_groups["premium"]:
                expire = user.get("expire_at", "Never").strftime("%Y-%m-%d") if user.get("expire_at") else "Never"
                try:
                    user_entity = await self.bot.get_entity(user["user_id"])
                    text += f"• {user_entity.first_name} (ID: {user['user_id']})\n  Expire: {expire}\n"
                except:
                    text += f"• ID: {user['user_id']}\n  Expire: {expire}\n"
            text += "\n"

        # Regular users
        if user_groups["regular"]:
            text += "👤 REGULAR:\n"
            for user in user_groups["regular"]:
                try:
                    user_entity = await self.bot.get_entity(user["user_id"])
                    text += f"• {user_entity.first_name} (ID: {user['user_id']})\n"
                except:
                    text += f"• ID: {user['user_id']}\n"

        # Add total count
        total_users = sum(len(users) for users in user_groups.values())
        text += f"\nTotal Users: {total_users}"

        # Split text if too long
        if len(text) > 4096:
            texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
            for i, chunk in enumerate(texts):
                if i == len(texts)-1:
                    await event.edit(
                        chunk,
                        buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                    )
                else:
                    await event.respond(chunk)
        else:
            await event.edit(
                text,
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def delete_userbot_handler(self, event):
        """Handle userbot deletion"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        userbots = await self.db.get_all_userbots()
        
        if not userbots:
            await event.edit(
                "❌ Tidak ada userbot yang aktif.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        buttons = []
        for userbot in userbots:
            try:
                user = await self.db.get_user(userbot["user_id"])
                user_entity = await self.bot.get_entity(userbot["user_id"])
                button_text = f"🗑️ {user_entity.first_name}"
                if user:
                    button_text += f" ({user['access_type'].upper()})"
            except:
                button_text = f"🗑️ User ID: {userbot['user_id']}"
                
            buttons.append([Button.inline(button_text, f"confirm_delete_{userbot['user_id']}")])

        buttons.append([Button.inline("🔙 Back", "admin_panel")])

        await event.edit(
            "🗑️ Pilih userbot yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_userbot(self, event):
        """Handle userbot deletion confirmation"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        user_id = int(event.data.decode().split("_")[-1])
        
        try:
            # Get user info for notification
            try:
                user_entity = await self.bot.get_entity(user_id)
                user_name = user_entity.first_name
            except:
                user_name = f"ID: {user_id}"
                
            # Delete userbot
            await self.db.delete_userbot(user_id)
            
            # Stop userbot if running
            if user_id in self.bot.user_handlers.active_userbots:
                await self.bot.user_handlers.active_userbots[user_id].disconnect()
                del self.bot.user_handlers.active_userbots[user_id]

            # Notify admin
            await event.edit(
                f"✅ Userbot berhasil dihapus!\n\n"
                f"User: {user_name}\n"
                f"ID: {user_id}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    "⚠️ Userbot Anda telah dihapus oleh admin."
                )
            except:
                pass

        except Exception as e:
            await event.edit(
                f"❌ Gagal menghapus userbot: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def admin_create_userbot(self, event):
        """Handle admin userbot creation"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "📱 Kirim nomor telepon dalam format internasional\n"
            "Contoh: +6281234567890",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_phone"

    async def handle_phone_number(self, event):
        """Handle phone number input"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                Config.format_error("invalid_phone"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Kode telah dikirim! Masukkan kode dengan spasi.\n"
                "Contoh: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ Nomor telepon ini telah dibanned oleh Telegram!",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Terlalu banyak permintaan! Tunggu {e.seconds} detik.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_code(self, event):
        """Handle OTP code input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            await event.reply(Config.format_error("invalid_otp"))
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)
            
            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return
                
            await event.reply("❌ Kode OTP salah! Silakan coba lagi.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa"
            await event.reply(
                "🔐 Akun ini menggunakan Two-Factor Authentication.\n"
                "Silakan masukkan password 2FA Anda:",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)

            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Password 2FA salah! Silakan coba lagi.")
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def admin_settings_userbot(self, event):
        """Handle admin userbot settings"""
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ Anda belum memiliki userbot!",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        buttons = [
            [Button.inline("📊 Status Bot", "status"), 
             Button.inline("📝 List Pesan", "check_lists")],
            [Button.inline("➕ Tambah Pesan", "add_list"),
             Button.inline("⏱️ Atur Delay", "set_delay")],
            [Button.inline("👥 Tambah Grup", "add_groups"),
             Button.inline("📋 List Grup", "list_groups")],
            [Button.inline("🗑️ Hapus Grup", "delete_group"),
             Button.inline("❌ Hapus Pesan", "delete_list")],
            [Button.inline("📥 Grup Joined", "joined_groups"),
             Button.inline("📨 Kirim RC", "send_rc")],
            [Button.inline("🔙 Back", "admin_panel")]
        ]

        msg_count = len(await self.db.get_messages(event.sender_id))
        grp_count = len(await self.db.get_groups(event.sender_id))
        status_text = "🟢 Active" if userbot.status == "active" else "🔴 Inactive"

        await event.edit(
            f"⚙️ Settings Userbot Admin\n\n"
            f"Status: {status_text}\n"
            f"Total Pesan: {msg_count}\n"
            f"Total Grup: {grp_count}\n\n"
            "Pilih menu:",
            buttons=buttons
        )