#admin handle
from telethon import events, Button, TelegramClient
from telethon.sessions import StringSession
from telethon.errors import *
from database.database import Database
from config import Config
from typing import Dict, List, Optional, Any
import asyncio
import logging
import re
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class AdminHandlers:
    def __init__(self, bot, db: Database):
        self.bot = bot
        self.db = db
        self.admin_states = {}
        self.user_states = {}
        self.otp_attempts = {}

    # Helper methods
    async def register_new_user(self, user_id: int, first_name: str, username: Optional[str] = None) -> None:
        """Register new user in database when they first access the bot"""
        try:
            existing_user = await self.db.get_user(user_id)
            if not existing_user:
                await self.db.add_user(
                    user_id=user_id,
                    access_type="regular",
                    first_name=first_name,
                    username=username,
                    duration=None
                )
                logger.info(f"New user registered: {user_id}")
        except Exception as e:
            logger.error(f"Error registering new user {user_id}: {str(e)}")

    async def get_all_userbots(self) -> List[Dict[str, Any]]:
        """Get all active userbots"""
        try:
            async with self.db.db.execute(
                'SELECT user_id, phone, status FROM userbots WHERE status != ?',
                ('deleted',)
            ) as cursor:
                rows = await cursor.fetchall()
                return [
                    {
                        'user_id': row[0],
                        'phone': row[1],
                        'status': row[2]
                    }
                    for row in rows
                ]
        except Exception as e:
            logger.error(f"Error getting all userbots: {str(e)}")
            return []

    async def check_admin_access(self, user_id: int) -> bool:
        """Check if user has admin access"""
        try:
            if user_id == Config.ADMIN_ID:
                return True
            
            user = await self.db.get_user(user_id)
            return user and user.access_type == "admin"
        except Exception as e:
            logger.error(f"Error checking admin access for {user_id}: {str(e)}")
            return False

    # Admin panel handler
    async def admin_panel_handler(self, event):
        """Handle admin panel menu"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        # Register admin if not already registered
        await self.register_new_user(
            event.sender_id,
            event.sender.first_name,
            event.sender.username
        )

        buttons = [
            [
                Button.inline("👥 Add Admin", "add_admin"),
                Button.inline("💎 Add Premium", "add_premium")
            ],
            [
                Button.inline("📢 Broadcast", "broadcast"),
                Button.inline("📊 User List", "user_list")
            ],
            [
                Button.inline("🗑️ Delete Userbot", "delete_userbot"),
                Button.inline("📱 Create Userbot", "admin_create_userbot")
            ],
            [
                Button.inline("⚙️ Settings Userbot", "admin_settings_userbot"),
                Button.inline("🔙 Back", "start")
            ]
        ]

        await event.edit(
            "👮‍♂️ Admin Panel\n\n"
            "Select an option:",
            buttons=buttons
        )

    # Admin management handlers
    async def add_admin_handler(self, event):
        """Handle adding new admin"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "👤 Send User ID to make admin:\n\n"
            "Format: numbers only (example: 123456789)",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_admin_id"

    async def handle_admin_id(self, event):
        """Handle admin ID input"""
        if not await self.check_admin_access(event.sender_id):
            return

        try:
            user_id = int(event.text.strip())
            
            try:
                user = await self.bot.get_entity(user_id)
            except:
                raise ValueError("Invalid User ID or user not found")

            await self.db.add_user(
                user_id=user_id, 
                access_type="admin",
                first_name=user.first_name,
                username=user.username
            )
            
            await event.reply(
                f"✅ Successfully added new admin!\n\n"
                f"User ID: {user_id}\n"
                f"Name: {user.first_name}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            try:
                await self.bot.send_message(
                    user_id,
                    "🎉 You have been promoted to admin!"
                )
            except:
                pass
            
        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            
        del self.admin_states[event.sender_id]

    # Premium management handlers
    async def add_premium_handler(self, event):
        """Handle adding premium user"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        buttons = [
            [
                Button.inline("💎 Premium", "premium_normal"),
                Button.inline("💎+ Premium Plus", "premium_plus")
            ],
            [Button.inline("🔙 Back", "admin_panel")]
        ]

        await event.edit(
            "💎 Select premium type:\n\n"
            "• Premium: With watermark\n"
            "• Premium Plus: No watermark",
            buttons=buttons
        )

    async def handle_premium_type(self, event):
        """Handle premium type selection"""
        if not await self.check_admin_access(event.sender_id):
            return

        premium_type = event.data.decode().split("_")[-1]
        self.admin_states[event.sender_id] = {
            "state": "waiting_premium_user",
            "premium_type": premium_type
        }

        await event.edit(
            "👤 Send User ID for premium access:\n\n"
            "Format: numbers only (example: 123456789)",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def handle_premium_user(self, event):
        """Handle premium user ID input"""
        if not await self.check_admin_access(event.sender_id):
            return

        try:
            user_id = int(event.text.strip())
            
            try:
                user = await self.bot.get_entity(user_id)
            except:
                raise ValueError("Invalid User ID or user not found")

            state_data = self.admin_states[event.sender_id]
            premium_type = state_data["premium_type"]

            self.admin_states[event.sender_id] = {
                "state": "waiting_premium_duration",
                "user_id": user_id,
                "premium_type": premium_type,
                "user_name": user.first_name
            }

            await event.reply(
                "⏱️ Enter premium duration in days:\n\n"
                "Example: 30 (for 30 days)",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def handle_premium_duration(self, event):
        """Handle premium duration input"""
        if not await self.check_admin_access(event.sender_id):
            return

        try:
            duration = int(event.text.strip())
            if duration <= 0:
                raise ValueError("Duration must be greater than 0 days")

            state_data = self.admin_states[event.sender_id]
            user_id = state_data["user_id"]
            premium_type = state_data["premium_type"]
            user_name = state_data["user_name"]

            access_type = "premium_plus" if premium_type == "plus" else "premium"
            
            # Add premium user
            await self.db.add_user(
                user_id=user_id,
                access_type=access_type,
                duration=duration,
                first_name=user_name
            )

            # Get expiry date for display
            user = await self.db.get_user(user_id)
            expire_date = user.expire_at if user else None

            await event.reply(
                f"✅ Successfully added premium user!\n\n"
                f"User: {user_name}\n"
                f"ID: {user_id}\n"
                f"Type: {access_type}\n"
                f"Duration: {duration} days\n"
                f"Expires: {expire_date.strftime('%Y-%m-%d %H:%M:%S') if expire_date else 'Never'}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    f"🎉 Congratulations! Your account has been upgraded to {access_type}!\n\n"
                    f"Duration: {duration} days\n"
                    f"Expires: {expire_date.strftime('%Y-%m-%d %H:%M:%S') if expire_date else 'Never'}"
                )
            except:
                pass

            del self.admin_states[event.sender_id]

        except ValueError as e:
            await event.reply(
                f"❌ {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    # Broadcast handlers
    async def broadcast_handler(self, event):
        """Handle broadcast message"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "📢 Send message to broadcast to all users:\n\n"
            "Supported formats:\n"
            "• Forwarded messages (will be forwarded as-is)\n"
            "• Text with formatting (bold, italic, etc)\n"
            "• Media with captions\n"
            "• All emoji types\n"
            "• Links and mentions",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_broadcast"

    async def handle_broadcast(self, event):
        """Handle broadcast message sending with improved entity handling"""
        if not await self.check_admin_access(event.sender_id):
            return

        message = event.message
        users = await self.db.get_all_users()

        if not users:
            await event.reply(
                "❌ No users found in database!",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        success = 0
        failed = 0
        skipped = 0
        
        progress_msg = await event.reply("📤 Starting broadcast...")

        try:
            total_users = len(users)
            for i, user in enumerate(users, 1):
                try:
                    if message.forward:
                        # Handle forwarded messages
                        await message.forward_to(user.user_id)
                    else:
                        # Handle regular messages (with or without media)
                        if message.media:
                            await self.bot.send_file(
                                user.user_id,
                                file=message.media,
                                caption=message.text if message.text else None,
                                formatting_entities=message.entities if message.entities else None
                            )
                        else:
                            await self.bot.send_message(
                                user.user_id,
                                message.text,
                                formatting_entities=message.entities if message.entities else None
                            )
                    
                    success += 1
                    
                    # Update progress
                    if i % 10 == 0 or i / total_users in [0.25, 0.5, 0.75, 1.0]:
                        await progress_msg.edit(
                            f"📤 Broadcasting...\n\n"
                            f"✅ Success: {success}\n"
                            f"❌ Failed: {failed}\n"
                            f"⏭️ Skipped: {skipped}\n\n"
                            f"Progress: {(i / total_users) * 100:.1f}%"
                        )
                    
                    # Log successful broadcast
                    await self.db.log_broadcast(
                        user_id=event.sender_id,
                        message_id=message.id,
                        group_id=user.user_id,
                        status="success"
                    )
                        
                except Exception as e:
                    logger.error(f"Broadcast failed for user {user.user_id}: {str(e)}")
                    failed += 1
                    # Log failed broadcast
                    await self.db.log_broadcast(
                        user_id=event.sender_id,
                        message_id=message.id,
                        group_id=user.user_id,
                        status="failed",
                        error_message=str(e)
                    )

                # Add delay between messages
                await asyncio.sleep(0.5)

        except Exception as e:
            logger.error(f"Broadcast error: {str(e)}")
            await progress_msg.edit(
                f"❌ Error during broadcast: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        await progress_msg.edit(
            f"📢 Broadcast completed!\n\n"
            f"✅ Success: {success}\n"
            f"❌ Failed: {failed}\n"
            f"⏭️ Skipped: {skipped}\n"
            f"Total Users: {total_users}",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

        del self.admin_states[event.sender_id]

    # User list handler
    async def user_list_handler(self, event):
        """Handle user list display"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        try:
            users = await self.db.get_all_users()
            
            if not users:
                await event.edit(
                    "❌ No users found in database!",
                    buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                )
                return

            # Group users by access type
            user_groups = {
                "admin": [],
                "premium_plus": [],
                "premium": [],
                "regular": []
            }

            for user in users:
                user_groups[user.access_type].append(user)

            text = "👥 User List:\n\n"
            
            # Admin users
            if user_groups["admin"]:
                text += "👮‍♂️ ADMIN:\n"
                for user in user_groups["admin"]:
                    try:
                        user_entity = await self.bot.get_entity(user.user_id)
                        text += f"• {user_entity.first_name} (ID: {user.user_id})\n"
                    except:
                        text += f"• ID: {user.user_id}\n"
                text += "\n"

            # Premium Plus users
            if user_groups["premium_plus"]:
                text += "💎+ PREMIUM PLUS:\n"
                for user in user_groups["premium_plus"]:
                    expire = user.expire_at.strftime("%Y-%m-%d") if user.expire_at else "Never"
                    try:
                        user_entity = await self.bot.get_entity(user.user_id)
                        text += f"• {user_entity.first_name} (ID: {user.user_id})\n  Expire: {expire}\n"
                    except:
                        text += f"• ID: {user.user_id}\n  Expire: {expire}\n"
                text += "\n"

            # Premium users
            if user_groups["premium"]:
                text += "💎 PREMIUM:\n"
                for user in user_groups["premium"]:
                    expire = user.expire_at.strftime("%Y-%m-%d") if user.expire_at else "Never"
                    try:
                        user_entity = await self.bot.get_entity(user.user_id)
                        text += f"• {user_entity.first_name} (ID: {user.user_id})\n  Expire: {expire}\n"
                    except:
                        text += f"• ID: {user.user_id}\n  Expire: {expire}\n"
                text += "\n"

            # Regular users
            if user_groups["regular"]:
                text += "👤 REGULAR:\n"
                for user in user_groups["regular"]:
                    try:
                        user_entity = await self.bot.get_entity(user.user_id)
                        text += f"• {user_entity.first_name} (ID: {user.user_id})\n"
                    except:
                        text += f"• ID: {user.user_id}\n"

            # Add total count
            total_users = sum(len(users) for users in user_groups.values())
            text += f"\nTotal Users: {total_users}"

            # Split text if too long
            if len(text) > 4096:
                texts = [text[i:i+4096] for i in range(0, len(text), 4096)]
                for i, chunk in enumerate(texts):
                    if i == len(texts)-1:
                        await event.edit(
                            chunk,
                            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                        )
                    else:
                        await event.respond(chunk)
            else:
                await event.edit(
                    text,
                    buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                )

        except Exception as e:
            logger.error(f"Error in user_list_handler: {str(e)}")
            await event.edit(
                f"❌ Error retrieving user list: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    # Userbot management handlers
    async def delete_userbot_handler(self, event):
        """Handle userbot deletion"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        try:
            userbots = await self.get_all_userbots()
            
            if not userbots:
                await event.edit(
                    "❌ No active userbots found.",
                    buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                )
                return

            buttons = []
            for userbot in userbots:
                try:
                    user = await self.db.get_user(userbot["user_id"])
                    user_entity = await self.bot.get_entity(userbot["user_id"])
                    button_text = f"🗑️ {user_entity.first_name}"
                    if user:
                        button_text += f" ({user.access_type.upper()})"
                except:
                    button_text = f"🗑️ User ID: {userbot['user_id']}"
                    
                buttons.append([Button.inline(
                    button_text, 
                    f"confirm_delete_{userbot['user_id']}"
                )])

            buttons.append([Button.inline("🔙 Back", "admin_panel")])

            await event.edit(
                "🗑️ Select userbot to delete:",
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in delete_userbot_handler: {str(e)}")
            await event.edit(
                f"❌ Error retrieving userbots: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def confirm_delete_userbot(self, event):
        """Handle userbot deletion confirmation"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        user_id = int(event.data.decode().split("_")[-1])
        
        try:
            # Get user info for notification
            try:
                user_entity = await self.bot.get_entity(user_id)
                user_name = user_entity.first_name
            except:
                user_name = f"ID: {user_id}"
                
            # Delete userbot
            await self.db.delete_userbot(user_id)
            
            # Stop userbot if running
            if hasattr(self.bot, 'user_handlers') and hasattr(self.bot.user_handlers, 'active_userbots') and \
               user_id in self.bot.user_handlers.active_userbots:
                await self.bot.user_handlers.active_userbots[user_id].disconnect()
                del self.bot.user_handlers.active_userbots[user_id]

            # Notify admin
            await event.edit(
                f"✅ Userbot successfully deleted!\n\n"
                f"User: {user_name}\n"
                f"ID: {user_id}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    "⚠️ Your userbot has been deleted by admin."
                )
            except:
                pass

        except Exception as e:
            await event.edit(
                f"❌ Failed to delete userbot: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def admin_create_userbot(self, event):
        """Handle admin userbot creation"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        # Initialize user_states for this user
        self.user_states[event.sender_id] = {
            "state": "waiting_phone_admin"
        }

        await event.edit(
            "📱 Send phone number in international format\n"
            "Example: +6281234567890",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def handle_phone_number(self, event):
        """Handle phone number input for userbot creation"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                "❌ Invalid phone number format! Please use international format.\n"
                "Example: +6281234567890",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code_admin",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Code has been sent! Enter the code with spaces.\n"
                "Example: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ This phone number has been banned by Telegram!",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Too many requests! Wait {e.seconds} seconds.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def handle_code(self, event):
        """Handle verification code input for userbot creation"""
        if event.sender_id not in self.user_states:
            await event.reply(
                "❌ Session expired. Please start over.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    "❌ Maximum OTP attempts reached. Please start over.",
                    buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                )
                return

            await event.reply("❌ Invalid code format! Please enter only numbers.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(
                user_id=event.sender_id,
                session_string=session_string,
                phone=state_data["phone"],
                app_id=Config.API_ID,
                app_hash=Config.API_HASH
            )
            
            await event.reply(
                "✅ Userbot successfully created!\n\n"
                "⚠️ IMPORTANT: Save this session string!\n"
                f"`{session_string}`\n\n"
                "Use /start to access userbot settings.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    "❌ Maximum OTP attempts reached. Please start over.",
                    buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                )
                return
                
            await event.reply("❌ Invalid verification code! Please try again.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa_admin"
            await event.reply(
                "🔐 This account uses Two-Factor Authentication.\n"
                "Please enter your 2FA password:",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input for userbot creation"""
        if event.sender_id not in self.user_states:
            await event.reply(
                "❌ Session expired. Please start over.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(
                user_id=event.sender_id,
                session_string=session_string,
                phone=state_data["phone"],
                app_id=Config.API_ID,
                app_hash=Config.API_HASH
            )

            await event.reply(
                "✅ Userbot successfully created!\n\n"
                "⚠️ IMPORTANT: Save this session string!\n"
                f"`{session_string}`\n\n"
                "Use /start to access userbot settings.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Invalid 2FA password! Please try again.")
        except Exception as e:
            await event.reply(
                f"❌ Error occurred: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def admin_settings_userbot(self, event):
        """Handle admin userbot settings"""
        if not await self.check_admin_access(event.sender_id):
            await event.answer("⛔ Access denied!")
            return

        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                "❌ You don't have a userbot yet!",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        buttons = [
            [Button.inline("📊 Bot Status", "status"), 
             Button.inline("📝 Message List", "check_lists")],
            [Button.inline("➕ Add Message", "add_list"),
             Button.inline("⏱️ Set Delay", "set_delay")],
            [Button.inline("👥 Add Group", "add_groups"),
             Button.inline("📋 Group List", "list_groups")],
            [Button.inline("🗑️ Delete Group", "delete_group"),
             Button.inline("❌ Delete Message", "delete_list")],
            [Button.inline("📥 Joined Groups", "joined_groups"),
             Button.inline("📨 Send RC", "send_rc")],
            [Button.inline("🔙 Back", "admin_panel")]
        ]

        try:
            msg_count = len(await self.db.get_messages(event.sender_id))
            grp_count = len(await self.db.get_groups(event.sender_id))
            status_text = "🟢 Active" if userbot.status == "active" else "🔴 Inactive"

            await event.edit(
                f"⚙️ Admin Userbot Settings\n\n"
                f"Status: {status_text}\n"
                f"Total Messages: {msg_count}\n"
                f"Total Groups: {grp_count}\n\n"
                "Select menu:",
                buttons=buttons
            )
        except Exception as e:
            logger.error(f"Error in admin_settings_userbot: {str(e)}")
            await event.edit(
                "❌ Error loading userbot settings",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )