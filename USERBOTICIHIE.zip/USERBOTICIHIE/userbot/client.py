# userbot/client.py
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.types import Channel, Chat, User
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, ChannelParticipantsSearch
from userbot.message_formatter import MessageFormatter
from typing import List, Dict, Optional, Generator
import asyncio
import logging

logger = logging.getLogger(__name__)

class UserBot:
    def __init__(self, session_string: str, api_id: str, api_hash: str, user_type: str):
        self.client = TelegramClient(StringSession(session_string), api_id, api_hash)
        self.user_type = user_type
        self.running = False
        self.formatter = MessageFormatter()
        
    async def start(self):
        """Start the userbot"""
        await self.client.start()
        
    async def stop(self):
        """Stop the userbot"""
        self.running = False
        await self.client.disconnect()

    async def get_joined_groups(self) -> List[Dict]:
        """Get list of groups the userbot has joined"""
        groups = []
        async for dialog in self.client.iter_dialogs():
            if isinstance(dialog.entity, (Channel, Chat)):
                if getattr(dialog.entity, 'broadcast', False):
                    continue  # Skip channels
                groups.append({
                    "id": dialog.entity.id,
                    "title": dialog.entity.title,
                    "username": getattr(dialog.entity, 'username', None),
                    "members_count": getattr(dialog.entity, 'participants_count', 0),
                    "joined_date": dialog.entity.date
                })
        return groups

    async def join_group(self, group_link: str) -> Optional[Dict]:
        """Join a group using username or invite link"""
        try:
            # Handle invite links
            if group_link.startswith('https://t.me/+'):
                group_entity = await self.client.get_entity(group_link)
            # Handle usernames
            else:
                username = group_link.replace('@', '').replace('https://t.me/', '')
                group_entity = await self.client.get_entity(username)

            if isinstance(group_entity, (Channel, Chat)):
                return {
                    "id": group_entity.id,
                    "title": group_entity.title,
                    "username": getattr(group_entity, 'username', None)
                }
            return None
        except Exception as e:
            logger.error(f"Error joining group {group_link}: {str(e)}")
            return None

    async def send_message_to_group(self, group_id: int, message: Dict, watermark: Optional[str] = None) -> bool:
        """Send message to a specific group"""
        try:
            # Format message with watermark if needed
            formatted_message = self.formatter.format_message(message, watermark)
            
            # Convert entities to Telethon format
            entities = self.formatter.convert_to_telethon_entities(formatted_message["entities"])
            
            if formatted_message.get("media"):
                await self.client.send_file(
                    group_id,
                    file=formatted_message["media"]["file"],
                    caption=formatted_message["text"],
                    formatting_entities=entities
                )
            else:
                await self.client.send_message(
                    group_id,
                    formatted_message["text"],
                    formatting_entities=entities
                )
            return True
        except Exception as e:
            logger.error(f"Error sending message to group {group_id}: {str(e)}")
            return False

    async def broadcast_messages(
        self,
        groups: List[Dict],
        messages: List[Dict],
        watermark: Optional[str] = None
    ) -> Generator[Dict, None, None]:
        """Broadcast messages to multiple groups"""
        self.running = True
        
        while self.running:
            for message in messages:
                if not self.running:
                    break

                success_count = 0
                fail_count = 0
                failed_groups = []

                for group in groups:
                    if not self.running:
                        break

                    success = await self.send_message_to_group(
                        group["id"],
                        message,
                        watermark if self.user_type == "premium" else None
                    )

                    if success:
                        success_count += 1
                    else:
                        fail_count += 1
                        failed_groups.append(group)

                    await asyncio.sleep(message.get("delay", 60))

                yield {
                    "message": message,
                    "success_count": success_count,
                    "fail_count": fail_count,
                    "failed_groups": failed_groups
                }

    async def send_to_recent_chats(self, message: Dict) -> Dict:
        """Send message to recent private chats"""
        success_count = 0
        fail_count = 0
        failed_chats = []

        async for dialog in self.client.iter_dialogs():
            if isinstance(dialog.entity, User) and not dialog.entity.bot:
                success = await self.send_message_to_group(
                    dialog.id,
                    message,
                    Config.WATERMARK if self.user_type == "premium" else None
                )

                if success:
                    success_count += 1
                else:
                    fail_count += 1
                    failed_chats.append({
                        "id": dialog.id,
                        "title": dialog.entity.first_name,
                        "username": dialog.entity.username
                    })

        return {
            "success_count": success_count,
            "fail_count": fail_count,
            "failed_chats": failed_chats
        }

    async def get_group_info(self, group_id: int) -> Optional[Dict]:
        """Get detailed information about a specific group"""
        try:
            entity = await self.client.get_entity(group_id)
            if isinstance(entity, (Channel, Chat)):
                participants_count = 0
                admins_count = 0

                try:
                    participants = await self.client(GetParticipantsRequest(
                        channel=entity,
                        filter=ChannelParticipantsSearch(''),
                        offset=0,
                        limit=0,
                        hash=0
                    ))
                    participants_count = len(participants.participants)
                    admins_count = len([p for p in participants.participants if getattr(p, 'admin_rights', None)])
                except:
                    pass

                return {
                    "id": entity.id,
                    "title": entity.title,
                    "username": getattr(entity, 'username', None),
                    "description": getattr(entity, 'about', None),
                    "members_count": participants_count,
                    "admins_count": admins_count,
                    "is_private": getattr(entity, 'username', None) is None,
                    "join_date": entity.date
                }
            return None
        except Exception as e:
            logger.error(f"Error getting group info for {group_id}: {str(e)}")
            return None

    async def get_group_members(self, group_id: int, limit: int = 100) -> List[Dict]:
        """Get members of a specific group"""
        try:
            entity = await self.client.get_entity(group_id)
            if not isinstance(entity, (Channel, Chat)):
                return []

            participants = await self.client(GetParticipantsRequest(
                channel=entity,
                filter=ChannelParticipantsSearch(''),
                offset=0,
                limit=limit,
                hash=0
            ))

            members = []
            for participant in participants.participants:
                user = next((u for u in participants.users if u.id == participant.user_id), None)
                if user:
                    members.append({
                        "id": user.id,
                        "first_name": user.first_name,
                        "last_name": user.last_name,
                        "username": user.username,
                        "is_bot": user.bot,
                        "is_admin": getattr(participant, 'admin_rights', None) is not None
                    })

            return members
        except Exception as e:
            logger.error(f"Error getting group members for {group_id}: {str(e)}")
            return []

    async def leave_group(self, group_id: int) -> bool:
        """Leave a specific group"""
        try:
            entity = await self.client.get_entity(group_id)
            if isinstance(entity, (Channel, Chat)):
                await self.client.delete_dialog(entity)
                return True
            return False
        except Exception as e:
            logger.error(f"Error leaving group {group_id}: {str(e)}")
            return False

    async def get_message_history(self, chat_id: int, limit: int = 100) -> List[Dict]:
        """Get message history from a specific chat"""
        messages = []
        try:
            async for message in self.client.iter_messages(chat_id, limit=limit):
                messages.append({
                    "id": message.id,
                    "text": message.text,
                    "date": message.date,
                    "from_id": message.from_id,
                    "media": bool(message.media),
                    "reply_to": message.reply_to_msg_id if message.reply_to else None
                })
        except Exception as e:
            logger.error(f"Error getting message history for {chat_id}: {str(e)}")
        return messages

    def _format_group_buttons(self, groups: List[Dict], selected: List[int] = None) -> List[List[Dict]]:
        """Format groups into button grid for selection"""
        buttons = []
        selected = selected or []
        
        for group in groups:
            text = "✅ " if group["id"] in selected else ""
            text += group["title"]
            if group.get("username"):
                text += f" (@{group['username']})"
                
            buttons.append([{
                "text": text,
                "callback_data": f"toggle_group_{group['id']}"
            }])
            
        # Add control buttons
        buttons.append([
            {"text": "✅ Select All", "callback_data": "select_all_groups"},
            {"text": "❌ Clear All", "callback_data": "clear_all_groups"}
        ])
        buttons.append([
            {"text": "💾 Save Selection", "callback_data": "save_group_selection"},
            {"text": "🔙 Cancel", "callback_data": "cancel_group_selection"}
        ])
        
        return buttons

    async def create_group_selection_message(self, title: str, groups: List[Dict], selected: List[int] = None) -> Dict:
        """Create message with group selection buttons"""
        buttons = self._format_group_buttons(groups, selected)
        
        return {
            "text": f"{title}\n\nSelected: {len(selected or [])} groups",
            "buttons": buttons
        }

    async def check_group_permissions(self, group_id: int) -> Dict:
        """Check bot permissions in a group"""
        try:
            entity = await self.client.get_entity(group_id)
            me = await self.client.get_me()
            
            participant = await self.client.get_permissions(entity, me)
            
            return {
                "can_send_messages": participant.send_messages,
                "can_send_media": participant.send_media,
                "can_send_stickers": participant.send_stickers,
                "can_send_gifs": participant.send_gifs,
                "can_send_games": participant.send_games,
                "can_send_inline": participant.send_inline,
                "is_admin": participant.is_admin
            }
        except Exception as e:
            logger.error(f"Error checking permissions for group {group_id}: {str(e)}")
            return None