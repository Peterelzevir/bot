from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.tl.types import Channel, Chat, User, Dialog, Message
from telethon.tl.functions.channels import GetParticipantsRequest, JoinChannelRequest
from telethon.tl.functions.messages import GetDialogsRequest, ImportChatInviteRequest
from telethon.tl.types import (
    InputPeerEmpty, 
    ChannelParticipantsSearch,
    MessageMediaPhoto,
    MessageMediaDocument
)
from telethon.errors import (
    ChatAdminRequiredError,
    ChatWriteForbiddenError,
    UserBannedInChannelError,
    ChannelPrivateError,
    FloodWaitError
)
from typing import List, Dict, Optional, Generator, Any, Union
import asyncio
import logging
from datetime import datetime
from config import Config
from utils.helpers import MessageHelper, GroupHelper

logger = logging.getLogger(__name__)

class UserBot:
    def __init__(self, session_string: str, api_id: str, api_hash: str, user_type: str):
        """Initialize UserBot with enhanced error handling"""
        try:
            self.client = TelegramClient(StringSession(session_string), api_id, api_hash)
            self.user_type = user_type
            self.running = False
            self.message_helper = MessageHelper()
            self.group_helper = GroupHelper()
            self.active_tasks = []
            self.last_activity = None
            logger.info(f"UserBot initialized with type: {user_type}")
        except Exception as e:
            logger.error(f"Error initializing UserBot: {str(e)}")
            raise

    async def start(self) -> bool:
        """Start userbot with connection verification"""
        try:
            await self.client.start()
            # Verify connection
            me = await self.client.get_me()
            self.running = True
            self.last_activity = datetime.now()
            logger.info(f"UserBot started successfully as {me.first_name} (ID: {me.id})")
            return True
        except Exception as e:
            logger.error(f"Error starting UserBot: {str(e)}")
            return False

    async def stop(self, clean: bool = True):
        """Stop userbot with cleanup"""
        try:
            self.running = False
            # Cancel ongoing tasks
            for task in self.active_tasks:
                try:
                    task.cancel()
                except:
                    pass
            self.active_tasks.clear()
            
            if clean:
                try:
                    # Proper disconnection
                    await self.client.disconnect()
                    await self.client.session.close()
                except:
                    pass
            
            logger.info("UserBot stopped successfully")
        except Exception as e:
            logger.error(f"Error stopping UserBot: {str(e)}")

    async def get_joined_groups(self, include_members: bool = False) -> List[Dict]:
        """Get comprehensive list of joined groups"""
        try:
            groups = []
            async for dialog in self.client.iter_dialogs():
                if isinstance(dialog.entity, (Channel, Chat)):
                    if getattr(dialog.entity, 'broadcast', False):
                        continue  # Skip channels
                    
                    group_info = {
                        "id": dialog.entity.id,
                        "title": dialog.entity.title,
                        "username": getattr(dialog.entity, 'username', None),
                        "members_count": getattr(dialog.entity, 'participants_count', 0),
                        "joined_date": dialog.entity.date.isoformat(),
                        "is_private": not bool(getattr(dialog.entity, 'username', None)),
                        "last_message_date": dialog.date.isoformat() if dialog.date else None,
                        "unread_count": dialog.unread_count,
                        "is_channel": isinstance(dialog.entity, Channel),
                    }
                    
                    if include_members:
                        try:
                            group_info["members"] = await self.get_group_members(dialog.entity.id)
                        except:
                            group_info["members"] = []
                    
                    groups.append(group_info)
            
            return sorted(groups, key=lambda x: x['title'].lower())
        except Exception as e:
            logger.error(f"Error getting joined groups: {str(e)}")
            return []

    async def join_group(self, group_identifier: str) -> Dict[str, Any]:
        """Join group with enhanced error handling and verification"""
        try:
            result = {
                "success": False,
                "group_info": None,
                "error": None
            }
            
            try:
                if group_identifier.startswith(('https://t.me/+', 'https://t.me/joinchat/')):
                    # Handle private invite links
                    invite_hash = group_identifier.split('/')[-1]
                    group_entity = await self.client(ImportChatInviteRequest(invite_hash))
                    group_entity = group_entity.chats[0]
                else:
                    # Handle public usernames
                    username = group_identifier.replace('@', '').replace('https://t.me/', '')
                    group_entity = await self.client.get_entity(username)
                    await self.client(JoinChannelRequest(group_entity))

                if isinstance(group_entity, (Channel, Chat)):
                    result["success"] = True
                    result["group_info"] = {
                        "id": group_entity.id,
                        "title": group_entity.title,
                        "username": getattr(group_entity, 'username', None),
                        "members_count": getattr(group_entity, 'participants_count', 0),
                        "join_date": datetime.now().isoformat(),
                        "is_private": not bool(getattr(group_entity, 'username', None))
                    }
                    logger.info(f"Successfully joined group: {group_entity.title}")
                
            except FloodWaitError as e:
                result["error"] = f"FloodWait: need to wait {e.seconds} seconds"
            except ChannelPrivateError:
                result["error"] = "This group/channel is private"
            except UserBannedInChannelError:
                result["error"] = "You are banned from this group/channel"
            except Exception as e:
                result["error"] = str(e)
            
            return result
            
        except Exception as e:
            logger.error(f"Error joining group {group_identifier}: {str(e)}")
            return {"success": False, "error": str(e)}

    async def send_message_to_group(
        self, 
        group_id: int, 
        message: Dict, 
        watermark: Optional[str] = None,
        delay: Optional[int] = None
    ) -> Dict[str, Any]:
        """Enhanced message sending with status tracking"""
        try:
            result = {
                "success": False,
                "message_id": None,
                "error": None,
                "timestamp": datetime.now().isoformat()
            }

            # Format message
            formatted_message = await self.message_helper.format_message(
                message, 
                watermark if self.user_type == "premium" else None
            )

            # Apply delay if specified
            if delay:
                await asyncio.sleep(delay)

            try:
                if formatted_message.get("media"):
                    sent_message = await self.client.send_file(
                        group_id,
                        file=formatted_message["media"]["file"],
                        caption=formatted_message.get("caption"),
                        parse_mode='html',
                        formatting_entities=formatted_message.get("entities"),
                    )
                else:
                    sent_message = await self.client.send_message(
                        group_id,
                        formatted_message["text"],
                        parse_mode='html',
                        formatting_entities=formatted_message.get("entities"),
                    )

                result["success"] = True
                result["message_id"] = sent_message.id
                
            except ChatWriteForbiddenError:
                result["error"] = "Writing messages is forbidden in this group"
            except FloodWaitError as e:
                result["error"] = f"FloodWait: need to wait {e.seconds} seconds"
            except Exception as e:
                result["error"] = str(e)

            return result

        except Exception as e:
            logger.error(f"Error sending message to group {group_id}: {str(e)}")
            return {"success": False, "error": str(e)}

    async def broadcast_messages(
        self,
        groups: List[Dict],
        messages: List[Dict],
        watermark: Optional[str] = None,
        notify_progress: bool = True
    ) -> Generator[Dict, None, None]:
        """Enhanced broadcasting with progress tracking"""
        try:
            self.running = True
            total_groups = len(groups)
            total_messages = len(messages)
            
            while self.running:
                for message_idx, message in enumerate(messages, 1):
                    if not self.running:
                        break

                    broadcast_stats = {
                        "message_index": message_idx,
                        "success_count": 0,
                        "fail_count": 0,
                        "failed_groups": [],
                        "progress": 0.0,
                        "completed": False
                    }

                    for group_idx, group in enumerate(groups, 1):
                        if not self.running:
                            break

                        result = await self.send_message_to_group(
                            group["id"],
                            message,
                            watermark if self.user_type == "premium" else None,
                            delay=message.get("delay", 60)
                        )

                        if result["success"]:
                            broadcast_stats["success_count"] += 1
                        else:
                            broadcast_stats["fail_count"] += 1
                            broadcast_stats["failed_groups"].append({
                                "group": group,
                                "error": result["error"]
                            })

                        broadcast_stats["progress"] = (
                            (group_idx + (message_idx - 1) * total_groups) / 
                            (total_groups * total_messages) * 100
                        )

                        if notify_progress:
                            yield broadcast_stats

                    broadcast_stats["completed"] = True
                    yield broadcast_stats

        except Exception as e:
            logger.error(f"Error in broadcast: {str(e)}")
            yield {
                "success_count": 0,
                "fail_count": 0,
                "failed_groups": [],
                "error": str(e),
                "completed": True
            }

    async def send_to_recent_chats(self, message: Dict) -> Dict[str, Any]:
        """Send to recent chats with enhanced tracking"""
        try:
            result = {
                "success_count": 0,
                "fail_count": 0,
                "failed_chats": [],
                "start_time": datetime.now().isoformat()
            }

            async for dialog in self.client.iter_dialogs(limit=30):
                if isinstance(dialog.entity, User) and not dialog.entity.bot:
                    send_result = await self.send_message_to_group(
                        dialog.id,
                        message,
                        Config.WATERMARK if self.user_type == "premium" else None
                    )

                    if send_result["success"]:
                        result["success_count"] += 1
                    else:
                        result["fail_count"] += 1
                        result["failed_chats"].append({
                            "id": dialog.id,
                            "name": dialog.name,
                            "username": getattr(dialog.entity, 'username', None),
                            "error": send_result["error"]
                        })

                    await asyncio.sleep(2)  # Prevent flooding

            result["end_time"] = datetime.now().isoformat()
            return result

        except Exception as e:
            logger.error(f"Error in send_to_recent_chats: {str(e)}")
            return {
                "success_count": 0,
                "fail_count": 0,
                "failed_chats": [],
                "error": str(e)
            }

    async def get_group_info(self, group_id: int) -> Optional[Dict]:
        """Get detailed group information"""
        try:
            entity = await self.client.get_entity(group_id)
            
            if isinstance(entity, (Channel, Chat)):
                group_info = {
                    "id": entity.id,
                    "title": entity.title,
                    "username": getattr(entity, 'username', None),
                    "description": getattr(entity, 'about', None),
                    "creation_date": entity.date.isoformat(),
                    "is_private": not bool(getattr(entity, 'username', None)),
                    "is_channel": isinstance(entity, Channel),
                    "has_geo": bool(getattr(entity, 'has_geo', False)),
                    "is_verified": bool(getattr(entity, 'verified', False))
                }

                try:
                    full_chat = await self.client.get_permissions(entity)
                    group_info.update({
                        "can_send_messages": full_chat.send_messages,
                        "can_send_media": full_chat.send_media,
                        "can_invite_users": full_chat.invite_users,
                        "can_pin_messages": full_chat.pin_messages,
                        "is_admin": full_chat.is_admin
                    })
                except:
                    pass

                try:
                    participants = await self.client(GetParticipantsRequest(
                        channel=entity,
                        filter=ChannelParticipantsSearch(''),
                        offset=0,
                        limit=0,
                        hash=0
                    ))
                    group_info.update({
                        "members_count": len(participants.participants),
                        "admins_count": len([p for p in participants.participants 
                                           if getattr(p, 'admin_rights', None)])
                    })
                except:
                    group_info.update({
                        "members_count": getattr(entity, 'participants_count', 0),
                        "admins_count": 0
                    })

                return group_info

            return None

        except Exception as e:
            logger.error(f"Error getting group info for {group_id}: {str(e)}")
            return None

    async def get_group_members(
        self, 
        group_id: int, 
        limit: int = 100,
        filter_admins: bool = False
    ) -> List[Dict]:
        """Get group members with filtering options"""
        try:
            entity = await self.client.get_entity(group_id)
            if not isinstance(entity, (Channel, Chat)):
                return []

            participants = await self.client(GetParticipantsRequest(
                channel=entity,
                filter=ChannelParticipantsSearch(''),
                offset=0,
                limit=limit,
                hash=0
            ))

            members = []
            for participant in participants.participants:
                if filter_admins and not getattr(participant, 'admin_rights', None):
                    continue

                user = next((u for u in participants.users if u.id == participant.user_id), None)
                if user:
                    members.append({
                        "id": user.id,
                        "first_name": user.first_name,
                        "last_name": user.last_name,
                        "username": user.username,
                        "phone": user.phone if hasattr(user, 'phone') else None,
                        "is_bot": user.bot,
                        "is_admin": getattr(participant, 'admin_rights', None) is not None,
                        "admin_title": getattr(participant, 'rank', None),
                        "joined_date": participant.date.isoformat() if hasattr(participant, 'date') else None,
                        "last_seen": getattr(user, 'status', None),
                        "bio": getattr(user, 'about', None)
                    })

            return sorted(members, key=lambda x: (not x['is_admin'], x['first_name'] or ''))

        except Exception as e:
            logger.error(f"Error getting group members for {group_id}: {str(e)}")
            return []

    async def leave_group(self, group_id: int) -> Dict[str, Any]:
        """Leave group with status tracking"""
        try:
            result = {
                "success": False,
                "error": None,
                "timestamp": datetime.now().isoformat()
            }

            try:
                entity = await self.client.get_entity(group_id)
                if isinstance(entity, (Channel, Chat)):
                    await self.client.delete_dialog(entity)
                    result["success"] = True
                    logger.info(f"Successfully left group {group_id}")
                else:
                    result["error"] = "Invalid group type"
            except Exception as e:
                result["error"] = str(e)

            return result

        except Exception as e:
            logger.error(f"Error leaving group {group_id}: {str(e)}")
            return {"success": False, "error": str(e)}

    async def get_message_history(
        self, 
        chat_id: int, 
        limit: int = 100,
        offset_id: int = 0,
        min_id: int = None,
        max_id: int = None
    ) -> List[Dict]:
        """Get message history with enhanced filtering"""
        try:
            messages = []
            async for message in self.client.iter_messages(
                chat_id,
                limit=limit,
                offset_id=offset_id,
                min_id=min_id,
                max_id=max_id
            ):
                msg_data = {
                    "id": message.id,
                    "text": message.text,
                    "date": message.date.isoformat(),
                    "edit_date": message.edit_date.isoformat() if message.edit_date else None,
                    "from_id": message.from_id.user_id if message.from_id else None,
                    "reply_to_msg_id": message.reply_to_msg_id,
                    "forward": bool(message.forward),
                    "pinned": message.pinned,
                    "mentioned": message.mentioned,
                    "scheduled": message.scheduled,
                    "reactions": getattr(message, 'reactions', None),
                    "views": getattr(message, 'views', 0),
                    "media": None
                }

                if message.media:
                    media_info = await self.message_helper.get_media_info(message.media)
                    msg_data["media"] = media_info

                messages.append(msg_data)

            return messages

        except Exception as e:
            logger.error(f"Error getting message history for {chat_id}: {str(e)}")
            return []

    async def check_group_permissions(self, group_id: int) -> Dict[str, Any]:
        """Check comprehensive group permissions"""
        try:
            result = {
                "success": False,
                "permissions": None,
                "error": None,
                "timestamp": datetime.now().isoformat()
            }

            try:
                entity = await self.client.get_entity(group_id)
                me = await self.client.get_me()
                permissions = await self.client.get_permissions(entity, me)

                result["success"] = True
                result["permissions"] = {
                    "chat_info": {
                        "can_view_participants": permissions.view_participants,
                        "can_invite_users": permissions.invite_users,
                        "can_pin_messages": permissions.pin_messages,
                        "can_change_info": permissions.change_info
                    },
                    "messaging": {
                        "can_send_messages": permissions.send_messages,
                        "can_send_media": permissions.send_media,
                        "can_send_stickers": permissions.send_stickers,
                        "can_send_gifs": permissions.send_gifs,
                        "can_send_games": permissions.send_games,
                        "can_send_inline": permissions.send_inline,
                        "can_embed_links": permissions.embed_links,
                        "can_send_polls": permissions.send_polls
                    },
                    "admin": {
                        "is_admin": permissions.is_admin,
                        "is_creator": permissions.is_creator,
                        "can_add_admins": permissions.add_admins,
                        "can_ban_users": permissions.ban_users,
                        "can_delete_messages": permissions.delete_messages,
                        "can_edit_messages": permissions.edit_messages
                    }
                }

            except Exception as e:
                result["error"] = str(e)

            return result

        except Exception as e:
            logger.error(f"Error checking permissions for group {group_id}: {str(e)}")
            return {"success": False, "error": str(e)}

    async def create_group_selection_message(
        self, 
        title: str, 
        groups: List[Dict], 
        selected: List[int] = None
    ) -> Dict[str, Any]:
        """Create enhanced group selection message"""
        try:
            selected = selected or []
            
            # Group buttons by first letter for better organization
            grouped_buttons = {}
            for group in sorted(groups, key=lambda x: x['title'].lower()):
                first_letter = group['title'][0].upper()
                if first_letter not in grouped_buttons:
                    grouped_buttons[first_letter] = []
                
                text = "✅ " if group["id"] in selected else "⭕ "
                text += group["title"]
                if group.get("username"):
                    text += f" (@{group['username']})"
                    
                grouped_buttons[first_letter].append({
                    "text": text,
                    "callback_data": f"toggle_group_{group['id']}"
                })

            # Create final button layout
            buttons = []
            for letter in sorted(grouped_buttons.keys()):
                buttons.extend([[btn] for btn in grouped_buttons[letter]])

            # Add control buttons
            control_buttons = [
                [
                    {"text": "✅ Select All", "callback_data": "select_all_groups"},
                    {"text": "❌ Clear All", "callback_data": "clear_all_groups"}
                ],
                [
                    {"text": "💾 Save", "callback_data": "save_group_selection"},
                    {"text": "🔄 Refresh", "callback_data": "refresh_groups"},
                    {"text": "🔙 Cancel", "callback_data": "cancel_selection"}
                ]
            ]
            buttons.extend(control_buttons)

            return {
                "text": (
                    f"{title}\n\n"
                    f"Selected: {len(selected)}/{len(groups)} groups\n"
                    f"✅ = Selected | ⭕ = Not Selected"
                ),
                "buttons": buttons,
                "total_groups": len(groups),
                "selected_count": len(selected)
            }

        except Exception as e:
            logger.error(f"Error creating group selection message: {str(e)}")
            return {
                "text": "Error creating selection message",
                "buttons": [[{"text": "🔙 Back", "callback_data": "back"}]]
            }