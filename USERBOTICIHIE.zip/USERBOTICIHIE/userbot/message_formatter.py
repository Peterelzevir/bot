#okok
from telethon.tl.types import (
    MessageEntityBold, MessageEntityItalic, MessageEntityCode,
    MessageEntityStrike, MessageEntityUnderline, MessageEntityPre,
    MessageEntityTextUrl, MessageEntityMention, MessageEntityHashtag,
    MessageEntityUrl, MessageEntitySpoiler, MessageEntityCustomEmoji,
    MessageEntityBlockquote, MessageEntityCashtag, MessageEntityPhone,
    MessageEntityEmail, MessageEntityBotCommand
)
from telethon.helpers import add_surrogate, del_surrogate
import emoji
import re
import logging
from typing import List, Dict, Union, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class MessageFormatter:
    """Enhanced message formatting with comprehensive style support"""
    
    # Text Style Constants
    TEXT_STYLES = {
        'bold': '**{}**',
        'italic': '__{}__',
        'code': '`{}`',
        'strike': '~~{}~~',
        'underline': '--{}--',
        'spoiler': '||{}||',
        'quote': '> {}',
        'blockquote': '```{}```',
        'pre': '```{}```',
        'mention': '@{}',
        'hashtag': '#{}',
        'cashtag': '${}',
        'url': '[{}]({})',
        'emoji': '{}'
    }

    # Entity Type Mappings
    ENTITY_MAPPING = {
        'messageentitybold': (MessageEntityBold, {}),
        'messageentityitalic': (MessageEntityItalic, {}),
        'messageentitycode': (MessageEntityCode, {}),
        'messageentitystrike': (MessageEntityStrike, {}),
        'messageentityunderline': (MessageEntityUnderline, {}),
        'messageentitypre': (MessageEntityPre, {'language': ''}),
        'messageentitytexturl': (MessageEntityTextUrl, {'url': ''}),
        'messageentitymention': (MessageEntityMention, {}),
        'messageentityhashtag': (MessageEntityHashtag, {}),
        'messageentityurl': (MessageEntityUrl, {}),
        'messageentityspoiler': (MessageEntitySpoiler, {}),
        'messageentitycustomemoji': (MessageEntityCustomEmoji, {'document_id': 0}),
        'messageentityblockquote': (MessageEntityBlockquote, {}),
        'messageentitycashtag': (MessageEntityCashtag, {}),
        'messageentityphone': (MessageEntityPhone, {}),
        'messageentityemail': (MessageEntityEmail, {}),
        'messageentitybotcommand': (MessageEntityBotCommand, {})
    }

    @staticmethod
    def validate_text(text: str) -> str:
        """Validate and clean text input"""
        try:
            if not isinstance(text, str):
                return str(text)
            return text.strip()
        except Exception as e:
            logger.error(f"Text validation error: {str(e)}")
            return ""

    @classmethod
    def format_text(cls, text: str, style: str, **kwargs) -> str:
        """Apply text formatting with validation"""
        try:
            text = cls.validate_text(text)
            if style in cls.TEXT_STYLES:
                if style == 'url' and 'url' in kwargs:
                    return cls.TEXT_STYLES[style].format(text, kwargs['url'])
                return cls.TEXT_STYLES[style].format(text)
            return text
        except Exception as e:
            logger.error(f"Text formatting error: {str(e)}")
            return text

    @classmethod
    def parse_entities(cls, text: str, entities: List[Dict]) -> str:
        """Enhanced entity parsing with error handling"""
        try:
            if not text or not entities:
                return text

            # Add surrogate for proper handling of unicode and emoji
            text = add_surrogate(text)
            sorted_entities = sorted(entities, key=lambda x: x["offset"], reverse=True)

            for entity in sorted_entities:
                try:
                    start = entity["offset"]
                    length = entity["length"]
                    end = start + length
                    chunk = text[start:end]
                    entity_type = entity["type"].lower()

                    if entity_type in cls.TEXT_STYLES:
                        styled_chunk = cls.format_text(chunk, entity_type, 
                                                     url=entity.get('url'))
                        text = text[:start] + styled_chunk + text[end:]
                except Exception as e:
                    logger.warning(f"Error processing entity: {str(e)}")
                    continue

            # Remove surrogate
            return del_surrogate(text)
        except Exception as e:
            logger.error(f"Entity parsing error: {str(e)}")
            return text

    @classmethod
    def create_entities(cls, text: str) -> List[Dict]:
        """Create entities with enhanced pattern matching"""
        try:
            entities = []
            text = add_surrogate(text)
            
            patterns = {
                'bold': (r'\*\*(.*?)\*\*', 'messageentitybold', 4),
                'italic': (r'__(.*?)__', 'messageentityitalic', 4),
                'code': (r'`(.*?)`', 'messageentitycode', 2),
                'strike': (r'~~(.*?)~~', 'messageentitystrike', 4),
                'underline': (r'--(.*?)--', 'messageentityunderline', 4),
                'spoiler': (r'\|\|(.*?)\|\|', 'messageentityspoiler', 4),
                'pre': (r'```(.*?)```', 'messageentitypre', 6),
                'url': (r'https?://\S+', 'messageentityurl', 0),
                'mention': (r'@\w+', 'messageentitymention', 0),
                'hashtag': (r'#\w+', 'messageentityhashtag', 0),
                'cashtag': (r'\$\w+', 'messageentitycashtag', 0),
                'email': (r'\S+@\S+\.\S+', 'messageentityemail', 0),
                'phone': (r'\+\d{10,15}', 'messageentityphone', 0),
                'bot_command': (r'/\w+', 'messageentitybotcommand', 0)
            }

            for style, (pattern, entity_type, marker_len) in patterns.items():
                for match in re.finditer(pattern, text):
                    start, end = match.span()
                    if marker_len:
                        start += marker_len // 2
                        end -= marker_len // 2
                    
                    entity = {
                        "type": entity_type,
                        "offset": start,
                        "length": end - start
                    }

                    # Add extra attributes for special entities
                    if style == 'url':
                        entity["url"] = match.group(0)
                    elif style == 'pre':
                        entity["language"] = ""

                    entities.append(entity)

            return sorted(entities, key=lambda x: (x['offset'], x['length']))
        except Exception as e:
            logger.error(f"Entity creation error: {str(e)}")
            return []

    @classmethod
    def format_message(cls, message: Dict, watermark: Optional[str] = None) -> Dict:
        """Format complete message with comprehensive handling"""
        try:
            formatted = {
                "text": message.get("text", ""),
                "entities": message.get("entities", []),
                "media": message.get("media"),
                "caption": message.get("caption", ""),
                "caption_entities": message.get("caption_entities", []),
                "custom_emojis": message.get("custom_emojis", []),
                "formatting_timestamp": datetime.now().isoformat()
            }

            # Handle watermark
            if watermark:
                if formatted["media"] and formatted["caption"]:
                    formatted["caption"] = cls.format_caption(
                        formatted["caption"], watermark
                    )
                elif formatted["text"]:
                    formatted["text"] = cls.format_caption(
                        formatted["text"], watermark
                    )

            # Process entities
            if formatted["text"] and formatted["entities"]:
                formatted["text"] = cls.parse_entities(
                    formatted["text"], 
                    formatted["entities"]
                )

            if formatted["caption"] and formatted["caption_entities"]:
                formatted["caption"] = cls.parse_entities(
                    formatted["caption"],
                    formatted["caption_entities"]
                )

            return formatted
        except Exception as e:
            logger.error(f"Message formatting error: {str(e)}")
            return message

    @staticmethod
    def format_caption(caption: str, watermark: str) -> str:
        """Format caption with watermark"""
        try:
            if not caption and not watermark:
                return ""
            
            formatted_caption = caption.strip() if caption else ""
            if watermark:
                if formatted_caption:
                    formatted_caption += f"\n\n{watermark}"
                else:
                    formatted_caption = watermark
            
            return formatted_caption
        except Exception as e:
            logger.error(f"Caption formatting error: {str(e)}")
            return caption or watermark or ""

    @classmethod
    def convert_to_telethon_entities(cls, entities: List[Dict]) -> List:
        """Convert to Telethon entities with enhanced error handling"""
        try:
            telethon_entities = []
            for entity in entities:
                try:
                    entity_type = entity["type"].lower()
                    if entity_type in cls.ENTITY_MAPPING:
                        EntityClass, extra_attrs = cls.ENTITY_MAPPING[entity_type]
                        
                        kwargs = {
                            "offset": entity["offset"],
                            "length": entity["length"]
                        }
                        
                        # Add extra attributes if provided in entity
                        for attr, default in extra_attrs.items():
                            kwargs[attr] = entity.get(attr, default)
                        
                        telethon_entities.append(EntityClass(**kwargs))
                except Exception as e:
                    logger.warning(f"Error converting entity: {str(e)}")
                    continue
                    
            return telethon_entities
        except Exception as e:
            logger.error(f"Entity conversion error: {str(e)}")
            return []

    @staticmethod
    def has_emoji(text: str) -> bool:
        """Check for emoji presence safely"""
        try:
            return bool(emoji.emoji_count(text))
        except Exception as e:
            logger.error(f"Emoji check error: {str(e)}")
            return False