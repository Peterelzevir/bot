p# main.py
from telethon import TelegramClient, events, Button
from config import Config
from database.database import Database
from handlers.user_handlers import UserHandlers
from handlers.admin_handlers import AdminHandlers
from utils.expiry_checker import ExpiryChecker
import asyncio
import logging
import sys
import traceback
from datetime import datetime

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.DEBUG,
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

class UserbotBot:
    def __init__(self):
        self.bot = TelegramClient('bot', Config.API_ID, Config.API_HASH)
        self.db = Database(Config.DB_NAME)
        self.active_userbots = {}
        
    async def start(self):
        try:
            logger.info("Starting bot...")
            await self.bot.start(bot_token=Config.BOT_TOKEN)
            
            # Test bot connection
            me = await self.bot.get_me()
            logger.info(f"Bot started successfully as @{me.username}")
            
            # Initialize handlers
            self.user_handlers = UserHandlers(self.bot, self.db)
            self.admin_handlers = AdminHandlers(self.bot, self.db)
            
            # Start expiry checker
            self.expiry_checker = ExpiryChecker(self.bot, self.db)
            asyncio.create_task(self.expiry_checker.start())
            
            # Register handlers
            self._register_handlers()
            
            logger.info("Bot is now running")
            await self.bot.run_until_disconnected()
            
        except Exception as e:
            logger.error(f"Critical error: {str(e)}\n{traceback.format_exc()}")
            raise

    def _register_handlers(self):
        # Command handler
        @self.bot.on(events.NewMessage(pattern='/start'))
        async def start(event):
            try:
                logger.debug(f"Start command from {event.sender_id}")
                await self.user_handlers.start_handler(event)
            except Exception as e:
                logger.error(f"Error in start: {str(e)}")
                await event.reply("⚠️ An error occurred")

        # User handlers 
        @self.bot.on(events.CallbackQuery(pattern=b'create_userbot'))
        async def create_userbot(event):
            try:
                await self.user_handlers.create_userbot_handler(event)
            except Exception as e:
                logger.error(f"Error in create_userbot: {str(e)}")
                await event.answer("⚠️ Error", alert=True)
                
        @self.bot.on(events.CallbackQuery(pattern=b'about_userbot'))
        async def about_userbot(event):
            try:
                await self.user_handlers.about_handler(event)
            except Exception as e:
                logger.error(f"Error in about: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'settings_userbot'))
        async def settings(event):
            try:
                await self.user_handlers.settings_handler(event)
            except Exception as e:
                logger.error(f"Error in settings: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'status'))
        async def status(event):
            try:
                await self.user_handlers.status_handler(event)
            except Exception as e:
                logger.error(f"Error in status: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'check_lists'))
        async def check_lists(event):
            try:
                await self.user_handlers.check_lists_handler(event)
            except Exception as e:
                logger.error(f"Error in check_lists: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'add_list'))
        async def add_list(event):
            try:
                await self.user_handlers.add_list_handler(event)
            except Exception as e:
                logger.error(f"Error in add_list: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'delete_list'))
        async def delete_list(event):
            try:
                await self.user_handlers.delete_list_handler(event)
            except Exception as e:
                logger.error(f"Error in delete_list: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'add_groups'))
        async def add_groups(event):
            try:
                await self.user_handlers.add_groups_handler(event)
            except Exception as e:
                logger.error(f"Error in add_groups: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'list_groups'))
        async def list_groups(event):
            try:
                await self.user_handlers.list_groups_handler(event)
            except Exception as e:
                logger.error(f"Error in list_groups: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'delete_group'))
        async def delete_group(event):
            try:
                await self.user_handlers.delete_group_handler(event)
            except Exception as e:
                logger.error(f"Error in delete_group: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'joined_groups'))
        async def joined_groups(event):
            try:
                await self.user_handlers.joined_groups_handler(event)
            except Exception as e:
                logger.error(f"Error in joined_groups: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'send_rc'))
        async def send_rc(event):
            try:
                await self.user_handlers.send_rc_handler(event)
            except Exception as e:
                logger.error(f"Error in send_rc: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'confirm_status_.*'))
        async def confirm_status(event):
            try:
                await self.user_handlers.confirm_status_handler(event)
            except Exception as e:
                logger.error(f"Error in confirm_status: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'delete_msg_.*'))
        async def delete_message(event):
            try:
                await self.user_handlers.confirm_delete_message(event)
            except Exception as e:
                logger.error(f"Error in delete_message: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'delete_group_.*'))
        async def confirm_delete_group(event):
            try:
                await self.user_handlers.confirm_delete_group(event)
            except Exception as e:
                logger.error(f"Error in confirm_delete_group: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'add_all_groups'))
        async def add_all_groups(event):
            try:
                await self.user_handlers.add_all_groups_handler(event)
            except Exception as e:
                logger.error(f"Error in add_all_groups: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'custom_add_groups'))
        async def custom_add_groups(event):
            try:
                await self.user_handlers.custom_add_groups_handler(event)
            except Exception as e:
                logger.error(f"Error in custom_add_groups: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'toggle_group_.*'))
        async def toggle_group(event):
            try:
                await self.user_handlers.toggle_group_handler(event)
            except Exception as e:
                logger.error(f"Error in toggle_group: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'save_group_selection'))
        async def save_group_selection(event):
            try:
                await self.user_handlers.save_group_selection_handler(event)
            except Exception as e:
                logger.error(f"Error in save_group_selection: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        # Admin handlers
        @self.bot.on(events.CallbackQuery(pattern=b'admin_panel'))
        async def admin_panel(event):
            try:
                await self.admin_handlers.admin_panel_handler(event)
            except Exception as e:
                logger.error(f"Error in admin_panel: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'add_admin'))
        async def add_admin(event):
            try:
                await self.admin_handlers.add_admin_handler(event)
            except Exception as e:
                logger.error(f"Error in add_admin: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'add_premium'))
        async def add_premium(event):
            try:
                await self.admin_handlers.add_premium_handler(event)
            except Exception as e:
                logger.error(f"Error in add_premium: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'premium_.*'))
        async def handle_premium_type(event):
            try:
                await self.admin_handlers.handle_premium_type(event)
            except Exception as e:
                logger.error(f"Error in handle_premium_type: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'broadcast'))
        async def broadcast(event):
            try:
                await self.admin_handlers.broadcast_handler(event)
            except Exception as e:
                logger.error(f"Error in broadcast: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'user_list'))
        async def user_list(event):
            try:
                await self.admin_handlers.user_list_handler(event)
            except Exception as e:
                logger.error(f"Error in user_list: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'delete_userbot'))
        async def delete_userbot(event):
            try:
                await self.admin_handlers.delete_userbot_handler(event)
            except Exception as e:
                logger.error(f"Error in delete_userbot: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        @self.bot.on(events.CallbackQuery(pattern=b'confirm_delete_.*'))
        async def confirm_delete_userbot(event):
            try:
                await self.admin_handlers.confirm_delete_userbot(event)
            except Exception as e:
                logger.error(f"Error in confirm_delete_userbot: {str(e)}")
                await event.answer("⚠️ Error", alert=True)

        # Message state handlers
        @self.bot.on(events.NewMessage)
        async def handle_messages(event):
            if not event.message.is_private:
                return
                
            try:
                user_state = self.user_handlers.user_states.get(event.sender_id)
                if user_state:
                    logger.debug(f"Processing state {user_state} for user {event.sender_id}")
                    await self._handle_user_states(event, user_state)
                
                # Admin states
                admin_state = self.admin_handlers.admin_states.get(event.sender_id)
                if event.sender_id == Config.ADMIN_ID and admin_state:
                    logger.debug(f"Processing admin state {admin_state}")
                    await self._handle_admin_states(event, admin_state)
                    
            except Exception as e:
                logger.error(f"Error handling message: {str(e)}\n{traceback.format_exc()}")
                await event.reply("⚠️ An error occurred")

    async def _handle_user_states(self, event, state):
        """Handle user states"""
        try:
            if state == "waiting_phone":
                await self.user_handlers.handle_phone_number(event)
            elif state == "waiting_code":
                await self.user_handlers.handle_code(event)
            elif state == "waiting_message":
                await self.user_handlers.handle_new_message(event)
            elif state == "waiting_delay":
                await self.user_handlers.handle_delay_input(event)
            elif state == "waiting_group":
                await self.user_handlers.handle_group_input(event)
            elif state == "waiting_rc_message":
                await self.user_handlers.handle_rc_message(event)
        except Exception as e:
            logger.error(f"Error in user state handler: {str(e)}")
            raise

    async def _handle_admin_states(self, event, state):
        """Handle admin states"""
        try:
            if state == "waiting_admin_id":
                await self.admin_handlers.handle_admin_id(event)
            elif state == "waiting_premium_user":
                await self.admin_handlers.handle_premium_user(event)
            elif state == "waiting_premium_duration":
                await self.admin_handlers.handle_premium_duration(event)
            elif state == "waiting_broadcast":
                await self.admin_handlers.handle_broadcast(event)
        except Exception as e:
            logger.error(f"Error in admin state handler: {str(e)}")
            raise

if __name__ == '__main__':
    try:
        logger.info("Starting bot process...")
        bot = UserbotBot()
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user!")
    except Exception as e:
        logger.error(f"Bot crashed: {str(e)}\n{traceback.format_exc()}")