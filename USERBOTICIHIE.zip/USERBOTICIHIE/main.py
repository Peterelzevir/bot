from telethon import TelegramClient, events
from config import Config
from database.database import Database
from handlers.user_handlers import UserHandlers
from handlers.admin_handlers import AdminHandlers
from utils.expiry_checker import ExpiryChecker
import asyncio
import logging
import sys
import traceback

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.DEBUG,
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

class UserbotBot:
    def __init__(self):
        self.bot = TelegramClient('bot', Config.API_ID, Config.API_HASH)
        self.db = Database(Config.DB_NAME)
        self.active_userbots = {}

    async def start(self):
        try:
            logger.info("Starting bot...")
            await self.bot.start(bot_token=Config.BOT_TOKEN)

            # Test bot connection
            me = await self.bot.get_me()
            logger.info(f"Bot started successfully as @{me.username}")

            # Initialize handlers
            self.user_handlers = UserHandlers(self.bot, self.db)
            self.admin_handlers = AdminHandlers(self.bot, self.db)

            # Start expiry checker
            self.expiry_checker = ExpiryChecker(self.bot, self.db)
            asyncio.create_task(self.expiry_checker.start())

            # Register handlers
            self._register_handlers()

            logger.info("Bot is now running")
            await self.bot.run_until_disconnected()

        except Exception as e:
            logger.error(f"Critical error: {str(e)}\n{traceback.format_exc()}")
            raise

    def _register_handlers(self):
        # Command handler for /start
        @self.bot.on(events.NewMessage(pattern='/start'))
        async def start(event):
            logger.debug(f"Start command from {event.sender_id}")
            try:
                await self.user_handlers.start_handler(event)
            except Exception as e:
                logger.error(f"Error in start: {str(e)}")
                await event.reply("⚠️ An error occurred")

        # Register user handlers for callback queries
        callback_patterns = [
            ('create_userbot', 'create_userbot_handler'),
            ('about_userbot', 'about_handler'),
            ('settings_userbot', 'settings_handler'),
            ('status', 'status_handler'),
            ('check_lists', 'check_lists_handler'),
            ('add_list', 'add_list_handler'),
            ('delete_list', 'delete_list_handler'),
            ('add_groups', 'add_groups_handler'),
            ('list_groups', 'list_groups_handler'),
            ('delete_group', 'delete_group_handler'),
            ('joined_groups', 'joined_groups_handler'),
            ('send_rc', 'send_rc_handler'),
            ('confirm_status_.*', 'confirm_status_handler'),
            ('delete_msg_.*', 'confirm_delete_message'),
            ('delete_group_.*', 'confirm_delete_group'),
            ('add_all_groups', 'add_all_groups_handler'),
            ('custom_add_groups', 'custom_add_groups_handler'),
            ('toggle_group_.*', 'toggle_group_handler'),
            ('save_group_selection', 'save_group_selection_handler')
        ]

        for pattern, handler in callback_patterns:
            @self.bot.on(events.CallbackQuery(pattern=pattern.encode()))
            async def callback(event, handler=handler):
                try:
                    await getattr(self.user_handlers, handler)(event)
                except Exception as e:
                    logger.error(f"Error in {handler}: {str(e)}")
                    await event.answer("⚠️ Error", alert=True)

        # Admin handlers for callback queries
        admin_callback_patterns = [
            ('admin_panel', 'admin_panel_handler'),
            ('add_admin', 'add_admin_handler'),
            ('add_premium', 'add_premium_handler'),
            ('premium_.*', 'handle_premium_type'),
            ('broadcast', 'broadcast_handler'),
            ('user_list', 'user_list_handler'),
            ('delete_userbot', 'delete_userbot_handler'),
            ('confirm_delete_.*', 'confirm_delete_userbot')
        ]

        for pattern, handler in admin_callback_patterns:
            @self.bot.on(events.CallbackQuery(pattern=pattern.encode()))
            async def admin_callback(event, handler=handler):
                try:
                    await getattr(self.admin_handlers, handler)(event)
                except Exception as e:
                    logger.error(f"Error in {handler}: {str(e)}")
                    await event.answer("⚠️ Error", alert=True)

        # Message state handlers
        @self.bot.on(events.NewMessage)
        async def handle_messages(event):
            if not event.message.is_private:
                return

            try:
                user_state = self.user_handlers.user_states.get(event.sender_id)
                if user_state:
                    logger.debug(f"Processing state {user_state} for user {event.sender_id}")
                    await self._handle_user_states(event, user_state)

                # Admin states
                admin_state = self.admin_handlers.admin_states.get(event.sender_id)
                if event.sender_id == Config.ADMIN_ID and admin_state:
                    logger.debug(f"Processing admin state {admin_state}")
                    await self._handle_admin_states(event, admin_state)

            except Exception as e:
                logger.error(f"Error handling message: {str(e)}\n{traceback.format_exc()}")
                await event.reply("⚠️ An error occurred")

    async def _handle_user_states(self, event, state):
        """Handle user states"""
        try:
            state_methods = {
                "waiting_phone": self.user_handlers.handle_phone_number,
                "waiting_code": self.user_handlers.handle_code,
                "waiting_message": self.user_handlers.handle_new_message,
                "waiting_delay": self.user_handlers.handle_delay_input,
                "waiting_group": self.user_handlers.handle_group_input,
                "waiting_rc_message": self.user_handlers.handle_rc_message,
            }
            
            if state in state_methods:
                await state_methods[state](event)

        except Exception as e:
            logger.error(f"Error in user state handler: {str(e)}")
    
    async def _handle_admin_states(self, event, state):
        """Handle admin states"""
        try:
            admin_methods = {
                "waiting_admin_id": self.admin_handlers.handle_admin_id,
                "waiting_premium_user": self.admin_handlers.handle_premium_user,
                "waiting_premium_duration": self.admin_handlers.handle_premium_duration,
                "waiting_broadcast": self.admin_handlers.handle_broadcast,
            }

            if state in admin_methods:
                await admin_methods[state](event)

        except Exception as e:
           logger.error(f"Error in admin state handler: {str(e)}")

if __name__ == '__main__':
    try:
        logger.info("Starting bot process...")
        bot = UserbotBot()
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user!")
    except Exception as e:
        logger.error(f"Bot crashed: {str(e)}\n{traceback.format_exc()}")
