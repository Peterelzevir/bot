#main.py njir
# codingan @hiyaok only.
from telethon import TelegramClient, events, Button
from config import Config
from database.database import Database
from handlers.user_handlers import UserHandlers
from handlers.admin_handlers import AdminHandlers
from utils.expiry_checker import ExpiryChecker
import asyncio
import logging
import sys
import traceback
from datetime import datetime

# Improved logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,  # Change to INFO for production
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class UserbotBot:
    def __init__(self):
        # Initialize bot with session name
        self.bot = TelegramClient('bot_session', Config.API_ID, Config.API_HASH)
        self.db = Database(Config.DB_NAME)
        self.active_userbots = {}
        self.user_handlers = None
        self.admin_handlers = None
        self.expiry_checker = None

    async def start(self):
        try:
            logger.info("Starting bot...")
            
            # Connect and start bot
            await self.bot.connect()
            if not await self.bot.is_user_authorized():
                await self.bot.start(bot_token=Config.BOT_TOKEN)
            
            # Test connection
            me = await self.bot.get_me()
            logger.info(f"Bot started successfully as @{me.username}")
            
            # Initialize handlers
            self.user_handlers = UserHandlers(self.bot, self.db)
            self.admin_handlers = AdminHandlers(self.bot, self.db)
            
            # Initialize expiry checker
            self.expiry_checker = ExpiryChecker(self.bot, self.db)
            
            # Register handlers
            self._register_handlers()
            
            # Start expiry checker in background
            asyncio.create_task(self.expiry_checker.start())
            
            logger.info("Bot is now running. Press Ctrl+C to stop.")
            await self.bot.run_until_disconnected()
            
        except Exception as e:
            logger.error(f"Critical error during startup: {str(e)}\n{traceback.format_exc()}")
            # Attempt to disconnect cleanly
            try:
                await self.bot.disconnect()
            except:
                pass
            raise

    def _register_handlers(self):
        """Register all message and callback handlers"""
        try:
            # Start command handler with proper error handling
            @self.bot.on(events.NewMessage(pattern='/start'))
            async def start_command(event):
                try:
                    if event.is_private:
                        logger.info(f"Start command from user {event.sender_id}")
                        await self.user_handlers.start_handler(event)
                except Exception as e:
                    logger.error(f"Error in start command: {str(e)}\n{traceback.format_exc()}")
                    await event.reply("⚠️ Terjadi kesalahan. Silakan coba lagi.")

            # User Callback Handlers
            user_callbacks = {
                'create_userbot': self.user_handlers.create_userbot_handler,
                'about_userbot': self.user_handlers.about_handler,
                'settings_userbot': self.user_handlers.settings_handler,
                'status': self.user_handlers.status_handler,
                'check_lists': self.user_handlers.check_lists_handler,
                'add_list': self.user_handlers.add_list_handler,
                'delete_list': self.user_handlers.delete_list_handler,
                'add_groups': self.user_handlers.add_groups_handler,
                'set_delay': self.user_handlers.set_delay_handler,
                'list_groups': self.user_handlers.list_groups_handler,
                'delete_group': self.user_handlers.delete_group_handler,
                'joined_groups': self.user_handlers.joined_groups_handler,
                'send_rc': self.user_handlers.send_rc_handler,
                'add_all_groups': self.user_handlers.add_all_groups_handler,
                'custom_add_groups': self.user_handlers.custom_add_groups_handler,
            }

            # Admin Callback Handlers
            admin_callbacks = {
                'admin_panel': self.admin_handlers.admin_panel_handler,
                'add_admin': self.admin_handlers.add_admin_handler,
                'add_premium': self.admin_handlers.add_premium_handler,
                'broadcast': self.admin_handlers.broadcast_handler,
                'user_list': self.admin_handlers.user_list_handler,
                'delete_userbot': self.admin_handlers.delete_userbot_handler,
                'admin_create_userbot': self.admin_handlers.admin_create_userbot_handler,
                'admin_settings_userbot': self.admin_handlers.admin_settings_userbot,
            }

            # Register user callbacks
            for pattern, handler in user_callbacks.items():
                @self.bot.on(events.CallbackQuery(pattern=pattern.encode()))
                async def callback_wrapper(event, handler=handler):
                    try:
                        await handler(event)
                    except Exception as e:
                        logger.error(f"Error in {handler.__name__}: {str(e)}\n{traceback.format_exc()}")
                        await event.answer("⚠️ Terjadi kesalahan", alert=True)

            # Register admin callbacks
            for pattern, handler in admin_callbacks.items():
                @self.bot.on(events.CallbackQuery(pattern=pattern.encode()))
                async def admin_callback_wrapper(event, handler=handler):
                    try:
                        if event.sender_id != Config.ADMIN_ID:
                            await event.answer("⛔ Access denied!", alert=True)
                            return
                        await handler(event)
                    except Exception as e:
                        logger.error(f"Error in {handler.__name__}: {str(e)}\n{traceback.format_exc()}")
                        await event.answer("⚠️ Terjadi kesalahan", alert=True)

            # Special pattern handlers
            special_patterns = {
                b'confirm_status_.*': self.user_handlers.confirm_status_handler,
                b'delete_msg_.*': self.user_handlers.confirm_delete_message,
                b'delete_group_.*': self.user_handlers.confirm_delete_group,
                b'premium_.*': self.admin_handlers.handle_premium_type,
                b'confirm_delete_.*': self.admin_handlers.confirm_delete_userbot,
                b'set_delay_.*': self.user_handlers.handle_delay_selection,
                b'delete_msg_.*': self.user_handlers.confirm_delete_message,
                b'confirm_delete_user_.*': self.user_handlers.final_delete_message,
                b'final_delete_group_.*': self.user_handlers.final_delete_group,
                b'final_delete_userbot_.*': self.admin_handlers.final_delete_userbot
            }

            for pattern, handler in special_patterns.items():
                @self.bot.on(events.CallbackQuery(pattern=pattern))
                async def pattern_wrapper(event, handler=handler):
                    try:
                        # Check admin access for admin handlers
                        if handler.__module__.endswith('admin_handlers') and event.sender_id != Config.ADMIN_ID:
                            await event.answer("⛔ Access denied!", alert=True)
                            return
                        await handler(event)
                    except Exception as e:
                        logger.error(f"Error in pattern handler: {str(e)}\n{traceback.format_exc()}")
                        await event.answer("⚠️ Terjadi kesalahan", alert=True)

            # Message state handler
            @self.bot.on(events.NewMessage)
            async def message_handler(event):
                if not event.is_private:
                    return
                    
                try:
                    # Handle user states
                    user_state = self.user_handlers.user_states.get(event.sender_id)
                    if user_state:
                        logger.debug(f"Processing user state: {user_state} for user {event.sender_id}")
                        await self._handle_user_states(event, user_state)
                    
                    # Handle admin states
                    if event.sender_id == Config.ADMIN_ID:
                        admin_state = self.admin_handlers.admin_states.get(event.sender_id)
                        if admin_state:
                            logger.debug(f"Processing admin state: {admin_state}")
                            await self._handle_admin_states(event, admin_state)
                            
                except Exception as e:
                    logger.error(f"Error in message handler: {str(e)}\n{traceback.format_exc()}")
                    await event.reply("⚠️ Terjadi kesalahan. Silakan coba lagi.")

            logger.info("All handlers registered successfully")

        except Exception as e:
            logger.error(f"Error registering handlers: {str(e)}\n{traceback.format_exc()}")
            raise

    async def _handle_user_states(self, event, state):
        """Handle user state transitions"""
        try:
            # Map states to handlers
            handlers = {
                "waiting_phone": self.user_handlers.handle_phone_number,
                "waiting_code": self.user_handlers.handle_code,
                "waiting_2fa": self.user_handlers.handle_2fa,
                "waiting_message": self.user_handlers.handle_new_message,
                "waiting_delay": self.user_handlers.handle_delay_input,
                "waiting_new_delay": self.user_handlers.handle_new_delay,
                "waiting_group_usernames": self.user_handlers.handle_group_usernames,
                "waiting_rc_message": self.user_handlers.handle_rc_message
            }
            
            if isinstance(state, dict):
                state_name = state.get("state")
                handler = handlers.get(state_name)
            else:
                handler = handlers.get(state)
                
            if handler:
                await handler(event)
            else:
                logger.warning(f"Unknown state: {state}")
                
        except Exception as e:
            logger.error(f"Error in user state handler: {str(e)}\n{traceback.format_exc()}")
            raise

    async def _handle_admin_states(self, event, state):
        """Handle admin state transitions"""
        try:
            # Map states to handlers
            handlers = {
                "waiting_admin_id": self.admin_handlers.handle_admin_id,
                "waiting_premium_user": self.admin_handlers.handle_premium_user,
                "waiting_premium_duration": self.admin_handlers.handle_premium_duration,
                "waiting_broadcast": self.admin_handlers.handle_broadcast,
                "waiting_phone_admin": self.admin_handlers.handle_phone_number_admin,
                "waiting_code_admin": self.admin_handlers.handle_code_admin,
                "waiting_2fa_admin": self.admin_handlers.handle_2fa_admin
            }
            
            if isinstance(state, dict):
                state_name = state.get("state")
                handler = handlers.get(state_name)
            else:
                handler = handlers.get(state)
                
            if handler:
                await handler(event)
            else:
                logger.warning(f"Unknown admin state: {state}")
                
        except Exception as e:
            logger.error(f"Error in admin state handler: {str(e)}\n{traceback.format_exc()}")
            raise

if __name__ == '__main__':
    try:
        logger.info("Starting bot process...")
        bot = UserbotBot()
        
        loop = asyncio.get_event_loop()
        try:
            loop.run_until_complete(bot.start())
        except KeyboardInterrupt:
            logger.info("Bot stopped by user!")
            loop.run_until_complete(bot.bot.disconnect())
        finally:
            loop.close()
            
    except Exception as e:
        logger.critical(f"Fatal error: {str(e)}\n{traceback.format_exc()}")
        sys.exit(1)