from telethon import TelegramClient, events, Button
from config import Config
import logging

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize bot
bot = TelegramClient('bot', Config.API_ID, Config.API_HASH)

@bot.on(events.NewMessage(pattern='/start'))
async def start(event):
    try:
        await event.reply(
            "🤖 Welcome to Userbot!\n\n"
            "Bot ini memungkinkan Anda untuk membuat userbot.",
            buttons=[
                [Button.inline("📱 Create Userbot", "create_userbot")],
                [Button.inline("ℹ️ About", "about")]
            ]
        )
    except Exception as e:
        logger.error(f"Error in start handler: {e}")
        await event.reply("An error occurred")

async def main():
    # Start the client
    await bot.start(bot_token=Config.BOT_TOKEN)
    logger.info("Bot started successfully!")
    
    # Run the client until disconnected
    await bot.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped!")