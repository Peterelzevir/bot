# buat test aje
# test_bot.py
from telethon import TelegramClient
from config import Config
import asyncio

async def main():
    bot = TelegramClient('bot', Config.API_ID, Config.API_HASH)
    await bot.start(bot_token=Config.BOT_TOKEN)
    
    me = await bot.get_me()
    print(f"Bot is working! Username: @{me.username}")
    
    await bot.disconnect()

if __name__ == '__main__':
    asyncio.run(main())