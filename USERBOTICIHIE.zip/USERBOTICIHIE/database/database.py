import sqlite3
import json
from datetime import datetime, timedelta
import aiosqlite
import asyncio
from typing import List, Dict, Optional, Any
from database.models import User, Message, Group, Userbot, AllowedGroup
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_name: str = "userbot.db"):
        self.db_name = db_name
        self._create_tables()
    
    def _create_tables(self):
        """Create necessary tables if they don't exist"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                c = conn.cursor()
                
                # Users table with improved schema
                c.execute('''
                    CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY,
                        access_type TEXT DEFAULT 'regular',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        expire_at TIMESTAMP,
                        phone TEXT,
                        first_name TEXT,
                        username TEXT,
                        status TEXT DEFAULT 'active',
                        last_active TIMESTAMP
                    )
                ''')
                
                # Userbots table with additional fields
                c.execute('''
                    CREATE TABLE IF NOT EXISTS userbots (
                        user_id INTEGER PRIMARY KEY,
                        session_string TEXT,
                        status TEXT DEFAULT 'inactive',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        last_active TIMESTAMP,
                        phone TEXT,
                        app_id INTEGER,
                        app_hash TEXT,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                # Messages table with enhanced media support
                c.execute('''
                    CREATE TABLE IF NOT EXISTS messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        text TEXT,
                        media BLOB,
                        media_type TEXT,
                        caption TEXT,
                        delay INTEGER DEFAULT 60,
                        entities TEXT,
                        caption_entities TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        last_used TIMESTAMP,
                        status TEXT DEFAULT 'active',
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                # Groups table with more metadata
                c.execute('''
                    CREATE TABLE IF NOT EXISTS groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        group_id INTEGER,
                        title TEXT,
                        username TEXT,
                        member_count INTEGER,
                        join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        last_active TIMESTAMP,
                        status TEXT DEFAULT 'active',
                        is_channel BOOLEAN DEFAULT 0,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')

                # Allowed Groups table with broadcast tracking
                c.execute('''
                    CREATE TABLE IF NOT EXISTS allowed_groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        group_id INTEGER,
                        title TEXT,
                        username TEXT,
                        added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        last_broadcast TIMESTAMP,
                        success_count INTEGER DEFAULT 0,
                        fail_count INTEGER DEFAULT 0,
                        status TEXT DEFAULT 'active',
                        FOREIGN KEY (user_id) REFERENCES users (user_id),
                        FOREIGN KEY (group_id) REFERENCES groups (group_id)
                    )
                ''')

                # Broadcast logs table
                c.execute('''
                    CREATE TABLE IF NOT EXISTS broadcast_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        message_id INTEGER,
                        group_id INTEGER,
                        status TEXT,
                        error_message TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id),
                        FOREIGN KEY (message_id) REFERENCES messages (id),
                        FOREIGN KEY (group_id) REFERENCES groups (group_id)
                    )
                ''')
                
                conn.commit()
                logger.info("Database tables created successfully")

        except Exception as e:
            logger.error(f"Error creating database tables: {str(e)}")
            raise

    # User Methods
    async def add_user(self, user_id: int, access_type: str = "regular", duration: Optional[int] = None, 
                      first_name: Optional[str] = None, username: Optional[str] = None) -> None:
        """Add or update user with improved data handling"""
        try:
            expire_at = (datetime.now() + timedelta(days=duration)).isoformat() if duration else None
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO users 
                    (user_id, access_type, expire_at, first_name, username, last_active) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (user_id, access_type, expire_at, first_name, username, datetime.now().isoformat()))
                await db.commit()
                logger.info(f"User {user_id} added/updated successfully")
        except Exception as e:
            logger.error(f"Error adding/updating user {user_id}: {str(e)}")
            raise

    async def get_user(self, user_id: int) -> Optional[User]:
        """Get user with enhanced error handling"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)) as cursor:
                    row = await cursor.fetchone()
                    if row:
                        return User(
                            user_id=row[0],
                            access_type=row[1],
                            created_at=datetime.fromisoformat(row[2]),
                            expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                            phone=row[4],
                            first_name=row[5],
                            username=row[6],
                            status=row[7],
                            last_active=datetime.fromisoformat(row[8]) if row[8] else None
                        )
                    return None
        except Exception as e:
            logger.error(f"Error getting user {user_id}: {str(e)}")
            raise

    async def update_user_access(self, user_id: int, access_type: str, duration: Optional[int] = None) -> None:
        """Update user access with expiry handling"""
        try:
            expire_at = (datetime.now() + timedelta(days=duration)).isoformat() if duration else None
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    UPDATE users 
                    SET access_type = ?, expire_at = ?, last_active = ? 
                    WHERE user_id = ?
                ''', (access_type, expire_at, datetime.now().isoformat(), user_id))
                await db.commit()
                logger.info(f"User {user_id} access updated to {access_type}")
        except Exception as e:
            logger.error(f"Error updating user access for {user_id}: {str(e)}")
            raise

    # Userbot Methods
    async def add_userbot(self, user_id: int, session_string: str, phone: Optional[str] = None,
                         app_id: Optional[int] = None, app_hash: Optional[str] = None) -> None:
        """Add userbot with enhanced metadata"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO userbots 
                    (user_id, session_string, phone, app_id, app_hash, last_active) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (user_id, session_string, phone, app_id, app_hash, datetime.now().isoformat()))
                await db.commit()
                logger.info(f"Userbot added for user {user_id}")
        except Exception as e:
            logger.error(f"Error adding userbot for user {user_id}: {str(e)}")
            raise

    async def get_userbot(self, user_id: int) -> Optional[Userbot]:
        """Get userbot with comprehensive data"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                # Get userbot info
                async with db.execute('SELECT * FROM userbots WHERE user_id = ?', (user_id,)) as cursor:
                    row = await cursor.fetchone()
                    if not row:
                        return None

                # Get related data
                messages = await self.get_messages(user_id)
                groups = await self.get_groups(user_id)
                allowed_groups = await self.get_allowed_groups(user_id)

                return Userbot(
                    user_id=row[0],
                    session_string=row[1],
                    status=row[2],
                    created_at=datetime.fromisoformat(row[3]),
                    last_active=datetime.fromisoformat(row[4]) if row[4] else None,
                    phone=row[5],
                    app_id=row[6],
                    app_hash=row[7],
                    messages=messages,
                    groups=groups,
                    allowed_groups=allowed_groups
                )
        except Exception as e:
            logger.error(f"Error getting userbot for user {user_id}: {str(e)}")
            raise

    async def update_userbot_status(self, user_id: int, status: str) -> None:
        """Update userbot status with timestamp"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    UPDATE userbots 
                    SET status = ?, last_active = ? 
                    WHERE user_id = ?
                ''', (status, datetime.now().isoformat(), user_id))
                await db.commit()
                logger.info(f"Userbot status updated to {status} for user {user_id}")
        except Exception as e:
            logger.error(f"Error updating userbot status for user {user_id}: {str(e)}")
            raise

    # Message Methods
    async def add_message(self, user_id: int, message: Dict) -> None:
        """Add message with enhanced media handling"""
        try:
            media_data = message.get("media")
            media_json = json.dumps(media_data) if media_data else None
            media_type = media_data.get("type") if media_data else None
            
            entities_json = json.dumps(message.get("entities", [])) if message.get("entities") else None
            caption_entities_json = json.dumps(message.get("caption_entities", [])) if message.get("caption_entities") else None
            
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT INTO messages 
                    (user_id, text, media, media_type, caption, delay, entities, 
                     caption_entities, last_used, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    user_id,
                    message.get("text", ""),
                    media_json,
                    media_type,
                    message.get("caption", ""),
                    message.get("delay", 60),
                    entities_json,
                    caption_entities_json,
                    datetime.now().isoformat(),
                    'active'
                ))
                await db.commit()
                logger.info(f"Message added for user {user_id}")
        except Exception as e:
            logger.error(f"Error adding message for user {user_id}: {str(e)}")
            raise

    async def get_messages(self, user_id: int) -> List[Message]:
        """Get active messages with complete data"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute(
                    'SELECT * FROM messages WHERE user_id = ? AND status = ? ORDER BY created_at',
                    (user_id, 'active')
                ) as cursor:
                    rows = await cursor.fetchall()
                    messages = []
                    for row in rows:
                        message = Message(
                            id=row[0],
                            text=row[2],
                            media=json.loads(row[3]) if row[3] else None,
                            media_type=row[4],
                            caption=row[5],
                            delay=row[6],
                            entities=json.loads(row[7]) if row[7] else [],
                            caption_entities=json.loads(row[8]) if row[8] else [],
                            created_at=datetime.fromisoformat(row[9]),
                            last_used=datetime.fromisoformat(row[10]) if row[10] else None,
                            status=row[11]
                        )
                        messages.append(message)
                    return messages
        except Exception as e:
            logger.error(f"Error getting messages for user {user_id}: {str(e)}")
            raise

    async def delete_message(self, user_id: int, message_id: int) -> None:
        """Soft delete message by setting status to inactive"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    UPDATE messages 
                    SET status = ?, last_used = ? 
                    WHERE user_id = ? AND id = ?
                ''', ('inactive', datetime.now().isoformat(), user_id, message_id))
                await db.commit()
                logger.info(f"Message {message_id} deleted for user {user_id}")
        except Exception as e:
            logger.error(f"Error deleting message {message_id} for user {user_id}: {str(e)}")
            raise

    async def update_message_delay(self, user_id: int, message_id: int, delay: int) -> None:
        """Update message delay"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    UPDATE messages 
                    SET delay = ?, last_used = ? 
                    WHERE user_id = ? AND id = ?
                ''', (delay, datetime.now().isoformat(), user_id, message_id))
                await db.commit()
                logger.info(f"Message {message_id} delay updated to {delay}s for user {user_id}")
        except Exception as e:
            logger.error(f"Error updating delay for message {message_id}: {str(e)}")
            raise

    # Group Methods
    async def add_group(self, user_id: int, group: Dict) -> None:
        """Add group with enhanced metadata"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO groups 
                    (user_id, group_id, title, username, member_count, last_active, is_channel) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    user_id,
                    group["id"],
                    group["title"],
                    group.get("username"),
                    group.get("member_count", 0),
                    datetime.now().isoformat(),
                    group.get("is_channel", False)
                ))
                await db.commit()
                logger.info(f"Group {group['id']} added for user {user_id}")
        except Exception as e:
            logger.error(f"Error adding group for user {user_id}: {str(e)}")
            raise

    async def get_groups(self, user_id: int) -> List[Group]:
        """Get active groups"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute(
                    'SELECT * FROM groups WHERE user_id = ? AND status = ? ORDER BY title',
                    (user_id, 'active')
                ) as cursor:
                    rows = await cursor.fetchall()
                    return [Group(
                        id=row[0],
                        group_id=row[2],
                        title=row[3],
                        username=row[4],
                        member_count=row[5],
                        join_date=datetime.fromisoformat(row[6]),
                        last_active=datetime.fromisoformat(row[7]) if row[7] else None,
                        status=row[8],
                        is_channel=bool(row[9])
                    ) for row in rows]
        except Exception as e:
            logger.error(f"Error getting groups for user {user_id}: {str(e)}")
            raise
            
    # Allowed Groups Methods
    async def add_allowed_group(self, user_id: int, group: Dict) -> None:
        """Add group to allowed list with tracking data"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO allowed_groups 
                    (user_id, group_id, title, username, last_broadcast, success_count, fail_count) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    user_id,
                    group["id"],
                    group["title"],
                    group.get("username"),
                    None,
                    0,
                    0
                ))
                await db.commit()
                logger.info(f"Group {group['id']} added to allowed list for user {user_id}")
        except Exception as e:
            logger.error(f"Error adding allowed group for user {user_id}: {str(e)}")
            raise

    async def get_allowed_groups(self, user_id: int) -> List[AllowedGroup]:
        """Get active allowed groups with stats"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute(
                    'SELECT * FROM allowed_groups WHERE user_id = ? AND status = ? ORDER BY title',
                    (user_id, 'active')
                ) as cursor:
                    rows = await cursor.fetchall()
                    return [AllowedGroup(
                        id=row[0],
                        group_id=row[2],
                        title=row[3],
                        username=row[4],
                        added_date=datetime.fromisoformat(row[5]),
                        last_broadcast=datetime.fromisoformat(row[6]) if row[6] else None,
                        success_count=row[7],
                        fail_count=row[8],
                        status=row[9]
                    ) for row in rows]
        except Exception as e:
            logger.error(f"Error getting allowed groups for user {user_id}: {str(e)}")
            raise

    async def remove_allowed_group(self, user_id: int, group_id: int) -> None:
        """Soft delete allowed group"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    UPDATE allowed_groups 
                    SET status = 'inactive' 
                    WHERE user_id = ? AND group_id = ?
                ''', (user_id, group_id))
                await db.commit()
                logger.info(f"Group {group_id} removed from allowed list for user {user_id}")
        except Exception as e:
            logger.error(f"Error removing allowed group {group_id}: {str(e)}")
            raise

    async def update_broadcast_stats(self, user_id: int, group_id: int, success: bool) -> None:
        """Update broadcast statistics for group"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                if success:
                    await db.execute('''
                        UPDATE allowed_groups 
                        SET success_count = success_count + 1,
                            last_broadcast = ?
                        WHERE user_id = ? AND group_id = ?
                    ''', (datetime.now().isoformat(), user_id, group_id))
                else:
                    await db.execute('''
                        UPDATE allowed_groups 
                        SET fail_count = fail_count + 1,
                            last_broadcast = ?
                        WHERE user_id = ? AND group_id = ?
                    ''', (datetime.now().isoformat(), user_id, group_id))
                await db.commit()
                logger.info(f"Broadcast stats updated for group {group_id}")
        except Exception as e:
            logger.error(f"Error updating broadcast stats for group {group_id}: {str(e)}")
            raise

    # Broadcast Logs
    async def log_broadcast(self, user_id: int, message_id: int, group_id: int, 
                          status: str, error_message: Optional[str] = None) -> None:
        """Log broadcast attempt"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                await db.execute('''
                    INSERT INTO broadcast_logs 
                    (user_id, message_id, group_id, status, error_message) 
                    VALUES (?, ?, ?, ?, ?)
                ''', (user_id, message_id, group_id, status, error_message))
                await db.commit()
                logger.info(f"Broadcast log added for message {message_id} to group {group_id}")
        except Exception as e:
            logger.error(f"Error logging broadcast: {str(e)}")
            raise

    async def get_broadcast_logs(self, user_id: int, limit: int = 100) -> List[Dict]:
        """Get recent broadcast logs"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute('''
                    SELECT bl.*, m.text, g.title 
                    FROM broadcast_logs bl
                    LEFT JOIN messages m ON bl.message_id = m.id
                    LEFT JOIN groups g ON bl.group_id = g.group_id
                    WHERE bl.user_id = ?
                    ORDER BY bl.created_at DESC
                    LIMIT ?
                ''', (user_id, limit)) as cursor:
                    rows = await cursor.fetchall()
                    return [{
                        'id': row[0],
                        'message_text': row[8][:50] + '...' if row[8] else 'N/A',
                        'group_title': row[9] or 'Unknown Group',
                        'status': row[4],
                        'error': row[5],
                        'timestamp': datetime.fromisoformat(row[6])
                    } for row in rows]
        except Exception as e:
            logger.error(f"Error getting broadcast logs: {str(e)}")
            raise

    # Additional Methods
    async def get_all_users(self) -> List[User]:
        """Get all active users"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute(
                    'SELECT * FROM users WHERE status = ? ORDER BY created_at DESC',
                    ('active',)
                ) as cursor:
                    rows = await cursor.fetchall()
                    return [User(
                        user_id=row[0],
                        access_type=row[1],
                        created_at=datetime.fromisoformat(row[2]),
                        expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                        phone=row[4],
                        first_name=row[5],
                        username=row[6],
                        status=row[7],
                        last_active=datetime.fromisoformat(row[8]) if row[8] else None
                    ) for row in rows]
        except Exception as e:
            logger.error(f"Error getting all users: {str(e)}")
            raise

    async def delete_userbot(self, user_id: int) -> None:
        """Delete userbot and associated data"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                # Soft delete instead of hard delete
                await db.execute('UPDATE userbots SET status = ? WHERE user_id = ?', ('deleted', user_id))
                await db.execute('UPDATE messages SET status = ? WHERE user_id = ?', ('deleted', user_id))
                await db.execute('UPDATE groups SET status = ? WHERE user_id = ?', ('deleted', user_id))
                await db.execute('UPDATE allowed_groups SET status = ? WHERE user_id = ?', ('deleted', user_id))
                await db.commit()
                logger.info(f"Userbot and associated data deleted for user {user_id}")
        except Exception as e:
            logger.error(f"Error deleting userbot for user {user_id}: {str(e)}")
            raise

    async def check_expired_users(self) -> List[User]:
        """Get list of users whose premium access has expired"""
        try:
            current_time = datetime.now()
            async with aiosqlite.connect(self.db_name) as db:
                async with db.execute('''
                    SELECT * FROM users 
                    WHERE expire_at IS NOT NULL 
                    AND expire_at < ? 
                    AND access_type IN ('premium', 'premium_plus')
                ''', (current_time.isoformat(),)) as cursor:
                    rows = await cursor.fetchall()
                    return [User(
                        user_id=row[0],
                        access_type=row[1],
                        created_at=datetime.fromisoformat(row[2]),
                        expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                        phone=row[4],
                        first_name=row[5],
                        username=row[6],
                        status=row[7],
                        last_active=datetime.fromisoformat(row[8]) if row[8] else None
                    ) for row in rows]
        except Exception as e:
            logger.error(f"Error checking expired users: {str(e)}")
            raise

    async def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """Get comprehensive user statistics"""
        try:
            async with aiosqlite.connect(self.db_name) as db:
                stats = {
                    'message_count': 0,
                    'group_count': 0,
                    'allowed_group_count': 0,
                    'total_broadcasts': 0,
                    'successful_broadcasts': 0,
                    'failed_broadcasts': 0
                }
                
                # Get counts
                async with db.execute('SELECT COUNT(*) FROM messages WHERE user_id = ? AND status = ?', 
                                    (user_id, 'active')) as cursor:
                    stats['message_count'] = (await cursor.fetchone())[0]
                
                async with db.execute('SELECT COUNT(*) FROM groups WHERE user_id = ? AND status = ?', 
                                    (user_id, 'active')) as cursor:
                    stats['group_count'] = (await cursor.fetchone())[0]
                
                async with db.execute('SELECT COUNT(*) FROM allowed_groups WHERE user_id = ? AND status = ?', 
                                    (user_id, 'active')) as cursor:
                    stats['allowed_group_count'] = (await cursor.fetchone())[0]
                
                async with db.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
                        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
                    FROM broadcast_logs 
                    WHERE user_id = ?
                ''', (user_id,)) as cursor:
                    row = await cursor.fetchone()
                    if row:
                        stats['total_broadcasts'] = row[0]
                        stats['successful_broadcasts'] = row[1] or 0
                        stats['failed_broadcasts'] = row[2] or 0
                
                return stats
        except Exception as e:
            logger.error(f"Error getting user stats for user {user_id}: {str(e)}")
            raise