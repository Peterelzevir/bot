#models y
from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class User(BaseModel):
    """Enhanced User Model"""
    user_id: int
    access_type: str = "regular"  # regular, premium, premium_plus, admin
    created_at: datetime = Field(default_factory=datetime.now)
    expire_at: Optional[datetime] = None
    phone: Optional[str] = None
    first_name: Optional[str] = None
    username: Optional[str] = None
    status: str = "active"  # active, banned, deleted
    last_active: Optional[datetime] = None

    class Config:
        from_attributes = True

class Message(BaseModel):
    """Enhanced Message Model"""
    id: int
    text: Optional[str] = None
    media: Optional[Dict] = None
    media_type: Optional[str] = None  # photo, video, gif, document, etc.
    caption: Optional[str] = None
    delay: int = 60
    entities: List[Dict] = []
    caption_entities: List[Dict] = []
    created_at: datetime = Field(default_factory=datetime.now)
    last_used: Optional[datetime] = None
    status: str = "active"  # active, deleted

    class Config:
        from_attributes = True

class Group(BaseModel):
    """Enhanced Group Model"""
    id: int
    group_id: int
    title: str
    username: Optional[str] = None
    member_count: Optional[int] = None
    join_date: datetime = Field(default_factory=datetime.now)
    last_active: Optional[datetime] = None
    status: str = "active"  # active, left, banned, deleted
    is_channel: bool = False
    is_allowed: bool = False

    class Config:
        from_attributes = True

class AllowedGroup(BaseModel):
    """Enhanced Allowed Group Model"""
    id: int
    group_id: int
    title: str
    username: Optional[str] = None
    added_date: datetime = Field(default_factory=datetime.now)
    last_broadcast: Optional[datetime] = None
    success_count: int = 0
    fail_count: int = 0
    status: str = "active"  # active, inactive, deleted

    class Config:
        from_attributes = True

class BroadcastLog(BaseModel):
    """New Broadcast Log Model"""
    id: int
    user_id: int
    message_id: int
    group_id: int
    status: str  # success, failed
    error_message: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.now)

    class Config:
        from_attributes = True

class Userbot(BaseModel):
    """Enhanced Userbot Model"""
    user_id: int
    session_string: str
    status: str = "inactive"  # inactive, active, deleted
    created_at: datetime = Field(default_factory=datetime.now)
    last_active: Optional[datetime] = None
    phone: Optional[str] = None
    app_id: Optional[int] = None
    app_hash: Optional[str] = None
    messages: List[Message] = []
    groups: List[Group] = []
    allowed_groups: List[AllowedGroup] = []

    class Config:
        from_attributes = True

class UserStats(BaseModel):
    """New User Stats Model"""
    user_id: int
    message_count: int = 0
    group_count: int = 0
    allowed_group_count: int = 0
    total_broadcasts: int = 0
    successful_broadcasts: int = 0
    failed_broadcasts: int = 0
    last_broadcast: Optional[datetime] = None

    class Config:
        from_attributes = True